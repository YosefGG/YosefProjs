export const init: (appInitResponse: any) => void;
