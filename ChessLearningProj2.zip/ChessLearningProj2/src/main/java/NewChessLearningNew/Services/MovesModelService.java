package NewChessLearningNew.Services;

import NewChessLearningNew.Models.Location;
import NewChessLearningNew.Models.Move;
import NewChessLearningNew.Models.MovesModel;
import NewChessLearningNew.Models.MyHashCode;
import NewChessLearningNew.Repositories.MovesModelRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service

public class MovesModelService {
    private MovesModelRepository movesModelRepo;
    public MovesModelService(MovesModelRepository movesModelRepo) {
        this.movesModelRepo=movesModelRepo;
    }
    public boolean addMovesModel(MovesModel movesModel) 
    {
        if(movesModelRepo.findById(movesModel.getMoveName()).isEmpty())
        {
            movesModelRepo.insert(movesModel);
            return true;
        }
        return false;
    }

    public List<MovesModel> getAllMovesModels() {
        return movesModelRepo.findAll();
    }
    public MovesModel getMovesModelById(String id)
    {
        Optional movesModel=null;
        MovesModel trueMovesModel=null;
        try
        {
            movesModel=movesModelRepo.findById(id);
            trueMovesModel=(MovesModel)(movesModel.get());
        }
        catch(Exception e)
        {
        }
        return trueMovesModel; 
    }
    public boolean delMoveModel(MovesModel toDel)
    {
        MovesModel mme=getMovesModelById(toDel.getMoveName());
        if(mme!=null)
        {
            movesModelRepo.delete(toDel);
            return true;
        }
        return false;
    }
    
}
