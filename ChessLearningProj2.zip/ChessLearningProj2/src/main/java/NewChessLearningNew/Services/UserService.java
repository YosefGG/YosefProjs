package NewChessLearningNew.Services;

//import NewChessLearningNew.Models.MyHashCode;
import NewChessLearningNew.Models.MyHashCode;
import NewChessLearningNew.Models.User;
import NewChessLearningNew.Models.UserMovesModelSize;
import NewChessLearningNew.Repositories.UserRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private UserRepository userRepo;

    public UserService(UserRepository userRepo) {
        this.userRepo=userRepo;
    }
    public boolean addUser(User user) 
    {
        if(userRepo.findById(user.getUserName()).isEmpty())
        {
            userRepo.insert(user);
            return true;
        }
        return false;
    }
    public boolean userExcist(String id)
    {
        return !userRepo.findById(id).isEmpty();
    }
    public List<User> getAllUsers()
    {
        return userRepo.findAll();
    }
    public User getUserById(String id) 
    {
        Optional user=null;
        User trueUser=null;
        try
        {
            user=userRepo.findById(id);
            trueUser=(User)(user.get());
        }
        catch(NoSuchElementException e)
        {
            return null;
        }
        return trueUser; 
    }
    public boolean updateUser(User user)
    {
            if(userExcist(user.getUserName()))
            {
                userRepo.save(user);
                return true;
            }
        return false;
    }

    public boolean deleteUser(User userToDel) {
        if(!userRepo.findById(userToDel.getUserName()).isEmpty())
        {
            userRepo.delete(userToDel);
            return true;
        }
        return false;
    }
    public void updateAllUsers(List<User> users)
    {
        userRepo.saveAll(users);
    }
}
