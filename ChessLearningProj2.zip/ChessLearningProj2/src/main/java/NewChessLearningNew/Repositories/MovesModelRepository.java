package NewChessLearningNew.Repositories;

import NewChessLearningNew.Models.MovesModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository    
public interface MovesModelRepository extends MongoRepository<MovesModel, String> {
    }
