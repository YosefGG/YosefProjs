package NewChessLearningNew.Models;

import NewChessLearningNew.Models.User;


public class StudentUser extends User{
    public StudentUser(String userName, String password) {
        super(userName, password,"", false);
    }

    
}
