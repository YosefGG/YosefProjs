package NewChessLearningNew.Models;
public class UserMovesModelSize {
    private int maxIndex;
    private int size;
    
    public UserMovesModelSize()
    {
        
    }
    public UserMovesModelSize(int maxIndex, int size) {
        this.maxIndex = maxIndex;
        this.size = size;
    }

    public int getMaxIndex() {
        return maxIndex;
    }

    public void setMaxIndex(int maxIndex) {
        this.maxIndex = maxIndex;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    
    public int getProccedInfo()
    {
        return (int)((maxIndex*1.0/size*1.0)*100);
    }
    
    @Override
    public String toString() {
        return "UserMovesModelSize{" + "maxIndex=" + maxIndex + ", size=" + size + '}';
    }
    
    
    
}
