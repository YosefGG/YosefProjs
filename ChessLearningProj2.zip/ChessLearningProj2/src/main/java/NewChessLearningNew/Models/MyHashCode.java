package NewChessLearningNew.Models;


public class MyHashCode {
public static final String[] names=
        {
          "Study-Pawn1",  
          "Study_Pawn2", 
          "Study-Pawn3", 
          "Study-Pawn4", 
          "Study-Rook1", 
          "Study-Rook2", 
          "Study-Rook3", 
          "Study-Queen1", 
          "Study-Queen2", 
          "Study-Queen3", 
          "Study-Knight1", 
          "Study-Knight2", 
          "Study-Knight3", 
          "Study-Bishop1", 
          "Study-Bishop2", 
          "Study-Bishop3",
          "Study-King1",
          "Study-King2",
          "Study-King3",
          "Study-King4",
          "Study-King5",
          "Openings-Sicilian Defense",
          "Openings-FrenchDefence",
          "Openings-ScandinavianDefense",
          "Openings-ItalianGame",
          "Openings-KingsGambit",
          "Openings-EnglishOpening",
          "Openings-QueensGambit",
          "GM1",
          "GM2",
          "GM3",
          "GM4",
          "EG-Bishop1",
          "EG-Bishop2",
          "EG-Knight1",
          "EG-Knight2",
          "EG-Pawn1",
          "EG-Pawn2",
          "EG-Rook1",
          "EG-Rook2",
          "EG-Queen1",
          "EG-Queen2",
          "EG-King1",
          "EG-King2"
        };
     public static final int[] sizes={
            64,
            25,
            32,
            12,
            24,
            6,
            19,
            40,
            21,
            15,
            32,
            19,
            33,
            10,
            29,
            24,
            24,
            31,
            9,
            7,
            14,
            17,
            16,
            22,
            20,
            27,
            30,
            11,
            138,
            20,
            48,
            41,
            31,
            39,
            73,
            3,
            29,
            44,
            45,
            25,
            17,
            29,
            3,
            3
       };
    public MyHashCode() {
    
    }
    public int getSizeOfList()
    {
        return names.length;
    }
    public static int getMyHashIndex(String nameOfMove)
    {
        for (int i = 0; i < names.length; i++) {
            if(names[i].equals(nameOfMove))
                return i;
        }
        return -1;
    }
    public static String getNameOfMoveByIndex(int index)
    {
        return names[index];
    }
    public static String[] getMyHash()
    {
        return names;
    }
    public static int[] getSizesOfAllMoves()
    {
             return sizes;
    }
}
