package NewChessLearningNew.Models;

import java.util.ArrayList;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Users")
public class User {
    @Id
    private String userName;
    private String password;
    private String name;
    private boolean isTeacher;
    private ArrayList<UserMovesModelSize> maxIndexsOfMovesModel;
    private boolean admin;
    
    public User()
    {
        
    }
    public User(String userName, String password,String name,boolean isTeacher) {
        maxIndexsOfMovesModel=new ArrayList<>();
        this.userName = userName;
        this.password = password;
        this.name=name;
        this.isTeacher = isTeacher;
        admin=false;
        createDefualtmacIndexsOfMoevsModel();
    }
    public User(String userName, String password,String name,boolean isTeacher,boolean isAdmin) {
        maxIndexsOfMovesModel=new ArrayList<>();
        this.userName = userName;
        this.password = password;
        this.name=name;
        this.isTeacher = isTeacher;
        admin=isAdmin;
        createDefualtmacIndexsOfMoevsModel();
    }
    public User(String userName, String password, String name, boolean isTeacher, ArrayList<UserMovesModelSize> maxIndexsOfMovesModel) {
        this.userName = userName;
        this.password = password;
        this.name = name;
        this.isTeacher = isTeacher;
        this.maxIndexsOfMovesModel = maxIndexsOfMovesModel;
        admin=false;
    }
    
    public User(User user)
    {
        this.userName = user.userName;
        this.password = user.password;
        this.name = user.name;
        this.isTeacher = user.isTeacher;
        user.admin=false;
        setMaxIndexsOfMovesModel(user.maxIndexsOfMovesModel);
    }

    public User(String userName, String password, String name, boolean isTeacher, ArrayList<UserMovesModelSize> maxIndexsOfMovesModel, boolean admin) {
        this.userName = userName;
        this.password = password;
        this.name = name;
        this.isTeacher = isTeacher;
        this.maxIndexsOfMovesModel = maxIndexsOfMovesModel;
        this.admin = admin;
    }
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isIsTeacher() {
        return isTeacher;
    }

    public void setIsTeacher(boolean isTeacher) {
        this.isTeacher = isTeacher;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList getMaxIndexsOfMovesModel() {
        return maxIndexsOfMovesModel;
    }

    public void setMaxIndexsOfMovesModel(ArrayList<UserMovesModelSize> maxIndexsOfMovesModel) {
        this.maxIndexsOfMovesModel=new ArrayList<>();
        for (int i = 0; i < maxIndexsOfMovesModel.size(); i++) {
            this.maxIndexsOfMovesModel.add((UserMovesModelSize)maxIndexsOfMovesModel.get(i));
        }
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }
    
    private void createDefualtmacIndexsOfMoevsModel()
    {
        int[] sizes={
            64,
            25,
            32,
            12,
            24,
            6,
            19,
            40,
            21,
            15,
            32,
            19,
            33,
            10,
            29,
            24,
            24,
            31,
            9,
            7,
            14,
            17,
            16,
            22,
            20,
            27,
            30,
            11,
            138,
            20,
            48,
            41,
            31,
            39,
            73,
            3,
            29,
            44,
            45,
            25,
            17,
            29,
            3,
            3
       };
        for (int i = 0; i < sizes.length; i++) 
            maxIndexsOfMovesModel.add(new UserMovesModelSize(0, sizes[i]));
    }
    @Override
    public String toString() {
        return "User{" + "userName=" + userName + ", password=" + password + ", name="+ name+", isTeacher=" + isTeacher + '}';
    }

    
    
    
    
    
}
