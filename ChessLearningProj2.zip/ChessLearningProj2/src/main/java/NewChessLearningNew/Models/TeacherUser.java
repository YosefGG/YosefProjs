package NewChessLearningNew.Models;

import NewChessLearningNew.Models.User;


public class TeacherUser extends User{
    public TeacherUser(String userName, String password) {
        super(userName, password,"",true);
    }
    

    
}      
