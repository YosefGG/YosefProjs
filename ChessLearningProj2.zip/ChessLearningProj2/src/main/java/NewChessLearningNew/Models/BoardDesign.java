package NewChessLearningNew.Models;

import NewChessLearningNew.Run.Pieces;
import java.awt.Color;
import java.awt.desktop.UserSessionEvent;
import java.util.ArrayList;

public class BoardDesign {
    private Piece[][] board;
    private Piece[] blackPieces;
    private Piece[] whitePieces;
    private boolean delBtnPressd;
    private Location prevMove;
    private int blackPieceClickedLoc;
    private int whitePieceClickedLoc;
    private boolean showRulesBtnPressd;
    public BoardDesign() {
        showRulesBtnPressd=false;
        delBtnPressd=false;
        board = new Piece[8][8];
        blackPieces=new Piece[6];
        whitePieces=new Piece[6];
        blackPieceClickedLoc=-1;
        whitePieceClickedLoc=-1;
        prevMove=null;
        init();
    }
    private void init()
    {
        char[] blackPiecesNames={'P','R','B','N','K','Q'};
        char[] whitePiecesNames={'p','r','b','n','k','q'};
        for (int i = 0; i < 6; i++) {
            blackPieces[i]=new Piece(blackPiecesNames[i],"BLACK");
            whitePieces[i]=new Piece(blackPiecesNames[i],"WHITE");
        }
        initBoard();
    }
    public void initBoard()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j]=new Piece(' ',"yellow");
            }
        }
    }
    public Piece[] getBlackPieces() {
        return blackPieces;
    }

    public void setBlackPieces(Piece[] blackPieces) {
        this.blackPieces = blackPieces;
    }

    public Piece[] getWhitePieces() {
        return whitePieces;
    }

    public void setWhitePieces(Piece[] whitePieces) {
        this.whitePieces = whitePieces;
    }

    public Location getPrevMove() {
        return prevMove;
    }

    public void setPrevMove(Location prevMove) {
        this.prevMove = prevMove;
    }

    public int getBlackPieceClickedLoc() {
        return blackPieceClickedLoc;
    }

    public void setBlackPieceClickedLoc(int blackPieceClickedLoc) {
        this.blackPieceClickedLoc = blackPieceClickedLoc;
    }

    public int getWhitePieceClickedLoc() {
        return whitePieceClickedLoc;
    }

    public void setWhitePieceClickedLoc(int whitePieceClickedLoc) {
        this.whitePieceClickedLoc = whitePieceClickedLoc;
    }
    
    public Piece[][] getBoard() {
        return board;
    }

    public void setBoard(Piece[][] board) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                this.board[i][j]=new Piece(board[i][j]);
            }
        }
    }
    
    public boolean checkMoveOnBoard(Location loc)
    {
        
       int row=loc.getRow();
       int col=loc.getCol();
       if(board[row][col].getPiece()==' ' && !thereIsPrevMoveNotDoingThing())
           return false;
       return true;
    }

    public boolean thereIsPrevMove() {
        if(prevMove!=null)
        {
            prevMove=null;
            return true;
        } 
        return false;
    }
    public boolean thereIsPrevMoveNotDoingThing() {
        if(prevMove!=null)
            return true;
        return false;
    }
    
    public boolean whitePieceClicked() {
        if(whitePieceClickedLoc>-1)
            return true;
        return false;
    }

    public boolean blackPieceClicked() {
        if(blackPieceClickedLoc>-1)
            return true;
        return false;
    }

    public boolean isShowRulesBtnPressd() {
        return showRulesBtnPressd;
    }

    public void setShowRulesBtnPressd(boolean showRulesBtnPressd) {
        this.showRulesBtnPressd = showRulesBtnPressd;
    }
    
    public boolean twoBlackPieceNotEquals(int l1,int l2) {
        if(!blackPieces[l1].equals(blackPieces[l2]))
            return true;
        return false;
    }

    public boolean twoWhitePieceNotEquals(int l1,int l2) {
        if(!whitePieces[l1].equals(whitePieces[l2]))
            return true;
        return false;
    }

    public void setPrevMoveDeafult() {
        prevMove=null;
    }

    public void doMove(Move move) {
        Location srcLoc=move.getSrcLoc();
        Location dstLoc=move.getDstLoc();
        board[dstLoc.getRow()][dstLoc.getCol()]=new Piece(board[srcLoc.getRow()][srcLoc.getCol()]);
        board[srcLoc.getRow()][srcLoc.getCol()].setPiece(' ');
        board[srcLoc.getRow()][srcLoc.getCol()].setColor("yellow");
    } 
    public void bringBlackPieceToBoard(int srcLoc,Location dstLoc)
    {
        board[dstLoc.getRow()][dstLoc.getCol()]=new Piece(blackPieces[srcLoc]);
    }
    public void bringWhitePieceToBoard(int srcLoc,Location dstLoc)
    {
        board[dstLoc.getRow()][dstLoc.getCol()]=new Piece(whitePieces[srcLoc]);
    }

    public void delBtnPressed() {
            if(delBtnPressd==true)
            {
                delBtnPressd=false;
                return;
            }
                delBtnPressd=true;
    }
    public boolean delBtnIsPressed()
    {
        return delBtnPressd;
    }
    public void setDelBtnPressed(boolean bool)
    {
        delBtnPressd=bool;
    }
    public void eraseMove(Location location) {
        board[location.getRow()][location.getCol()]=new Piece(' ',"yellow");
    }
    public char getCorrectPieceByNum(String num,boolean isBlackPiece)
    {
        int index=Integer.parseInt(num);
        if(isBlackPiece)
            return blackPieces[index].getPiece();
        return whitePieces[index].getPiece();
    }
    public void createClassicBoard()
    {
        char[][] board=
        {
            {'R','N','B','Q','K','B','N','R'},
            {'P','P','P','P','P','P','P','P'},
            {' ',' ',' ',' ',' ',' ',' ',' '},
            {' ',' ',' ',' ',' ',' ',' ',' '},
            {' ',' ',' ',' ',' ',' ',' ',' '},
            {' ',' ',' ',' ',' ',' ',' ',' '},
            {'p','p','p','p','p','p','p','p'},
            {'r','n','b','q','k','b','n','r'}
        };
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                Location loc=new Location(i, j);
                char piece=board[i][j];
                String color;
                if(board[i][j]>'a'&&board[i][j]<'z')
                {
                    color="WHITE";
                    this.board[i][j]=new Piece(piece,color,loc);
                }
                else
                    if(board[i][j]==' ')
                    {
                        color="WHITE";
                        this.board[i][j]=new Piece(piece,color,loc);
                    }
                    else
                    {
                        color="BLACK";
                        this.board[i][j]=new Piece(piece,color,loc);
                    }
            }
        }
    }
    public ArrayList<Location> getPossibleMove(Location pLoc)
    {
        ArrayList<Location> generateMoves=new ArrayList<Location>();
        switch (getSameColorPiece(board[pLoc.getRow()][pLoc.getCol()].getPiece())) {
            case Pieces.BLACK_QUEEN:  getQueenGenerateMoves(generateMoves, pLoc);
                                      break;
            case Pieces.BLACK_BISHOP: getBishopGenerateMoves(generateMoves, pLoc);
                                      break;
            case Pieces.BLACK_ROOK:   getRookGenerateMoves(generateMoves, pLoc);
                                      break;
            case Pieces.BLACK_PAWN:   getPawnGenerateMoves(generateMoves, pLoc);
                                      break;
            case Pieces.BLACK_KNIGHT:   getKnightGenerateMoves(generateMoves, pLoc);
                                      break;
            case Pieces.BLACK_KING:   getKingGenerateMoves(generateMoves, pLoc);
                                      break;
        }
        return generateMoves;
    }
    private void getQueenGenerateMoves(ArrayList<Location> list, Location pLoc)
    {
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 1);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 2);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 3);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 4);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 5);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 6);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 7);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 8);
        
    }
    private void getBishopGenerateMoves(ArrayList<Location> list, Location pLoc)
    {
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 1);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 2);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 3);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 4);
    }
    private void getRookGenerateMoves(ArrayList<Location> list, Location pLoc)
    {
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 5);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 6);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 7);
        getDiagnolesGenerateMoves2(list, new Location(pLoc), 8);
    }
    private void getDiagnolesGenerateMoves2(ArrayList<Location> list, Location pLoc,int state)
    {
        String cP=board[pLoc.getRow()][pLoc.getCol()].getColor();
        Location newLoc=pLoc;
        while(true)
        {
            newLoc=getCorrectLocationsForDiagnolesGenerateMoves1(list,cP,new Location(newLoc),state);
            if(newLoc==null)
                return;
            list.add(new Location(newLoc));
        }
        
    }
    private Location getCorrectLocationsForDiagnolesGenerateMoves1(ArrayList<Location> list,String cP,Location pLoc,int state)
    {
        if(state==1)//שמאל למעלה
        {
            pLoc.setRow(pLoc.getRow()-1);
            pLoc.setCol(pLoc.getCol()-1);
            if(pLoc.getRow()>=0&&pLoc.getCol()>=0)
            {
                if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
            }
            return null;
        }
        if(state==2)//ימין למטה
        {
            pLoc.setRow(pLoc.getRow()+1);
            pLoc.setCol(pLoc.getCol()+1);
            if(pLoc.getRow()<8&&pLoc.getCol()<8)
            {
                 if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
            }
            return null;
        }
        if(state==3)//ימין למעלה
        {
            pLoc.setRow(pLoc.getRow()-1);
            pLoc.setCol(pLoc.getCol()+1);
            if(pLoc.getRow()>=0&&pLoc.getCol()<8)
            {
                if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
                return null;
            }
            return null;
        }
        if(state==4)//שמאל למטה
        {
            pLoc.setRow(pLoc.getRow()+1);
            pLoc.setCol(pLoc.getCol()-1);
            if(pLoc.getRow()<8&&pLoc.getCol()>=0)
            {
              if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
                return null;
            }
        }
        if(state==5)//שמאלה ישר
        {
            pLoc.setCol(pLoc.getCol()-1);
            if(pLoc.getCol()>=0)
            {
              if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
                return null;
            }
        }
        if(state==6)//ימינה ישר
        {
            pLoc.setCol(pLoc.getCol()+1);
            if(pLoc.getCol()<8)
            {
              if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
                return null;
            }
        }
        if(state==7)//למעלה ישר
        {
            pLoc.setRow(pLoc.getRow()+1);
            if(pLoc.getRow()<8)
            {
              if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
                return null;
            }
        }
        if(state==8)//למטה ישר
        {
            pLoc.setRow(pLoc.getRow()-1);
            if(pLoc.getRow()>=0)
            {
              if(board[pLoc.getRow()][pLoc.getCol()].getPiece()==' ')
                    return pLoc;
                if(!compareColors(cP, board[pLoc.getRow()][pLoc.getCol()].getColor()))
                {
                    list.add(pLoc);
                    return null;
                }
                return null;
            }
        }
        return null;
    }
    private boolean compareColors(String c1,String c2)
    {
        if(c1.equals(c2))
            return true;
        return false;
    }
    private char getSameColorPiece(char piece)
    {
        if(piece>='a' && piece<='z')
            return (char) (piece-'a'+'A');
        return piece;
    }
    //
    private void getPawnGenerateMoves(ArrayList<Location> list,Location pL)
    {
        int r=pL.getRow();
        int c=pL.getCol();
        if(board[r][c].getColor().equals("WHITE"))//רגלי לבן
        {
            if(r-1>=0)
            {
                if(board[r-1][c].getPiece()==' ')
                {
                    list.add(new Location(r-1, c));
                    if(r==6)
                    {
                        if(board[4][c].getPiece()==' ')
                            list.add(new Location(4,c));
                    }
                }
                //אכילה באלכסונים
                for (int i = 0; i < 2; i++) {
                    int c2;
                    if(i==0)
                        c2=c+1;
                    else
                        c2=c-1;
                    if(c2>=0&&c2<8)
                    {
                        if(board[r-1][c2].getPiece()!=' '&&!compareColors(board[r][c].getColor(), board[r-1][c2].getColor()))
                            list.add(new Location(r-1,c2));
                    }
                }
            }
            
        }
        else//רגלי שחור
        {
            if(r+1<8)
            {
                if(board[r+1][c].getPiece()==' ')
                {
                    list.add(new Location(r+1, c));
                    if(r==1)
                    {
                        if(board[3][c].getPiece()==' ')
                            list.add(new Location(3,c));
                    }
                }
                
                //אכילה באלכסונים
                for (int i = 0; i < 2; i++) {
                    int c2;
                    if(i==0)
                        c2=c+1;
                    else
                        c2=c-1;
                    if(c2>=0&&c2<8)
                    {
                        if(board[r+1][c2].getPiece()!=' '&&!compareColors(board[r][c].getColor(), board[r+1][c2].getColor()))
                            list.add(new Location(r+1,c2));
                    }
                }
            }
            
        }
    }
    private void getKnightGenerateMoves(ArrayList<Location> list,Location pL)
    {
        int r=pL.getRow();
        int c=pL.getCol();
        Location[] locs=
        {
            new Location(r+2,c+1),
            new Location(r+2,c-1),
            new Location(r-2,c+1),
            new Location(r-2,c-1),
            new Location(r+1,c+2),
            new Location(r-1,c+2),
            new Location(r+1,c-2),
            new Location(r-1,c-2)
        };
        for (int i = 0; i < locs.length; i++) {
            int r2=locs[i].getRow();
            int c2=locs[i].getCol();
            if(r2<8&&r2>=0&&c2<8&&c2>=0)
                if(!compareColors(board[r][c].getColor(), board[r2][c2].getColor()))
                    list.add(locs[i]);
        }
            
    }
    private void getKingGenerateMoves(ArrayList<Location> list,Location pL)
    {
        int r=pL.getRow();
        int c=pL.getCol();
        Location[] locs=
        {
            new Location(r,c+1),
            new Location(r,c-1),
            new Location(r-1,c),
            new Location(r+1,c),
            new Location(r+1,c+1),
            new Location(r-1,c-1),
            new Location(r+1,c-1),
            new Location(r-1,c+1)
        };
        for (int i = 0; i < locs.length; i++) {
            int r2=locs[i].getRow();
            int c2=locs[i].getCol();
            if(r2<8&&r2>=0&&c2<8&&c2>=0)
                if(!compareColors(board[r][c].getColor(), board[r2][c2].getColor()))
                    if(getSameColorPiece(board[r2][c2].getPiece())!='K')
                        if(!kingIsNearToKing(locs[i], board[pL.getRow()][pL.getCol()].getColor()))
                            list.add(locs[i]);
        }
    }
    private void getKingGenerateNotCompleteMoves(ArrayList<Location> list,Location pL)
    {
        try
        {
        int r=pL.getRow();
        int c=pL.getCol();
        Location[] locs=
        {
            new Location(r,c+1),
            new Location(r,c-1),
            new Location(r-1,c),
            new Location(r+1,c),
            new Location(r+1,c+1),
            new Location(r-1,c-1),
            new Location(r+1,c-1),
            new Location(r-1,c+1)
        };
        for (int i = 0; i < locs.length; i++) {
            int r2=locs[i].getRow();
            int c2=locs[i].getCol();
            if(r2<8&&r2>=0&&c2<8&&c2>=0)
                if(!compareColors(board[r][c].getColor(), board[r2][c2].getColor()))
                    if(getSameColorPiece(board[r2][c2].getPiece())!='K')
                        list.add(locs[i]);
        }
        }
        catch(Exception e){};
    }
    private ArrayList<Location> getAllKingDstLocs(Location king)
    {
        int r=king.getRow();
        int c=king.getCol();
        ArrayList<Location> locs=new ArrayList<Location>();
        locs.add(new Location(r,c+1));
        locs.add(new Location(r,c-1));
        locs.add(new Location(r-1,c));
        locs.add(new Location(r+1,c));
        locs.add(new Location(r+1,c+1));
        locs.add(new Location(r-1,c-1));
        locs.add(new Location(r+1,c-1));
        locs.add(new Location(r-1,c+1));
        for (int i = 0; i < locs.size(); i++) {
            if(!(r<8&&r>=0&&c<8&&c>=0))
            {
                locs.remove(i);
                i--;
            }
        }
        return locs;
    }
    private boolean kingIsNearToKing(Location loc,String sign)
    {
        ArrayList<Location> validPositionForKing=new ArrayList<Location>();
        Location kingOpLoc=getKingLoc(getOponentSign(sign));
        if(kingOpLoc!=null)
        {
            validPositionForKing=getAllKingDstLocs(getKingLoc(getOponentSign(sign)));
            for (int i = 0; i < validPositionForKing.size(); i++) {
                int j=validPositionForKing.get(i).getRow();
                int k=validPositionForKing.get(i).getCol();
                if(validPositionForKing.get(i).equalsLocations(loc))
                    return true;
            }
        }
        return false;
    }
    private String getOponentSign(String sign)
    {
        if(sign.equals("WHITE"))
            return "BLACK";
        return "WHITE";
    }
    private Location getAnyKingLocation()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(board[i][j].getPiece()=='k'||board[i][j].getPiece()=='K')
                    return new Location(i,j);
            }
        }
        return null;
    }
    //בדיקת איום על כלי כלי שנרצה
    //Run time - O(n^2*posMovs)
    //---------------------------------------------------------------
    public boolean checkOnPiece(Location anyPieceLoc)
    {
        if(anyPieceLoc==null)
            return false;
        ArrayList<Location> validMoves=new ArrayList<Location>();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                validMoves=getPossibleMove(new Location(i,j));
                for (int k = 0; k < validMoves.size(); k++) {
                    if(validMoves.get(k).equalsLocations(anyPieceLoc))
                        return true;
                }
            }
        }
        return false;
    }
    public String checkValidState()
    {
        String msgValidtion;
        if(validPiecesOnBoard()!=-1)
            return TalkingBot.notCorrectKingNumbers;
        if(onlyKingsonBoard())
            return TalkingBot.pat;
        msgValidtion=checkStateGameForBoth();
        if(!msgValidtion.isEmpty())
            return msgValidtion;
        return TalkingBot.normalState;
    }
    private boolean onlyKingsonBoard()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(board[i][j].getPiece()!=' '&&getSameColorPiece(board[i][j].getPiece())!='K')
                    return false;
            }
        }
        return true;
    }
    private ArrayList<Move> getAllGenrateMoves(String current)
    {
        try
        {
            ArrayList<Location> genrateMovesForPiece=new ArrayList<Location>();
            ArrayList<Move> allGenrateMoves=new ArrayList<Move>();
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if(board[i][j].getPiece()!=' ' && board[i][j].getColor().equals(current))//משבצת לא ריקה ומאותו צבע
                    {
                        genrateMovesForPiece=getPossibleMove(new Location(i,j));
                        for (int k = 0; k < genrateMovesForPiece.size(); k++) {
                            Piece srP=new Piece(board[i][j]);
                            Piece dsP=new Piece(board[genrateMovesForPiece.get(k).getRow()][genrateMovesForPiece.get(k).getCol()]);
                            Move move=new Move(new Location(i,j),new Location(genrateMovesForPiece.get(k)),srP,dsP);
                            doMove(move);
                            if(checkOnPiece(getKingLoc(current)))
                            {
                                genrateMovesForPiece.remove(k);
                                k--;
                            }
                            else
                                allGenrateMoves.add(move);
                            unMakeMove(move);
                        }
                    }
                }
            }
            return allGenrateMoves;
        }
        catch(Exception e)
        {
            return null;
        }
    }
    private void unMakeMove(Move move)
    {
        int sI=move.getSrcLoc().getRow();
        int sJ=move.getSrcLoc().getCol();
        int dI=move.getDstLoc().getRow();
        int dJ=move.getDstLoc().getCol();
        board[sI][sJ]=new Piece(move.getSrcPiece());
        board[dI][dJ]=new Piece(move.getDstPiece());
    }
    private Location getKingLoc(String sign)
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(getSameColorPiece(board[i][j].getPiece())=='K' && board[i][j].getColor().equals(sign))
                    return new Location(i,j);
            }
        }
        return null;
    }
    private int validPiecesOnBoard()
    {
        int mountOfWhiteKings=0;
        int mountOfBlackKings=0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(board[i][j].getPiece()=='k')
                    mountOfWhiteKings++;
                else
                    if(board[i][j].getPiece()=='K')
                        mountOfBlackKings++;
            }
        }
        if(mountOfBlackKings!=1)
            return 0;
        if(mountOfWhiteKings!=1)
            return 1;
        return -1;
    }
    private String checkStateGameForBoth()
    {
        ArrayList<Move> allPossibleMovesForBlack=getAllGenrateMoves("BLACK");
        ArrayList<Move> allPossibleMovesForWhite=getAllGenrateMoves("WHITE");
        String state="";
            
        if(allPossibleMovesForWhite!=null && allPossibleMovesForWhite.isEmpty() || allPossibleMovesForWhite==null)
        {
            if(checkOnPiece(getKingLoc("WHITE")))
                state = TalkingBot.checkMateOnWhite;
            else
                state = TalkingBot.patOnWhite;
        }
        else
            if(checkOnPiece(getKingLoc("WHITE")))
            {
                state=TalkingBot.checkOnWhite;
            }
        if(allPossibleMovesForBlack!=null && allPossibleMovesForBlack.isEmpty())
        {
            if(checkOnPiece(getKingLoc("BLACK")))
            {
                if(!state.isEmpty())
                    return TalkingBot.notValid;
                return TalkingBot.checkMateOnBlack;
            }
            else
                if(!state.isEmpty())
                {
                    return TalkingBot.notValid;
                }
            return TalkingBot.patOnBlack;
           
                
        }
        else
            if(checkOnPiece(getKingLoc("BLACK")))
            {
                if(!state.isEmpty())
                {
                    return TalkingBot.notValid;
                }
                state=TalkingBot.checkOnBlack;
            }
        return state;
    }
    
    public ArrayList<Location> getGenratePossibleMove(Location pLoc) {
        ArrayList<Location> genrateLocsForPiece=new ArrayList<Location>();
        ArrayList<Location> genratePLocs=getPossibleMove(pLoc);
        ArrayList<Move> allGenrateMoves=getAllGenrateMoves(board[pLoc.getRow()][pLoc.getCol()].getColor());
        for (int i = 0; i < allGenrateMoves.size(); i++) {
            for (int j = 0; j < genratePLocs.size(); j++) {
                if(allGenrateMoves.get(i).getSrcLoc().equalsLocations(pLoc)&&
                   allGenrateMoves.get(i).getDstLoc().equalsLocations(genratePLocs.get(j)))
                   genrateLocsForPiece.add(allGenrateMoves.get(i).getDstLoc());
            }
        }
        return genrateLocsForPiece;
    }
    public ArrayList<Location> getAllDefanderPiecesLocs(String sign)
    {
        ArrayList<Location> defanderLocs=new ArrayList<Location>();
        if(checkOnPiece(getKingLoc(sign)))
        {
            ArrayList<Move> allGenMvs=getAllGenrateMoves(sign);
            for (int i = 0; i < allGenMvs.size(); i++) {
                int r=allGenMvs.get(i).getSrcLoc().getRow();
                int c=allGenMvs.get(i).getSrcLoc().getCol();
                if(getSameColorPiece(board[r][c].getPiece())!='K')
                    defanderLocs.add(allGenMvs.get(i).getSrcLoc());
            }
        }
        return defanderLocs;
    }
}
