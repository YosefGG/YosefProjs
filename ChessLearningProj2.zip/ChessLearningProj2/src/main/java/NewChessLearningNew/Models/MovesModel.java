package NewChessLearningNew.Models;

import java.util.ArrayList;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="MovesModels")
public class MovesModel {
    @Id
    private String nameOfMove;
    private ArrayList<Move> moves; 
    private Piece[][] openingBoard;
    private int lastIndex;
    private String msg;
    public MovesModel()
    {
        nameOfMove=" ";
        moves=new ArrayList<Move>();
        openingBoard=new Piece[8][8];
        createEmptyBoard();
    }
    public MovesModel(ArrayList<Move> moves,Piece[][] openingBoard,String msg) {
        lastIndex=0;
        this.moves=moves;
        this.openingBoard=new Piece[8][8];
        cpyBoard(openingBoard);
        this.msg=msg;
    }
    public MovesModel(ArrayList<Move> moves,Piece[][] openingBoard,String msg,String nameOfMove) {
        this.nameOfMove=nameOfMove;
        lastIndex=0;
        this.moves=moves;
        this.openingBoard=new Piece[8][8];
        cpyBoard(openingBoard);
        this.msg=msg;
    }
    public MovesModel(MovesModel movesModel)
    {
        openingBoard=new Piece[8][8];
        moves=movesModel.moves;
        cpyBoard(movesModel.openingBoard);
    }
    public String getMoveName()
    {
        return nameOfMove;
    }
    private void cpyBoard(Piece[][] board) 
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                this.openingBoard[i][j]=new Piece(board[i][j]);
            }
        }
    }
    private void createEmptyBoard()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                openingBoard[i][j]=new Piece(' '," ");
            }
        }
    }
    public Move getForWardMove()
    {
        Move moveToGet=null;
        if(lastIndex<moves.size())
            moveToGet=moves.get(lastIndex);
        if(lastIndex+1<=moves.size())
            lastIndex++;
        return moveToGet;
    }
    public Move getPrevMove()
    {
        Move prevMove=null;
        if(lastIndex>0)
        {
            prevMove=moves.get(lastIndex-1);
            lastIndex--;
        }
        return prevMove;
    }
    public Piece[][] getOpeningBoard()
    {
        return openingBoard;
    }

    public String getNameOfMove() {
        return nameOfMove;
    }

    public void setNameOfMove(String nameOfMove) {
        this.nameOfMove = nameOfMove;
    }

    public ArrayList<Move> getMoves() {
        return moves;
    }

    public void setMoves(ArrayList<Move> moves) {
        this.moves = moves;
    }

    public int getLastIndex() {
        return lastIndex;
    }

    public void setLastIndex(int lastIndex) {
        this.lastIndex = lastIndex;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "MovesModel{" + "nameOfMove=" + nameOfMove + ", moves=" + moves + ", openingBoard=" + openingBoard + ", lastIndex=" + lastIndex + ", msg=" + msg + '}';
    }
    
}
