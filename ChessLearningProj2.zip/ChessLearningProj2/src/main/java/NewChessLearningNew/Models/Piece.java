package NewChessLearningNew.Models;

public class Piece {
    private char piece;
    private String color;
    Location loc;
    public Piece()
    {
        
    }

    public Piece(char piece, String color, Location loc) {
        
        this.piece = piece;
        this.color = color;
        this.loc = new Location(loc);
        fixPiece();
    }
    
    public Piece(char piece,String color)
    {
        this.piece=piece;
        this.color=color;
        fixPiece();
    }
    public Piece(Piece piece) {
        if(piece!=null)
        {
            this.piece=piece.piece;
            color=piece.color;
            fixPiece();
        }
        
    }


    public char getPiece() {
        return piece;
    }

    public void setPiece(char piece) {
        this.piece = piece;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Location getLoc() {
        return loc;
    }

    public void setLoc(Location loc) {
        this.loc = loc;
    }
    
    public boolean equals(Piece piece)
    {
        return piece.piece==this.piece;
    }
    private void fixPiece()
    {
        if(piece>'A'&&piece<'Z'&&color.equals("WHITE"))
            piece=(char)(piece-'A'+'a');
        if(piece>'a'&&piece<'z'&&color.equals("BLACK"))
            piece=(char)(piece-'a'+'A');
    }
    @Override
    public String toString() {
        return "Piece{" + "piece=" + piece + ", color=" + color +", Location= " + loc + '}';
    }
    
}
