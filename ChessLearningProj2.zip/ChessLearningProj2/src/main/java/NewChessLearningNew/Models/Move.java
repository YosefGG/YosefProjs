package NewChessLearningNew.Models;





public class Move{
    private Location srcLoc;
    private Location dstLoc;
    private Piece srcPiece;
    private Piece dstPiece;
    private char pieceChange;
    public Move()
    {
        
    }

    public Move(Location srcLoc, Location dstLoc, Piece srcPiece, Piece dstPiece, char pieceChange) {
        this.srcLoc = srcLoc;
        this.dstLoc = dstLoc;
        this.srcPiece = srcPiece;
        this.dstPiece = dstPiece;
        this.pieceChange = pieceChange;
    }
    
    public Move(Location srcLoc, Location dstLoc, Piece srcPiece, Piece dstPiece) {
        pieceChange=' ';
        this.srcLoc = srcLoc;
        this.dstLoc = dstLoc;
        this.srcPiece = srcPiece;
        this.dstPiece = dstPiece;
    }
    public Move(Location srcLoc, Location dstLoc) {
        pieceChange=' ';
        this.srcLoc = new Location(srcLoc);
        this.dstLoc = new Location(dstLoc);
    }
    Move(Move moveToGet) {
        pieceChange=moveToGet.pieceChange;
        this.srcLoc=new Location(moveToGet.getSrcLoc());
        this.dstLoc=new Location(moveToGet.getDstLoc());
        this.srcPiece=new Piece(moveToGet.getSrcPiece());
        this.dstPiece=new Piece(moveToGet.getDstPiece());
    }
    

    public Location getSrcLoc() {
        return srcLoc;
    }

    public void setSrcLoc(Location srcLoc) {
        this.srcLoc = srcLoc;
    }

    public Location getDstLoc() {
        return dstLoc;
    }

    public void setDstLoc(Location dstLoc) {
        this.dstLoc = dstLoc;
    }

    public Piece getSrcPiece() {
        return srcPiece;
    }

    public void setSrcPiece(Piece srcPiece) {
        this.srcPiece = srcPiece;
    }

    public Piece getDstPiece() {
        return dstPiece;
    }

    public void setDstPiece(Piece dstPiece) {
        this.dstPiece = dstPiece;
    }

    public char getPieceChange() {
        return pieceChange;
    }

    public void setPieceChange(char pieceChange) {
        this.pieceChange = pieceChange;
    }
    
    @Override
    public String toString() {
        return "Move{" + "srcLoc=" + srcLoc + ", dstLoc=" + dstLoc + ", srcPiece=" + srcPiece + ", dstPiece=" + dstPiece + '}';
    }
    
    
}
