package NewChessLearningNew.Models;
public class TalkingBot {
    public static final String checkMateOnWhite="There is check mate on king white!";
    public static final String checkMateOnBlack="There is check mate on king black!";
    public static final String patOnWhite="White can't move!\nThere is pat!";
    public static final String patOnBlack="White can't move!\nThere is pat!";
    public static final String pat="Only kings on board!\nThere is pat!";
    public static final String checkOnWhite="There is check on white king!";
    public static final String checkOnBlack="There is check on black king!";
    public static final String notValid="Not valid position!";
    public static final String notCorrectKingNumbers="Num of each king is 1!";
    public static final String normalState="The state is normal and ready to play!";
    
}
