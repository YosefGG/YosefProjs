package NewChessLearningNew;

import com.vaadin.flow.component.page.AppShellConfigurator;
import com.vaadin.flow.component.page.Push;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"NewChessLearningNew.*","NewChessLearningNew.Models.*","NewChessLearningNew.Repositories.*","NewChessLearningNew.Run.*","NewChessLearningNew.Services.*","NewChessLearningNew.Views.*","assets"})
//@RestController
@Push
public class ChessApplication implements AppShellConfigurator
{                 
    public static void main(String[] args) {
        SpringApplication.run(ChessApplication.class, args);
        System.out.println("ChessApplication running...");
    }                              
     
//    @RequestMapping("/testing")
//    public String button("/button")
//    {
//        return new Button("Hey");
//    }

}
