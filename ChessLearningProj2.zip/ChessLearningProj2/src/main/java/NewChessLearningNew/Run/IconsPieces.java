package NewChessLearningNew.Run;

import com.vaadin.flow.component.html.Image;

public class IconsPieces {
    private Image WHITE_PAWN;
    private Image WHITE_ROOK;
    private Image WHITE_KNIGHT;
    private Image WHITE_BISHOP;
    private Image WHITE_QUEEN;
    private Image WHITE_KING;
    private Image BLACK_PAWN;
    private Image BLACK_ROOK;
    private Image BLACK_KNIGHT;
    private Image BLACK_BISHOP;
    private Image BLACK_QUEEN;
    private Image BLACK_KING;
    private Image EMPTY_SIGN;
    private final int width=35;
    private final int height=35;
    public IconsPieces()
    {
        WHITE_PAWN=loadImage("imgs/pwanWhite.jpg", width, height);
        WHITE_ROOK=loadImage("imgs/rookWhite.jpg", width, height);
        WHITE_KNIGHT=loadImage("imgs/knightWhite.jpg", width, height);
        WHITE_BISHOP=loadImage("imgs/bishopWhite.jpg", width, height);
        WHITE_QUEEN=loadImage("imgs/queenWhite.jpg", width, height);
        WHITE_KING=loadImage("imgs/kingWhite.jpg", width, height);
        BLACK_PAWN=loadImage("imgs/pwanblack.jpg", width, height);
        BLACK_ROOK=loadImage("imgs/rookBlack.jpg", width, height);
        BLACK_KNIGHT=loadImage("imgs/knightBlack.jpg", width, height);
        BLACK_BISHOP=loadImage("imgs/bishopBlack.jpg", width, height);
        BLACK_QUEEN=loadImage("imgs/queenBlack.jpg", width, height);
        BLACK_KING=loadImage("imgs/kingBlack.jpg", width, height);
        EMPTY_SIGN=loadImage("imgs/Empty.jpg", width, height);
    }
    private Image loadImage(String path,int width,int height)
    {
        Image img=new Image(path,"HEY");
        img.setWidth(width+"px");
        img.setWidth(height+"px");
        return img;
    }
    
    public Image getWHITE_PAWN() {
        return WHITE_PAWN;
    }

    public Image getWHITE_ROOK() {
        return WHITE_ROOK;
    }

    public Image getWHITE_KNIGHT() {
        return WHITE_KNIGHT;
    }

    public Image getWHITE_BISHOP() {
        return WHITE_BISHOP;
    }

    public Image getWHITE_QUEEN() {
        return WHITE_QUEEN;
    }

    public Image getWHITE_KING() {
        return WHITE_KING;
    }

    public Image getBLACK_PAWN() {
        return BLACK_PAWN;
    }

    public Image getBLACK_ROOK() {
        return BLACK_ROOK;
    }

    public Image getBLACK_KNIGHT() {
        return BLACK_KNIGHT;
    }

    public Image getBLACK_BISHOP() {
        return BLACK_BISHOP;
    }

    public Image getBLACK_QUEEN() {
        return BLACK_QUEEN;
    }

    public Image getBLACK_KING() {
        return BLACK_KING;
    }

    public Image getEMPTY_SIGN() {
        return getApropatePiece(Pieces.EMPTY_SIGN);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
    public Image getApropatePiece(char piece)
    {
        switch (piece) {
            case Pieces.WHITE_PAWN:return loadImage(WHITE_PAWN.getSrc(), width, height);
                    case Pieces.WHITE_ROOK:return loadImage(WHITE_ROOK.getSrc(), width, height);
                        
                    case Pieces.WHITE_KNIGHT:return  loadImage(WHITE_KNIGHT.getSrc(), width, height);

                    case Pieces.WHITE_BISHOP:return loadImage(WHITE_BISHOP.getSrc(), width, height);

                    case Pieces.WHITE_KING:return loadImage(WHITE_KING.getSrc(), width, height);

                    case Pieces.WHITE_QUEEN:return loadImage(WHITE_QUEEN.getSrc(), width, height);

                    case Pieces.BLACK_PAWN:return loadImage(BLACK_PAWN.getSrc(), width, height);

                    case Pieces.BLACK_ROOK:return loadImage(BLACK_ROOK.getSrc(), width, height);

                    case Pieces.BLACK_KNIGHT:return loadImage(BLACK_KNIGHT.getSrc(), width, height);

                    case Pieces.BLACK_BISHOP:return loadImage(BLACK_BISHOP.getSrc(), width, height);

                    case Pieces.BLACK_KING:return loadImage(BLACK_KING.getSrc(), width, height);

                    case Pieces.BLACK_QUEEN:return loadImage(BLACK_QUEEN.getSrc(), width, height);
                    
                    case Pieces.EMPTY_SIGN:return loadImage(EMPTY_SIGN.getSrc(), width,height);
        }
        return null;
    }
        
}
