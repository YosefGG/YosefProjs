package NewChessLearningNew.Run;

import com.vaadin.flow.component.orderedlayout.VerticalLayout;

public class Panel extends VerticalLayout{
     public Panel() {
    }
    
}
