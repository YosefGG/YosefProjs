package NewChessLearningNew.Views;

import NewChessLearningNew.Models.User;
import NewChessLearningNew.Models.UserMovesModelSize;
import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.server.startup.VaadinAppShellInitializer;
import java.util.ArrayList;

@Route("/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules")
public class StudyRules extends VerticalLayout{
    private Button pawn;
    private Button rook;
    private Button knight;
    private Button bishop;
    private Button queen;
    private Button king;
    private Button backWardPage;
    private H1 title;
    private UserService service;
    
    public StudyRules(UserService service) {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        this.service=service;
        Icon icon=new Icon(VaadinIcon.REPLY);
        icon.getStyle().set("height", 50+"px");
        icon.getStyle().set("width",50+"px");
        backWardPage=new Button(icon);
        title=new H1("Learning Rules");
        pawn=new Button(loadImage("imgs/pawn.jpg","100"));
        rook=new Button(loadImage("imgs/rook.jpg","100"));
        knight=new Button(loadImage("imgs/horse.jpg","100"));
        bishop=new Button(loadImage("imgs/bishop.jpg","100"));
        queen=new Button(loadImage("imgs/queen.jpg","100"));
        king=new Button(loadImage("imgs/crown.jpg","100"));
        setSizeForButtons(250, 250);
        this.getStyle().set("background","gray");
        handleClickLisetner();
        showStudyProceed();
        add(title,backWardPage,new HorizontalLayout(pawn,rook),new HorizontalLayout(knight,bishop),new HorizontalLayout(queen,king));
        this.setAlignItems(Alignment.CENTER);
    }
    private Image loadImage(String path,String size)
    {
        Image img=new Image(path,"");
        img.setHeight(size+"px");
        img.setWidth(size+"px");
        return img;
    }
    private void setSizeForButtons(int height,int width)
    {
        backWardPage.setHeight(height+"px");
        backWardPage.setWidth(width+"px");
        pawn.setHeight(height+"px");
        pawn.setWidth(width+"px");
        rook.setHeight(height+"px");
        rook.setWidth(width+"px");
        knight.setHeight(height+"px");
        knight.setWidth(width+"px");
        bishop.setHeight(height+"px");
        bishop.setWidth(width+"px");
        queen.setHeight(height+"px");
        queen.setWidth(width+"px");
        king.setHeight(height+"px");
        king.setWidth(width+"px");
        
    }

    private void handleClickLisetner() {
        backWardPage.addClickListener(t->{
            backWardPage.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView"));
        });
        pawn.addClickListener(t->{
            pawn.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules/pawn"));
        });
        rook.addClickListener(t->{
            rook.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules/rook"));
        });
        knight.addClickListener(t->{
            knight.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules/knight"));
        });
        bishop.addClickListener(t->{
            bishop.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules/bishop"));
        });
        queen.addClickListener(t->{
            queen.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules/queen"));
        });
        king.addClickListener(t->{
            king.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules/king"));
        });
    }
     private void showStudyProceed()
    {
        User cUser=service.getUserById(VaadinSession.getCurrent().getAttribute("UserName").toString());
        int pawn=0;
        int rook=0;
        int knight=0;
        int bishop=0;
        int queen=0;
        int king=0;
        ArrayList<UserMovesModelSize> moves=cUser.getMaxIndexsOfMovesModel();
        for (int i = 0; i < 4; i++) {
            UserMovesModelSize moveSize=moves.get(i);
            pawn+=moves.get(i).getProccedInfo();
        }
        pawn/=4;
        
        for (int i = 4; i < 7; i++) {
            UserMovesModelSize moveSize=moves.get(i);
            rook+=moves.get(i).getProccedInfo();
        }
        rook/=3;
        
        for (int i = 7; i < 10; i++) {
            UserMovesModelSize moveSize=moves.get(i);
            queen+=moves.get(i).getProccedInfo();
        }
        queen/=3;
        
        for (int i = 10; i < 13; i++) {
            UserMovesModelSize moveSize=moves.get(i);
            knight+=moves.get(i).getProccedInfo();
        }
        knight/=3;
        
        for (int i = 13; i < 16; i++) {
            UserMovesModelSize moveSize=moves.get(i);
            bishop+=moves.get(i).getProccedInfo();
        }
        bishop/=3;
        
        for (int i = 16; i < 21; i++) {
            UserMovesModelSize moveSize=moves.get(i);
            king+=moves.get(i).getProccedInfo();
        }
        king/=5;
        
        this.pawn.setText(pawn+"%");
        this.rook.setText(rook+"%");
        this.knight.setText(knight+"%");
        this.bishop.setText(bishop+"%");
        this.queen.setText(queen+"%");
        this.king.setText(king+"%");
    }
}
