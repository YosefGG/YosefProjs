package NewChessLearningNew.Views;

import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;

@Route("login/ChoiceOfBoardOrMoves")
public class ChoiceOfBoardOrMovesVIew extends VerticalLayout
{
    private H1 title;
    private Button boardBtn;
    private Button movesBtn;
    private Button gridServiceBtn;
    private Button backWardPage;
    
    public ChoiceOfBoardOrMovesVIew(UserService service)
    {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        gridServiceBtn=new Button("Users service");
        Icon icon=new Icon(VaadinIcon.REPLY);
        icon.getStyle().set("height", 50+"px");
        icon.getStyle().set("width",50+"px");
        backWardPage=new Button(icon);
        HorizontalLayout fixButtonsLayout=new HorizontalLayout();
        title=new H1("Learn choice");
        boardBtn=new Button("Go to design board");
        movesBtn=new Button("Go to learn moves");
        this.getStyle().set("background","cyan");
        setStyleForComponents();
        addClickListenerForComponents();
        setAlignItems(FlexComponent.Alignment.CENTER);
        if((service.getUserById((String) VaadinSession.getCurrent().getAttribute("UserName"))).isAdmin())
            fixButtonsLayout.add(boardBtn,movesBtn,gridServiceBtn);
        else
            fixButtonsLayout.add(boardBtn,movesBtn);
        setSizeOfButtons(100, 300);
        setFontSizesOfButtons(30);
        
        add(title,backWardPage,getImageForBackGround(),fixButtonsLayout);
        fixButtonsLayout.setAlignItems(Alignment.CENTER);
    }
    private Image getImageForBackGround()
    {
        Image img=new Image("imgs/caseChessIcon.jpg","");
        img.setHeight(100+"px");
        img.setWidth(100+"px");
        return img;
    }
    private void setStyleForComponents() {
        title.getStyle().set("color", " green");
        boardBtn.getStyle().set("background-color","green");
        boardBtn.getStyle().set("color"," white");
        movesBtn.getStyle().set("background-color","green");
        movesBtn.getStyle().set("color"," white");
        gridServiceBtn.getStyle().set("background-color","green");
        gridServiceBtn.getStyle().set("color"," white");
    }
    private void setSizeOfButtons(int height,int width)
    {
        boardBtn.setHeight(height+"px");
        boardBtn.setWidth(width+"px");
        movesBtn.setHeight(height+"px");
        movesBtn.setWidth(width+"px");
        gridServiceBtn.setHeight(height+"px");
        gridServiceBtn.setWidth(width+"px");
        
    }
    private void setFontSizesOfButtons(int size)
    {
        boardBtn.getStyle().set("font-size",size+"px");
        movesBtn.getStyle().set("font-size",size+"px");
        gridServiceBtn.getStyle().set("font-size",size+"px");
    }
    private void addClickListenerForComponents()
    {
        gridServiceBtn.addClickListener((t) -> {
            gridServiceBtn.getUI().ifPresent(ui->ui.navigate("http://localhost:8080/login/GridServiceForMongoView"));
        });
        backWardPage.addClickListener((t) -> {
            backWardPage.getUI().ifPresent(ui->ui.navigate("http://localhost:8080/"));
        });
        boardBtn.addClickListener((t) -> {
            UI.getCurrent().navigate(BoardDesignView.class);
        });
        movesBtn.addClickListener((t) -> {
            movesBtn.getUI().ifPresent(ui->ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView"));
        });
    }
}
