package NewChessLearningNew.Views;

import NewChessLearningNew.Models.User;
import NewChessLearningNew.Models.UserMovesModelSize;
import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import java.util.ArrayList;

@Route("/login/ChoiceOfBoardOrMoves/studyChoiceView")
public class StudyChoiceView extends VerticalLayout{
    private H1 title;
    private Button study_Game;
    private Button learn_Openings;
    private Button grandMasters_Moves;
    private Button end_Games;
    private Button backWardPage;
    private UserService service;
    public StudyChoiceView(UserService service) {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        this.service=service;
        Icon icon=new Icon(VaadinIcon.REPLY);
        icon.getStyle().set("height", 50+"px");
        icon.getStyle().set("width",50+"px");
        backWardPage=new Button(icon);
        title=new H1();
        study_Game=new Button("Study Rules");
        learn_Openings=new Button("Openings");
        grandMasters_Moves=new Button("Grand Masters Games");
        end_Games=new Button("End Games");
        handleButtonsClicked();
        setSizeForButtons(200, 500);
        setBorderForButtons("inset");
        setColorForButtons("black");
        setFontSizeForButtons(30);
        setIconForTitle(200, 200);
        showStudyProceed();
        this.getStyle().set("background","gray");
        add(title,backWardPage,study_Game,learn_Openings,grandMasters_Moves,end_Games); 
        setAlignItems(Alignment.CENTER);
    }
    private void setIconForTitle(int height,int width)
    {
        Image img=new Image("imgs/studyIcon.jpg"," ");
        img.setHeight(height+"px");
        img.setWidth(width+"px");
        title.add(img);
    }
    
    //--------------------------------------------------------------------------------------------------------------------------------------------------
    //Open pages for it!!!!!!!
    private void handleButtonsClicked() {
         backWardPage.addClickListener((t) -> {
            backWardPage.getUI().ifPresent(ui->ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves"));
        });
        study_Game.addClickListener(t->{
            study_Game.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules"));
        });
        learn_Openings.addClickListener(t->{
            learn_Openings.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/openings"));
        });
        grandMasters_Moves.addClickListener(t->{
            grandMasters_Moves.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/grandMastersGames"));
        });
        end_Games.addClickListener(t->{
            end_Games.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/endGames"));
        });
        
    }
    private void setSizeForButtons(int height,int width)
    {
        study_Game.setHeight(height+"px");
        study_Game.setWidth(width+"px");
        learn_Openings.setHeight(height+"px");
        learn_Openings.setWidth(width+"px");
        grandMasters_Moves.setHeight(height+"px");
        grandMasters_Moves.setWidth(width+"px");
        end_Games.setHeight(height+"px");
        end_Games.setWidth(width+"px");
    }
    private void setFontSizeForButtons(int size)
    {
        study_Game.getStyle().set("font-size",size+"px");
        learn_Openings.getStyle().set("font-size",size+"px");
        grandMasters_Moves.getStyle().set("font-size",size+"px");
        end_Games.getStyle().set("font-size",size+"px");
    }
    private void setBorderForButtons(String border)
    {
        study_Game.getStyle().set("border-style",border);
        learn_Openings.getStyle().set("border-style",border);
        grandMasters_Moves.getStyle().set("border-style",border);
        end_Games.getStyle().set("border-style",border);
        study_Game.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        learn_Openings.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        grandMasters_Moves.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        end_Games.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
    }
    private void setColorForButtons(String color)
    {
        study_Game.getStyle().set("background",color);
        learn_Openings.getStyle().set("background",color);
        grandMasters_Moves.getStyle().set("background",color);
        end_Games.getStyle().set("background",color);   
    }
    private void showStudyProceed()
    {
        User cUser=service.getUserById(VaadinSession.getCurrent().getAttribute("UserName").toString());
        int rulesScore=0;
        int openingsScore=0;
        int grandMastersScore=0;
        int endGamesScore=0;
        ArrayList<UserMovesModelSize> moves=cUser.getMaxIndexsOfMovesModel();
        //rules
        for (int i = 0; i < 21; i++) {
            UserMovesModelSize moveSize=moves.get(i);
            rulesScore+=moveSize.getProccedInfo();
        }
        rulesScore/=21;
        
        //openings
        for (int i = 21; i < 28; i++) {
            openingsScore+=moves.get(i).getProccedInfo();
        }
        openingsScore/=7;
        
        //grandMasters
        for (int i = 28; i < 32; i++) {
            grandMastersScore+=moves.get(i).getProccedInfo();
        }
        grandMastersScore/=4;
        
        //endGames
        for (int i = 32; i < moves.size(); i++) {
            endGamesScore+=moves.get(i).getProccedInfo();
        }
        endGamesScore/=12;
        study_Game.setText(study_Game.getText()+" "+rulesScore+"%");
        learn_Openings.setText(learn_Openings.getText()+" "+openingsScore+"%");
        grandMasters_Moves.setText(grandMasters_Moves.getText()+" "+grandMastersScore+"%");
        end_Games.setText(end_Games.getText()+" "+endGamesScore+"%");
    }
    
}
