package NewChessLearningNew.Views;

import NewChessLearningNew.Models.User;
import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
@Route("signUp")
public class SignUpView extends VerticalLayout{
    private UserService service;
    private TextField un;
    private TextField pw;
    private Button trBtn;
    private Button stBtn;
    private Button signUpBtn;
    private boolean statusUserClicked;
    private H1 title;
    private Button login;
    public SignUpView(UserService service)
    {
        statusUserClicked=false;
        this.service=service;
        title=new H1("Sign up page");
        login=new Button("Log in");
        un=new TextField("Enter user name");
        pw=new TextField("Enter password 6-10 characthers with no space!");
        signUpBtn=new Button("Sign me!");
        trBtn=new Button("I'm a teacher!");
        stBtn=new Button("I'm a student!");
        handleButtonsClickListener();
        add(title,un,pw,trBtn,stBtn,new HorizontalLayout(signUpBtn,login));
        setAlignItems(Alignment.CENTER);
    }
    private void handleButtonsClickListener()
    {
         trBtn.addClickListener((t) -> {
            trBtn.setText("I'm a teacher!, (Clickd!)");
            stBtn.setText("I'm a student!");
            statusUserClicked=true;
        });
        stBtn.addClickListener((t) -> {
            trBtn.setText("I'm a teacher!");
            stBtn.setText("I'm a student!, (Clickd!)");
            statusUserClicked=true;
        });
        signUpBtn.addClickListener((t) -> {
            checkPasswordAndUserName();
            checkStatusUser();
        });
        login.addClickListener(t->{
            login.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login"));
        });
    }
    private void checkPasswordAndUserName() {
        if(pw!=null)
        {
            boolean thereIsPwProblem=false;
            String pwVal=pw.getValue();
            if(pwVal.length()<6)
            {
                Notification.show("Password lentgh is smaller then 6 please enter other password!",4000,Notification.Position.MIDDLE);
                thereIsPwProblem=true;
            }
            else
                if(pwVal.length()>10)
                {
                    Notification.show("Password lentgh is bigger then 10 please enter other password!",4000,Notification.Position.MIDDLE);
                    thereIsPwProblem=true;
                }
            if(pwVal.indexOf(" ")>-1)
            {
                Notification.show("Remove space charecther please!",4000,Notification.Position.MIDDLE);
                thereIsPwProblem=true;
            }
            if(!thereIsPwProblem && statusUserClicked)
            {
                try
                {
                    boolean isTeacher=false;
                    if(trBtn.getText().length()>17)
                        isTeacher=true;
                    if(service.addUser(new User(un.getValue(),pw.getValue(),"",isTeacher)))
                    {
                        Notification.show("Nice!\nYou've sign up successfully!\nWe loading the page for you!",4000,Notification.Position.MIDDLE);
                        VaadinSession.getCurrent().setAttribute("UserName", un.getValue());
                        signUpBtn.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves"));
                    }
                    else
                        Notification.show("There is already user name called "+un.getValue()+"!\nPlease try another user name.");
                }
                catch(RuntimeException e)
                {
                    Notification.show("User not added!\nPlease try again!");
                }
            }
            
            
        }
    }

    private void checkStatusUser() {
        if(!statusUserClicked)
            Notification.show("Enter your status user!",4000,Notification.Position.MIDDLE);
    }
}
