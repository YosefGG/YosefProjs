package NewChessLearningNew.Views;

import NewChessLearningNew.Models.BoardDesign;
import NewChessLearningNew.Models.Location;
import NewChessLearningNew.Models.Move;
import NewChessLearningNew.Models.Piece;
import NewChessLearningNew.Models.TalkingBot;
import NewChessLearningNew.Run.IconsPieces;
import NewChessLearningNew.Run.Pieces;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import java.util.ArrayList;
@Route("/login/ChoiceOfBoardOrMoves/boardDesign")
public class BoardDesignView extends VerticalLayout implements HasUrlParameter<String>{
    private Button[] blackPieces;
    private Button[] whitePieces;
    private Button[][] board;
    private BoardDesign boardModel;
    private Button resetBoardBtn;
    private Button delPieceBtn;
    private IconsPieces icons;
    private Button backWardPage;
    private Button backToMovesView;
    private String nameOfMove;
    private Button navBackToMovesView;
    private int lastIndex;
    private Button showRules;
    private ArrayList<Location> generateMoves;
    private VerticalLayout explainPnl;
    private TextArea explains;
    public BoardDesignView()
    {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        explains=new TextArea();
        explainPnl=new VerticalLayout();
        showRules=new Button("Show generate moves");
        lastIndex=-1;
        navBackToMovesView=new Button("Nav to moves view");
        nameOfMove="";
        Icon icon=new Icon(VaadinIcon.REPLY);
        icon.getStyle().set("height", 50+"px");
        icon.getStyle().set("width",50+"px");
        backWardPage=new Button(icon);
        icons=new IconsPieces();
        resetBoardBtn=new Button("Reset board");
        delPieceBtn=new Button(new Icon(VaadinIcon.TRASH));
        boardModel=new BoardDesign();
        blackPieces=new Button[6];
        whitePieces=new Button[6];
        board=new Button[8][8];
        this.getStyle().set("gap", "0");
        designButtons();
        initSystem();
        
    }
    private void designButtons()
    {
        showRules.getStyle().set("background-color", "cyan");
        navBackToMovesView.getStyle().set("background-color", "cyan");
        delPieceBtn.getStyle().set("color", "black");
        resetBoardBtn.getStyle().set("color", "black");
        navBackToMovesView.getStyle().set("color", "black");
        showRules.getStyle().set("color", "black");
        setSizeOfButtons(delPieceBtn, 50, 50);
        setSizeOfButtons(resetBoardBtn, 50, 300);
        setSizeOfButtons(showRules, 50, 350);
        setSizeOfButtons(navBackToMovesView, 50, 300);
        setFontSizeForButtons(delPieceBtn, 30);
        setFontSizeForButtons(resetBoardBtn, 30);
        setFontSizeForButtons(showRules, 30);
        setFontSizeForButtons(navBackToMovesView, 30);
    }
    private void setFontSizeForButtons(Button btn,int size)
    {
        btn.getStyle().set("font-size",size+"px");
    }
    private void setSizeOfButtons(Button btn,int height,int width)
    {
        btn.setHeight(height+"px");
        btn.setWidth(width+"px");
    }
    public void buildBoardDefulat()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j].setIcon(icons.getApropatePiece(Pieces.EMPTY_SIGN));
            }
        }
    }
    private String getApropateColor(Location loc)
    {
        int row=loc.getRow();
        int col=loc.getCol();
        if(((row%2==0)&&col%2>0)||(row%2>0&&(col%2==0)))
            return " SandyBrown";
        return "SaddleBrown";
    }
    public void btnClickedOnBoard(Button btn)
    {
        int row=Integer.parseInt((btn.getId().get().charAt(0))+"");
        int col=Integer.parseInt((btn.getId().get().charAt(2))+"");
        if(boardModel.isShowRulesBtnPressd())
        {
            if(generateMoves!=null)
                cleanBoardByGenerateListLocs();
            Location pLoc=new Location(row,col);
            generateMoves=boardModel.getGenratePossibleMove(pLoc);
            showRulesForSpcifiedPiece();
            return;
        }
        if(boardModel.delBtnIsPressed())
        {
            boardModel.eraseMove(new Location(row,col));
            board[row][col].setIcon(icons.getApropatePiece(Pieces.EMPTY_SIGN));
            updateExplain();
            return;
        }
        if(!boardModel.thereIsPrevMoveNotDoingThing())
        {
            boardModel.setPrevMove(new Location(row,col));
            board[row][col].getStyle().set("background-color", "red");
            boardModel.setPrevMove(new Location(row,col));
        }
        else
        {
            Location prevMove=boardModel.getPrevMove();
            if(!boardModel.getPrevMove().equalsLocations(new Location(row,col)))
            {
                board[row][col].setIcon(icons.getApropatePiece(boardModel.getBoard()[prevMove.getRow()][prevMove.getCol()].getPiece()));
                board[prevMove.getRow()][prevMove.getCol()].setIcon(icons.getApropatePiece(Pieces.EMPTY_SIGN));
                boardModel.doMove(new Move(new Location(prevMove.getRow(),prevMove.getCol()),new Location(row,col)));
                updateExplain();
            }
            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", getColorOfLocationInBoard());
            boardModel.setPrevMoveDeafult();
        }
    }

    private String getColorOfLocationInBoard() {
        Location prevMove=boardModel.getPrevMove();
        int row=prevMove.getRow();
        int col=prevMove.getCol();
        if(((row%2==0)&&col%2>0)||(row%2>0&&(col%2==0)))
            return "SandyBrown";
        return "SaddleBrown";
    }
    private String getColorOfLocationInBoardWithOutPrevMove(Location loc) {
        int row=loc.getRow();
        int col=loc.getCol();
        if(((row%2==0)&&col%2>0)||(row%2>0&&(col%2==0)))
            return "SandyBrown";
        return "SaddleBrown";
    }
    private void buildBoard()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(((i%2==0)&&j%2>0)||(i%2>0&&(j%2==0)))
                    board[i][j].getStyle().set("background-color"," SandyBrown");
                else
                    board[i][j].getStyle().set("background-color"," SaddleBrown");
            }
        }
    }

    private void blackPieceClickedInArray(Button btn) {
        if(boardModel.isShowRulesBtnPressd())
        {
            if(generateMoves!=null)
                cleanBoardByGenerateListLocs();
            boardModel.setShowRulesBtnPressd(false);
            showRules.getStyle().set("background-color", " cyan");
        }
        Location prevMove=boardModel.getPrevMove();
        if(boardModel.delBtnIsPressed())
        {
            boardModel.setDelBtnPressed(false);
            delPieceBtn.getStyle().set("background-color", " white");
        }
        if(boardModel.thereIsPrevMoveNotDoingThing()/*prevMove!=null*/)
        {
            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", getColorOfLocationInBoard());
            boardModel.setPrevMoveDeafult();
        }
        int pieceLoc=Integer.parseInt(btn.getId().get());
        if(boardModel.whitePieceClicked()/*whitePieceClickedLoc>-1*/)
        {
            whitePieces[boardModel.getWhitePieceClickedLoc()].getStyle().set("background-color", " SandyBrown");
            boardModel.setWhitePieceClickedLoc(-1);
        }
        if(boardModel.blackPieceClicked()/*blackPieceClickedLoc>-1*/)
        {
            
            if(boardModel.twoBlackPieceNotEquals(boardModel.getBlackPieceClickedLoc(),pieceLoc))/*!(blackPieces[blackPieceClickedLoc].getId().get()).equals(blackPieces[pieceLoc].getId().get())*/
            {
                blackPieces[boardModel.getBlackPieceClickedLoc()].getStyle().set("background-color", " SandyBrown");
                blackPieces[pieceLoc].getStyle().set("background-color", " red");
                boardModel.setBlackPieceClickedLoc(pieceLoc);
            }
            else
            {
                blackPieces[pieceLoc].getStyle().set("background-color", " SandyBrown");
                boardModel.setBlackPieceClickedLoc(-1);
            }
        }
        else
        {
            boardModel.setBlackPieceClickedLoc(pieceLoc);
            blackPieces[pieceLoc].getStyle().set("background-color", " red");
        }

    }

    private void whitePieceClickedInArray(Button btn) {
        if(boardModel.isShowRulesBtnPressd())
        {
            if(generateMoves!=null)
                cleanBoardByGenerateListLocs();
            boardModel.setShowRulesBtnPressd(false);
            showRules.getStyle().set("background-color", " cyan");
        }
        Location prevMove=boardModel.getPrevMove();
        if(boardModel.delBtnIsPressed())
        {
            System.out.println("1");
            boardModel.setDelBtnPressed(false);
            delPieceBtn.getStyle().set("background-color", " cyan");
        }
        if(boardModel.thereIsPrevMoveNotDoingThing())
        {
            System.out.println("2");
            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", getColorOfLocationInBoard());
            boardModel.setPrevMoveDeafult();
        }
        int pieceLoc=Integer.parseInt(btn.getId().get());
        if(boardModel.blackPieceClicked())
        {
            System.out.println("3");
            blackPieces[boardModel.getBlackPieceClickedLoc()].getStyle().set("background-color", " SandyBrown");
            boardModel.setBlackPieceClickedLoc(-1);
        }
        if(boardModel.whitePieceClicked())
        {
            
            if(boardModel.twoWhitePieceNotEquals(boardModel.getWhitePieceClickedLoc(),pieceLoc))
            {
                System.out.println("4");
                whitePieces[boardModel.getWhitePieceClickedLoc()].getStyle().set("background-color", " SandyBrown");
                whitePieces[pieceLoc].getStyle().set("background-color", " red");
                boardModel.setWhitePieceClickedLoc(pieceLoc);
            }
            else
            {
                System.out.println("5");
                whitePieces[pieceLoc].getStyle().set("background-color", " SandyBrown");
                boardModel.setWhitePieceClickedLoc(-1);
            }
        }
        else
        {
            System.out.println("6");
            boardModel.setWhitePieceClickedLoc(pieceLoc);
            System.out.println("PieceLoc="+pieceLoc);
            whitePieces[pieceLoc].getStyle().set("background-color", " red");
        }

    }

    private void handleBlackPieceFromOutSideToInside(Button btn) {
        int row=Integer.parseInt(btn.getId().get().charAt(0)+"");
        int col=Integer.parseInt(btn.getId().get().charAt(2)+"");
        board[row][col].setIcon(icons.getApropatePiece(boardModel.getCorrectPieceByNum(blackPieces[boardModel.getBlackPieceClickedLoc()].getId().get(),true)));
        boardModel.bringBlackPieceToBoard(boardModel.getBlackPieceClickedLoc(), new Location(row, col));
        updateExplain();
    }

    private void handleWhitePieceFromOutSideToInside(Button btn) {
        int row=Integer.parseInt(btn.getId().get().charAt(0)+"");
        int col=Integer.parseInt(btn.getId().get().charAt(2)+"");
        board[row][col].setIcon(icons.getApropatePiece(boardModel.getCorrectPieceByNum(whitePieces[boardModel.getWhitePieceClickedLoc()].getId().get(),false)));
        boardModel.bringWhitePieceToBoard(boardModel.getWhitePieceClickedLoc(), new Location(row, col));
        updateExplain();
    }
    
    private Image loadImage(String fileName, int width, int height)
    {
        Image imgImage = new Image(fileName,"Image");
        if(width != -1 || height != -1)
        {
            imgImage.getStyle().set("width", width+"px");
            imgImage.getStyle().set("height", height+"px");
        }
        return imgImage;
    }

    private void handleDelBtnPressed() {
        if(boardModel.isShowRulesBtnPressd())
        {
            if(generateMoves!=null)
                cleanBoardByGenerateListLocs();
            boardModel.setShowRulesBtnPressd(false);
            showRules.getStyle().set("background-color", " cyan");
        }
        if(boardModel.delBtnIsPressed())
        {
            if(boardModel.thereIsPrevMoveNotDoingThing())
            {
                Location loc=boardModel.getPrevMove();
                board[loc.getRow()][loc.getCol()].getStyle().set("background-color", getColorOfLocationInBoard());
                boardModel.setPrevMoveDeafult();
            }
            if(boardModel.whitePieceClicked())
            {
                whitePieces[boardModel.getWhitePieceClickedLoc()].getStyle().set("background-color", " SandyBrown");
                boardModel.setWhitePieceClickedLoc(-1);
            }
            if(boardModel.blackPieceClicked())
            {
                blackPieces[boardModel.getBlackPieceClickedLoc()].getStyle().set("background-color", " SandyBrown");
                boardModel.setBlackPieceClickedLoc(-1);
            }
            delPieceBtn.getStyle().set("background-color", " red");
        }
        else
        {
            System.out.println("dellllll");
            delPieceBtn.getStyle().set("background-color", " cyan");
        }
    }
    private void handleClickLies()
    {
        navBackToMovesView.addClickListener(t->{
            UI.getCurrent().navigate(MovesView.class,"$"+lastIndex+"@"+nameOfMove);
        });
        navBackToMovesView.setEnabled(false);
        resetBoardBtn.getStyle().set("background-color", " cyan");
        delPieceBtn.getStyle().set("background-color", " cyan");
         backWardPage.addClickListener((t) -> {
            UI.getCurrent().getPage().getHistory().back();
        });
        resetBoardBtn.addClickListener(t->{
            if(boardModel.isShowRulesBtnPressd())
            {
                if(generateMoves!=null)
                    cleanBoardByGenerateListLocs();
                boardModel.setShowRulesBtnPressd(false);
                showRules.getStyle().set("background-color", " cyan");
            }
            boardModel.initBoard();
            if(boardModel.thereIsPrevMoveNotDoingThing())
            {
                Location prevMove=boardModel.getPrevMove();
                int row=prevMove.getRow();
                int col=prevMove.getCol();
                board[row][col].getStyle().set("background-color"," "+getApropateColor(prevMove));
                boardModel.setPrevMoveDeafult();
            }
            boardModel.setDelBtnPressed(false);
            delPieceBtn.getStyle().set("background-color","cyan");
            buildBoardDefulat();
        });
        delPieceBtn.addClickListener(t->{
            boardModel.delBtnPressed();
            System.out.println("del="+boardModel.delBtnIsPressed());
            handleDelBtnPressed();
        });
        showRules.addClickListener(t->{
            if(boardModel.delBtnIsPressed())
            {
                boardModel.setDelBtnPressed(false);
                delPieceBtn.getStyle().set("background-color","cyan");
            }
            if(boardModel.thereIsPrevMoveNotDoingThing())
            {
                int r=boardModel.getPrevMove().getRow();
                int c=boardModel.getPrevMove().getCol();
                board[r][c].getStyle().set("background-color", getColorOfLocationInBoard());
                boardModel.setPrevMoveDeafult();
            }
            if(boardModel.blackPieceClicked())
            {
                blackPieces[boardModel.getBlackPieceClickedLoc()].getStyle().set("background-color", "SandyBrown");
                boardModel.setBlackPieceClickedLoc(-1);
            }
            if(boardModel.whitePieceClicked())
            {
                whitePieces[boardModel.getWhitePieceClickedLoc()].getStyle().set("background-color", "SandyBrown");
                boardModel.setWhitePieceClickedLoc(-1);
            }
                
            boardModel.setShowRulesBtnPressd(!boardModel.isShowRulesBtnPressd());
            if(boardModel.isShowRulesBtnPressd())
                showRules.getStyle().set("background-color", "red");
            else
                showRules.getStyle().set("background-color", "cyan");
            if(generateMoves!=null)
            {
                cleanBoardByGenerateListLocs();
                generateMoves=null;
            }
                
        });
    }
    private void initSystem() {
        addToExplainPnl();
        handleClickLies();
        char[] blackPiecesNames={'P','R','B','N','K','Q'};
        char[] whitePiecesNames={'p','r','b','n','k','q'};
        for (int i = 0; i < 6; i++) {
            blackPieces[i]=new Button();
            whitePieces[i]=new Button();
            blackPieces[i].setId(i+"");
            whitePieces[i].setId(i+"");
            blackPieces[i].setIcon(icons.getApropatePiece(blackPiecesNames[i]));
            whitePieces[i].setIcon(icons.getApropatePiece(whitePiecesNames[i]));
            blackPieces[i].getStyle().set("background-color", "SandyBrown");
            whitePieces[i].getStyle().set("background-color", "SandyBrown");
            whitePieces[i].getStyle().set("width"," 80px");
            whitePieces[i].getStyle().set("height"," 80px");
            blackPieces[i].getStyle().set("width"," 80px");
            blackPieces[i].getStyle().set("height"," 80px");
            
            blackPieces[i].addClickListener((t)->{
                blackPieceClickedInArray(t.getSource());
//                blackPieceClickedLoc=Integer.parseInt(t.getSource().getId().get());
            });
            
            whitePieces[i].addClickListener((t)->{
                whitePieceClickedInArray(t.getSource());
//                whitePieceClickedLoc=Integer.parseInt(t.getSource().getId().get());
            });
        }
        VerticalLayout boardPnl=new VerticalLayout();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j]=new Button();
                board[i][j].setId(i+","+j);
                board[i][j].getStyle().set("width"," 80px");
                board[i][j].getStyle().set("height"," 80px");
                board[i][j].getStyle().set("padding", "0");
                board[i][j].getStyle().set("margin", "0");
                board[i][j].addClickListener((t->{
                    
                    if(boardModel.blackPieceClicked())
                    {
                        handleBlackPieceFromOutSideToInside(t.getSource());
                        if(boardModel.thereIsPrevMove())
                        {
                            Location prevMove=boardModel.getPrevMove();
                            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", "SandyBrown");
                        }
                    }
                    
                    else
                        if(boardModel.whitePieceClicked())
                        {
                            handleWhitePieceFromOutSideToInside(t.getSource());
                            if(boardModel.thereIsPrevMove())
                            {
                                Location prevMove=boardModel.getPrevMove();
                                board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", "SandyBrown");
                            }
                        }
                        else
                            if(boardModel.checkMoveOnBoard(new Location(Integer.parseInt(t.getSource().getId().get().charAt(0)+""),Integer.parseInt(t.getSource().getId().get().charAt(2)+""))))
                                btnClickedOnBoard(t.getSource());
                }
                ));
            }
        }
        
//        setAlignItems(Alignment.CENTER);
        buildBoard();
        add(new H1("Chess Board"),backWardPage);
        add(new HorizontalLayout(blackPieces[0],blackPieces[1],blackPieces[2],blackPieces[3],blackPieces[4],blackPieces[5]));
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++) {
                board[i][j].getStyle().set("float"," left");
            }
            HorizontalLayout hr=new HorizontalLayout(board[i][0],board[i][1],board[i][2],board[i][3],board[i][4],board[i][5],board[i][6],board[i][7]);
            hr.getStyle().set("gap", "0");
            boardPnl.add(hr);
        }
        boardPnl.getStyle().set("gap", "0");
        HorizontalLayout h=new HorizontalLayout(boardPnl,explainPnl);
        h.getStyle().set("gap", "0");
        add(h);
        add(new HorizontalLayout(whitePieces[0],whitePieces[1],whitePieces[2],whitePieces[3],whitePieces[4],whitePieces[5]));
        add(new HorizontalLayout(delPieceBtn,resetBoardBtn,navBackToMovesView,showRules));
        setAlignItems(Alignment.CENTER);
        h.setAlignSelf(Alignment.STRETCH, explainPnl);
        boardPnl.getStyle().set("border"," 20px solid black");
        h.getStyle().set("margin-left", " 650px");
        h.getStyle().set("margin-right" ," auto");
        explainPnl.getStyle().set("margin-left", " 100px");
        explainPnl.getStyle().set("margin-right" ," auto");
        explainPnl.getStyle().set("margin-bottom", " 80px");
        explains.setWidth("300px");
        explains.setValue("The board is ready!");
    }
    private void addToExplainPnl()
    {
        Image img=loadImage("imgs/thinkMan.jpg", 200, 275);
        explainPnl.add(img);
        explainPnl.add(explains);
        explainPnl.setAlignItems(Alignment.CENTER);
    }
    
    @Override
    public void setParameter(BeforeEvent be,@OptionalParameter String s) {
        if(s!=null)
        {
            navBackToMovesView.setEnabled(true);
            nameOfMove=s.substring(0, s.indexOf('$'));
            lastIndex=Integer.parseInt(s.substring(s.indexOf('$')+1,s.indexOf('@')));
            System.out.println("---------------- "+(s.indexOf('@')+1)+" ---------------------");
            String t=s.substring(s.indexOf('@')+1,s.lastIndexOf('0'));
            boardModel=new BoardDesign();
            buildBoardByParmeter(t);
        }
    }
    private void buildBoardByParmeter(String s)
    {
        
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                char piece=s.charAt(i*8+j);
                board[i][j].setIcon(icons.getApropatePiece(piece));
                if(piece>'a'&&piece<'z')
                    boardModel.getBoard()[i][j]=new Piece(piece,"WHITE");
                else
                    if(piece>'A'&&piece<'Z')
                        boardModel.getBoard()[i][j]=new Piece(piece,"BLACK");
                    else
                        boardModel.getBoard()[i][j]=new Piece(piece," ");
            }
        }
        
    }
    
    //Rules

    private void cleanBoardByGenerateListLocs() {
        for (int i = 0; i < generateMoves.size(); i++) 
        {
            int r=generateMoves.get(i).getRow();
            int c=generateMoves.get(i).getCol();
            board[r][c].getStyle().set("background-color",getColorOfLocationInBoardWithOutPrevMove(generateMoves.get(i)));
        }
    }

    private void showRulesForSpcifiedPiece() {
        if(generateMoves!=null)
        {
            for (int i = 0; i < generateMoves.size(); i++) {
                int row=generateMoves.get(i).getRow();
                int col=generateMoves.get(i).getCol();
                board[row][col].getStyle().set("background-color", "SpringGreen");
            }
        }
    }
    private void updateExplain()
    {
        String explain=boardModel.checkValidState();
        System.out.println(explain.equals(TalkingBot.checkOnBlack));
        if(explain.equals(TalkingBot.checkOnWhite))
        {
            System.out.println("OK white");
            showDefanderLocsByBot(boardModel.getAllDefanderPiecesLocs("WHITE"));
            showGenrateMovesflickering();
            explain+="Click on show genrate moves!";
        }
            if(explain.equals(TalkingBot.checkOnBlack))
            {
                System.out.println("OK black");
                showDefanderLocsByBot(boardModel.getAllDefanderPiecesLocs("BLACK"));
                showGenrateMovesflickering();
                explain+="Click on show genrate moves!";
            }
        explains.setValue(explain);
    }
    private void showDefanderLocsByBot(ArrayList<Location> defndarsLocs)
    {
        Thread thread=new Thread() {
            UI ui=UI.getCurrent();
            public void run() {
                for (int i = 0; i < defndarsLocs.size(); i++) {
                    int r=defndarsLocs.get(i).getRow();
                    int c=defndarsLocs.get(i).getCol();
                    ui.access(() ->  
                    {
                        synchronized (board) {
                            board[r][c].getStyle().set("background-color", "yellow");
                        }
                        
                    });
                }
                try
                {
                    Thread.sleep(3000);
                }
                catch(Exception e){}
                cleanBoardByList(defndarsLocs,ui);
            }
            
        };
        thread.start();
        
        
    }
    private void cleanBoardByList(ArrayList<Location> locs,UI ui)
    {
            synchronized (board) {
                for (int i = 0; i < locs.size(); i++) {
                    int r=locs.get(i).getRow();
                    int c=locs.get(i).getCol();
                    final int x=i;
                    ui.access(() ->  
                        {
                            board[r][c].getStyle().set("background-color",getColorOfLocationInBoardWithOutPrevMove(locs.get(x)));
                        });
            }
        }
    }

    private void showGenrateMovesflickering() {
        Thread thread=new Thread(){
            UI ui=UI.getCurrent();
            public void run() {
                for (int i = 0; i < 3; i++) {
                    
                    ui.access(()->
                    {
                        showRules.getStyle().set("background-color", " red");
                    });
                        try
                        {
                            Thread.sleep(1000);
                        }
                        catch(Exception e){}
                    ui.access(()->
                    {
                        showRules.getStyle().set("background-color", " cyan");
                    });
                    try
                        {
                            Thread.sleep(1000);
                        }
                        catch(Exception e){}
                }
                    
                }
        };
        thread.start();
    }
}
