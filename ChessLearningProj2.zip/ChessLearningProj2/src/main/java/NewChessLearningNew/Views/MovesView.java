package NewChessLearningNew.Views;

import NewChessLearningNew.Models.Move;
import NewChessLearningNew.Models.Piece;
import NewChessLearningNew.Models.Location;
import NewChessLearningNew.Models.MovesModel;
import NewChessLearningNew.Models.MyHashCode;
import NewChessLearningNew.Models.User;
import NewChessLearningNew.Models.UserMovesModelSize;
import NewChessLearningNew.Run.IconsPieces;
import NewChessLearningNew.Run.Panel;
import NewChessLearningNew.Run.Pieces;
import NewChessLearningNew.Services.MovesModelService;
import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import java.util.ArrayList;
import java.util.List;
import static org.springframework.web.servlet.mvc.method.annotation.SseEmitter.event;

@Route("/login/ChoiceOfBoardOrMoves/moves")
public class MovesView extends VerticalLayout implements HasUrlParameter<String>{
    private Button[][] board;
    private Button proceedEnd;
    private Button reverseStart;
    private Button proceed;
    private Button reverse;
    private Button pause;
    private Button play;
    private MovesModelService movesModelservice;
    private UserService userService;
    private long seconds;
    private MovesModel model;
    private boolean stopMoves;
    private Thread thread;
    private TextField setSeconds;
    private Button applySeconds;
    private Panel pnl;
    private Button backWardPage;
    private IconsPieces icons;
    private TextArea msg;
    private User currentUser;
    private Button navToDesginBtn;
    
    public MovesView(MovesModelService movesModelservice,UserService userService)
    {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        currentUser=userService.getUserById(VaadinSession.getCurrent().getAttribute("UserName").toString());
        navToDesginBtn=new Button("Navigate to design in this state");
        msg=new TextArea("Explanation");
        Icon icon=new Icon(VaadinIcon.REPLY);
        icon.getStyle().set("height", 50+"px");
        icon.getStyle().set("width",50+"px");
        backWardPage=new Button(icon);
        icons=new IconsPieces();
        model=new MovesModel();
        seconds=1000;
        this.movesModelservice=movesModelservice;
        this.userService=userService;
        pnl=new Panel();
        setSeconds=new TextField("Enter Seconds");
        applySeconds=new Button("Apply");
        board=new Button[8][8];
        reverse=new Button(new Icon(VaadinIcon.BACKWARDS));
        proceed=new Button(new Icon(VaadinIcon.FORWARD));
        pause=new Button(new Icon(VaadinIcon.PAUSE));
        play=new Button(new Icon(VaadinIcon.PLAY));
        proceedEnd=new Button(">>>");
        reverseStart=new Button(new Icon(VaadinIcon.REFRESH));
        stopMoves=true;
        initSystem();
        buildBoardByModel();
        msg.getStyle().set("font-size", 20+"px");
        handleNavDesginBtn();
    }

    private void initSystem() {
        backWardPage.addClickListener((t) -> {
            UI.getCurrent().getPage().getHistory().back();
        });
        pnl.getStyle().set("gap", "0");
        add(new H1("Learn moves"),backWardPage);
        addBoard();
        buildBoard();
        for (int i = 0; i < 8; i++) 
        {
            HorizontalLayout h=new HorizontalLayout(board[i][0],board[i][1],board[i][2],board[i][3],board[i][4],board[i][5],board[i][6],board[i][7]);
            h.getStyle().set("gap","0");
            pnl.add(h);
        }
        reverse.addClickListener(t->{
            reverseBtnClicked();
        });
        play.addClickListener(t->{
            playBtnClicked();
        });
        pause.addClickListener(t->{
            pauseBtnClicked();
        });
        proceed.addClickListener(t->{
            proceedBtnClicked();
        });
        proceedEnd.addClickListener(t->{
            proceedEndClicked();
        });
        reverseStart.addClickListener(t->{
            reverseStartClicked();
        });
        applySeconds.addClickListener(t->{
            try
            {
                long newSeconds=Long.parseLong(setSeconds.getValue());
                seconds=newSeconds*1000;
                setSeconds.setValue("");
            }
            catch(Exception e)
            {
                Notification.show("Please enter a legal number",4000,Notification.Position.TOP_CENTER);
            }
        });
        add(new HorizontalLayout(navToDesginBtn,reverseStart,proceedEnd,reverse,play,pause,proceed,setSeconds,applySeconds));
        setAlignItems(Alignment.CENTER);
        runBoardDefulat();
        pauseBtnClicked();
    }       

    private void buildBoard() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j]=new Button();
                board[i][j].setIcon(icons.getApropatePiece(model.getOpeningBoard()[i][j].getPiece()));
                board[i][j].setId(model.getOpeningBoard()[i][j].getPiece()+"");
                board[i][j].getStyle().set("width"," 80px");
                board[i][j].getStyle().set("height"," 80px");
                board[i][j].getStyle().set("padding", "0");
                board[i][j].getStyle().set("margin", "0");
                board[i][j].getStyle().set("color","pink");
                if(((i%2==0)&&j%2>0)||(i%2>0&&(j%2==0)))
                    board[i][j].getStyle().set("background-color"," SandyBrown");
                else
                    board[i][j].getStyle().set("background-color"," SaddleBrown");
            }
        }
        
        
    }

    private void reverseBtnClicked() {
        pauseBtnClicked();
        doPrevMove(model.getPrevMove());
    }
    private void runBoardDefulat()
    {
        UI ui = UI.getCurrent();
        thread=new Thread(){
            @Override
            public void run()
            {
                    int i=0;
                    while(true)
                    {
                            if(stopMoves)
                                threadWait();
                            Move move=model.getForWardMove();
                            ui.access(() ->  {
                                if(move!=null)
                                    doForWardMove(move);
                                else
                                    stopMoves=true;
                            });
                            try
                            {
                                Thread.sleep(seconds);
                            }
                            catch(Exception e)
                            {}
                        }
                
            }
        };
        thread.start();
    }

    private void threadWait()
    {
        while(stopMoves)
        {
            try
            {
                Thread.sleep(1500);
            }
            catch(Exception e)
            {
                
            }
        }
    }
                    
    private void playBtnClicked() {
        stopMoves=false;
    }
    private void pauseBtnClicked() {
        stopMoves=true;
    }

    private void proceedBtnClicked() {
        pauseBtnClicked();
        doForWardMove(model.getForWardMove());
    }
    private void proceedEndClicked()
    {
        pauseBtnClicked();
        Move move=model.getForWardMove();
        while (move!=null)
        {
            doForWardMove(move);
            move=model.getForWardMove();
        }
    }
    private void reverseStartClicked()
    {
        pauseBtnClicked();
        Move move=model.getPrevMove();
        while (move!=null)
        {
            doPrevMove(move);
            move=model.getPrevMove();
        }
    }
    private void doForWardMove(Move move)
    {
        if(move!=null)
        {
            doMove(move);
            updateUser();
//            if(board[src.getRow()][src.getCol()].getId().get().equals("p")||board[src.getRow()][src.getCol()].getId().get().equals("P"))
//                checkForWeirdPawnOrCastleMove(move);
//            else
//                if(board[src.getRow()][src.getCol()].getId().get().equals("k")||board[src.getRow()][src.getCol()].getId().get().equals("K"))
//                    checkForWeirdPawnOrCastleMove(move);
        }
    }
    private void checkForWeirdPawnOrCastleMove(Move move)
    {
        Move nextMove=model.getForWardMove();
        if(nextMove!=null)
        {
            if(move.getSrcPiece().getColor().equals(nextMove.getSrcPiece().getColor()))
            {
                doMove(nextMove);
            }
            else
                model.getPrevMove();
        }
    }
    /**
 * Performs a move on the board.
 *
 * @param move The move to be executed.
 */
private void doMove(Move move) {
    Location src = new Location(move.getSrcLoc());
    Location dst = new Location(move.getDstLoc());

    if (move.getPieceChange() != ' ') {
        // Set the appropriate icon and ID for the destination cell
        board[dst.getRow()][dst.getCol()].setIcon(icons.getApropatePiece(move.getPieceChange()));
        board[dst.getRow()][dst.getCol()].setId(move.getPieceChange() + "");
    } else {
        // Set the appropriate icon and ID for the destination cell based on the source piece
        board[dst.getRow()][dst.getCol()].setIcon(icons.getApropatePiece(getCorrectPiece(move.getSrcPiece())));
        board[dst.getRow()][dst.getCol()].setId(getCorrectPiece(move.getSrcPiece()) + "");
    }

    // Clear the icon and ID for the source cell
    board[src.getRow()][src.getCol()].setIcon(icons.getApropatePiece(Pieces.EMPTY_SIGN));
    board[src.getRow()][src.getCol()].setId(Pieces.EMPTY_SIGN + "");

    // Update the button sizes
    buildButtonsSize();
}
    private void doPrevMove(Move move)
    {       
        
        if(move!=null)
        {   
            int sR=move.getSrcPiece().getLoc().getRow();
            int sC=move.getSrcPiece().getLoc().getCol();
            int dR=move.getDstPiece().getLoc().getRow();
            int dC=move.getDstPiece().getLoc().getCol();
            if(move.getPieceChange()!=' ')
            {
                board[sR][sC].setIcon(icons.getApropatePiece(getCorrectPawn(move.getPieceChange())));
                board[sR][sC].setId(move.getPieceChange()+"");
            }
            else
            {
                board[sR][sC].setIcon(icons.getApropatePiece(getCorrectPiece(move.getSrcPiece())));
                board[sR][sC].setId(move.getSrcPiece().getPiece()+"");
            }
            board[dR][dC].setIcon(icons.getApropatePiece(getCorrectPiece(move.getDstPiece())));
            board[dR][dC].setId(move.getDstPiece().getPiece()+"");                
        }   
    }
    
    private void addBoard() {
        HorizontalLayout h1=new HorizontalLayout(pnl,msg);
        add(h1);
        h1.setAlignSelf(Alignment.CENTER,pnl);
        
    }
    private void buildBoardByModel() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                try
                {
                    board[i][j].setIcon(icons.getApropatePiece(model.getOpeningBoard()[i][j].getPiece()));
                    board[i][j].setId(model.getOpeningBoard()[i][j].getPiece()+"");
                }
                catch(Exception e)
                {
                    System.out.println("ERROR!");
                }
                board[i][j].setHeight("60px");
                board[i][j].setWidth("80px");
            }
        }
    }

    private void buildButtonsSize() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j].setHeight("60px");
                board[i][j].setWidth("80px");
            }
        }
    }

    private char getCorrectPiece(Piece piece) {
        char name=piece.getPiece();
        if(name==' ')
            return name;
        if(name>'A'&&name<'Z'&&piece.getColor().equals("WHITE"))
        {
            return (char)((int)name-(int)'A'+(int)'a');
        }
        if(name>'a'&&name<'z'&&piece.getColor().equals("BLACK"))
            return (char)((int)name-(int)'a'+(int)'A');
        return name;
    }
    @Override
    public void setParameter(BeforeEvent be,@OptionalParameter String t) {
       int lastIndex=-1;
       if(t.charAt(0)=='$')
       {
           lastIndex=Integer.parseInt(t.substring(1,t.indexOf('@')));
           t=t.substring(t.indexOf('@')+1);
       }
       model=movesModelservice.getMovesModelById(t);
       buildBoardByModel();
       msg.setValue(model.getMsg());
       if(lastIndex>-1)
           doMovesTillIndex(lastIndex);
       
    }
    private void doMovesTillIndex(int index)
    {
        for (int i = 0; i < index; i++) {
            doForWardMove(model.getForWardMove());
        }
    }
    private char getCorrectPawn(char pieceChange) {
        if(pieceChange>'a'&&pieceChange<'z')
            return 'p';
        return 'P';
    }
    private void updateUser()
    {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<UserMovesModelSize> indexs=currentUser.getMaxIndexsOfMovesModel();
                int num=indexs.get(MyHashCode.getMyHashIndex(model.getMoveName())).getMaxIndex();
                if(model.getLastIndex()>num)
                {
                    indexs.get(MyHashCode.getMyHashIndex(model.getMoveName())).setMaxIndex(model.getLastIndex());
                    userService.updateUser(currentUser);
                    System.out.println(currentUser.getMaxIndexsOfMovesModel().toString());
                }
            }
        }).start();
        
    }
    private void handleNavDesginBtn()
    {
        navToDesginBtn.addClickListener(t->{
            UI.getCurrent().navigate(BoardDesignView.class,model.getNameOfMove()+"$"+model.getLastIndex()+"@"+buildBoardForDesignBoard().toString()+'0');
        });
    }
    private String buildBoardForDesignBoard()
    {
        String newBoard="";
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                char piece=board[i][j].getId().get().charAt(0);
                newBoard+=piece;
            }
        }
        return newBoard;
    }
}       
         