package NewChessLearningNew.Views;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
@Route("")
public class HomeView extends VerticalLayout{
    private H1 title;
    private Button logInBtn;
    private Button signUpBtn;;
    
    private HorizontalLayout fixLinksLayOut;
    public HomeView()
    {
        fixLinksLayOut=new HorizontalLayout();
        title=new H1("Chess Learning Web");
        logInBtn=new Button("Login");
        signUpBtn=new Button("Sign up");
        
        logInBtn.addClickListener((t) -> {
            logInBtn.getUI().ifPresent(ui->ui.navigate("http://localhost:8080/login"));
        });
        signUpBtn.addClickListener((t) -> {
            signUpBtn.getUI().ifPresent(ui->ui.navigate("http://localhost:8080/signUp"));
        });
        
        setStyling();
        fixLinksLayOut.add(signUpBtn,logInBtn);
        add(title,new Image("imgs/boardWinIcon.jpg",""),signUpBtn,logInBtn);
        setAlignItems(Alignment.CENTER);
    }
    private void setStyling()
    {
        
        setSizeForButtons(100, 300);
        setBorderForButtons("inset");
        setFontSizeForButtons(30);
        signUpBtn.getStyle().set("background-color","white");
        signUpBtn.getStyle().set("color"," black");
        logInBtn.getStyle().set("background-color","white");
        logInBtn.getStyle().set("color"," black");
        this.getStyle().set("background","cyan");
        
        fixLinksLayOut.getStyle().set("background","cyan");
        
    }
    private void setSizeForButtons(int height,int width)
    {
        signUpBtn.setHeight(height+"px");
        signUpBtn.setWidth(width+"px");
        logInBtn.setHeight(height+"px");
        logInBtn.setWidth(width+"px");
    }
    private void setFontSizeForButtons(int size)
    {
        signUpBtn.getStyle().set("font-size",size+"px");
        logInBtn.getStyle().set("font-size",size+"px");
    }
    private void setBorderForButtons(String border)
    {
        signUpBtn.getStyle().set("border-style",border);
        logInBtn.getStyle().set("border-style",border);
    }
}
