package NewChessLearningNew.Views;

import NewChessLearningNew.Models.User;
import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.SelectionMode;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import java.util.ArrayList;
import java.util.List;

@Route("/login/GridServiceForMongoView")
public class GridServiceForMongoView extends VerticalLayout {
    private UserService service;
    private Grid usersGrid;
    private TextField un;
    private TextField pw;
    private Button trBtn;
    private Button stBtn;
    private Button addBtn;
    private boolean statusUserClicked;
    private Button updateBtn;
    private Button deleteBtn;
    private TextField nameOfUser;
    private TextField theUserLoadName;
    private boolean thereIsPwProblem;
    private User userLoad;
    private Button cnclUserLod;
    private Button admin;
    private boolean adminBtnClicked;
    private TextField searchUser;
    private Button search;
    public GridServiceForMongoView(UserService service)
    {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        if(!service.getUserById((String) VaadinSession.getCurrent().getAttribute("UserName")).isAdmin())
        {
            Notification.show("Your'e not an admin\nSorry! We sent you back!");
            try{Thread.sleep(3000);}
            catch(Exception e){}
            UI.getCurrent().getPage().getHistory().back();
        }
        this.service=service;
        search=new Button(new Icon(VaadinIcon.SEARCH));
        searchUser=new TextField("Search User");
        admin=new Button("Set as Admin");
        adminBtnClicked=false;
        cnclUserLod=new Button("Cancel");
        theUserLoadName=new TextField("User Loaded");
        theUserLoadName.setEnabled(false);
        thereIsPwProblem=false;
        usersGrid=new Grid(User.class);
        updateGridAndHideAllAdmins();
        usersGrid.setSelectionMode(SelectionMode.SINGLE);
        statusUserClicked=false;
        
        H1 title=new H1("Grid service");
        title.setSizeFull();
        un=new TextField("Enter user name");
        nameOfUser=new TextField("Enter your real name");
        pw=new TextField("Enter password 6-10 characthers with no space!");
        addBtn=new Button("add");
        trBtn=new Button("I'm a teacher!");
        stBtn=new Button("I'm a student!");
        updateBtn=new Button("update");
        deleteBtn=new Button("delete");
        handleGridCLicked();
        handleClickLies();
        
        
        
        
        
        
        
//        checkValid();
        HorizontalLayout searchHorizontal=new HorizontalLayout(searchUser,search);
        searchHorizontal.getStyle().set("gap","0");
        add(title,searchHorizontal,usersGrid,new HorizontalLayout(un,pw,nameOfUser,theUserLoadName,cnclUserLod,admin),new HorizontalLayout(trBtn,stBtn),new HorizontalLayout(addBtn,updateBtn,deleteBtn));
        setAlignSelf(Alignment.END, title,theUserLoadName,cnclUserLod);
        setAlignSelf(Alignment.CENTER, searchHorizontal);
    }

    private void checkPassword() {
        thereIsPwProblem=false;
        if(pw!=null)
        {
            String pwVal=pw.getValue();
            if(pwVal.length()<6)
            {
                Notification.show("Password lentgh is smaller then 6 please enter other password!",4000,Notification.Position.MIDDLE);
                thereIsPwProblem=true;
            }
            else
                if(pwVal.length()>10)
                {
                    Notification.show("Password lentgh is bigger then 10 please enter other password!",4000,Notification.Position.MIDDLE);
                    thereIsPwProblem=true;
                }
            if(pwVal.indexOf(" ")>-1)
            {
                Notification.show("Remove space charecther please!",4000,Notification.Position.MIDDLE);
                thereIsPwProblem=true;
            }
            
            
            
        }
    }

    private void checkStatusUser() {
        if(!statusUserClicked)
            Notification.show("Enter your status user!",4000,Notification.Position.MIDDLE);
    }

    private void handleGridCLicked() {
        usersGrid.addSelectionListener(t->{
                if(!t.getFirstSelectedItem().isEmpty())
                {
                    userLoad=(User)t.getFirstSelectedItem().get();
                    checkLoadUser();
                }
        });
    }
    private void checkLoadUser()
    {
        User currentUser=getCurrentUser();
        if(userLoad.getUserName().equals(currentUser.getUserName()))
        {
            adminBtnClicked=true;
            setCorrectColorForAdminBtn();
        }
        if(!userLoad.isAdmin())
        {
            adminBtnClicked=false;
            setCorrectColorForAdminBtn();
        }
        if(userLoad.isAdmin()&&!userLoad.getUserName().equals(currentUser.getUserName()))
        {
            adminBtnClicked=false;
            setCorrectColorForAdminBtn();
            Notification.show("Only current admin can change his details!", 2000, Notification.Position.BOTTOM_CENTER);
        }
        else
        {
            theUserLoadName.setValue(userLoad.getUserName());
            un.setValue(userLoad.getUserName());
            pw.setValue(userLoad.getPassword());
            nameOfUser.setValue(userLoad.getName());
        }
    }
    
    private void handleClickLies()
    {
        search.addClickListener(t->{
            User sUser=service.getUserById(searchUser.getValue());
            if(sUser!=null)
            {
                usersGrid.select(sUser);
                userLoad=sUser;
                checkLoadUser();
            }
            else
                Notification.show("User not found!\nTry to search in your self.", 2000, Notification.Position.BOTTOM_CENTER);
        });
        admin.addClickListener(t->{
            adminBtnClicked=!adminBtnClicked;
            setCorrectColorForAdminBtn();
        });
        trBtn.addClickListener((t) -> {             
            trBtn.setText("I'm a teacher!, (Clickd!)");
            stBtn.setText("I'm a student!");
            statusUserClicked=true;         
        });
        stBtn.addClickListener((t) -> {
            trBtn.setText("I'm a teacher!");
            stBtn.setText("I'm a student!, (Clickd!)");
            statusUserClicked=true;
        });
        updateBtn.addClickListener((t) -> 
        {
            checkStatusUser();
            checkPassword();
            if(!thereIsPwProblem && statusUserClicked)
            {
                User userToUp=service.getUserById(userLoad.getUserName());
                if(un.getValue().equals(getCurrentUser().getUserName())||(userToUp!=null && !userToUp.isAdmin()))
                {
                    boolean isTeacher=false;
                    if(trBtn.getText().length()>17)
                        isTeacher=true;
                    if(userLoad!=null)
                    {
                        service.deleteUser(new User(un.getValue(), "", "", false));
                        User userToAdd=new User(un.getValue(),pw.getValue(),nameOfUser.getValue(),isTeacher,userLoad.getMaxIndexsOfMovesModel(),adminBtnClicked);
                        service.addUser(userToAdd);
                        updateGridAndHideAllAdmins();
                        Notification.show("User Updated!");
                        clearUserAtAll();
                    }
                }
                else
                    if(userToUp==null)
                        Notification.show("User not updated!\nPassword or Status aren't OK!\nPlease try again!");
                    else
                        Notification.show("Only current admin can change his details!", 2000, Notification.Position.BOTTOM_CENTER);
            }
            else
                Notification.show("User not added!\nPassword or Status aren't OK!\nPlease try again!");
        });
        deleteBtn.addClickListener((t) -> {
            User userToDel=service.getUserById(un.getValue());
                if(un.getValue().equals(getCurrentUser().getUserName())||(userToDel!=null && !(userToDel.isAdmin())))
                {
                    if(userLoad!=null)
                    {
                        service.deleteUser(userLoad);
                        updateGridAndHideAllAdmins();
                        clearUserAtAll();
                    }
                    else
                        if(service.deleteUser(new User(un.getValue(),"","",false)))
                        {
                            updateGridAndHideAllAdmins();
                            clearUserAtAll();
                        }
                        else
                            Notification.show("User not found!\nPlease try again");
                }
                else
                    if(userToDel==null)
                        Notification.show("User not found!\nPlease try again");
                else
                    Notification.show("Only current admin can change his details!", 2000, Notification.Position.BOTTOM_CENTER);
        });
        addBtn.addClickListener((t) -> {
            checkPassword();
            checkStatusUser();
            if(!thereIsPwProblem && statusUserClicked)
            {
                    boolean isTeacher=false;
                    if(trBtn.getText().length()>17)
                        isTeacher=true;
                    if(service.addUser(new User(un.getValue(),pw.getValue(),nameOfUser.getValue(),isTeacher)))
                    {
                        updateGridAndHideAllAdmins();
                        clearUserAtAll();
                    }
                    else
                        Notification.show("User not added!\nTry other user name!");
            }
            else
                Notification.show("User not added!\nCheck password and status");
        });
        cnclUserLod.addClickListener(t->{
          clearUserAtAll();
        });
    }
    private void clearStatus()
    {
        statusUserClicked=false;
        trBtn.setText("I'm a teacher!");
        stBtn.setText("I'm a student!");
    }

    private void clearUserAtAll() {
        adminBtnClicked=false;
        setCorrectColorForAdminBtn();
        userLoad=null;
        un.setValue("");
        pw.setValue("");
        theUserLoadName.setValue("");
        nameOfUser.setValue("");
        clearStatus();
    }
    private void setCorrectColorForAdminBtn()
    {
        if(adminBtnClicked)
                admin.getStyle().set("background-color","red");
            else
                admin.getStyle().set("background-color","grey");
    }
    private User getCurrentUser()
    {
        return service.getUserById((String) VaadinSession.getCurrent().getAttribute("UserName"));
    }
    private void updateGridAndHideAllAdmins()
    {
        List<User> allUsers=service.getAllUsers();
        User cureentUser=getCurrentUser();
        for (int i = 0; i < allUsers.size(); i++) {
            String userPswd=allUsers.get(i).getPassword();
            if(allUsers.get(i).isAdmin() && !allUsers.get(i).getName().equals(cureentUser.getName()))
                allUsers.get(i).setPassword("****"+userPswd.charAt(userPswd.length()-1));
        }
        usersGrid.setItems(allUsers);
    }
}
