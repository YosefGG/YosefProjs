package NewChessLearningNew.Views;

import NewChessLearningNew.Models.User;
import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import java.util.NoSuchElementException;
@Route("login")
public class LoginView extends VerticalLayout{
    private UserService service;
    private H1 title;
    private TextField un;
    private TextField up;
    private Button login;
    private Button signUp;
    public LoginView(UserService service)
    {
        this.service=service;
        title = new H1();
        un=new TextField("Enter userName");
        up=new TextField("Password");
        login = new Button("login");
        signUp = new Button("Sign up");
        handleSignUpClicked();
        handleLoginClicked();
        setLocationForComponents();
        setIconForTitle(100, 100);
        add(title,un,up,new HorizontalLayout(login,signUp));
    }
    private void setLocationForComponents()
    {
        setAlignItems(Alignment.CENTER);
    }
    private void handleSignUpClicked()
    {
        signUp.addClickListener(t->{
            signUp.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/signUp"));
        });
    }
    private void setIconForTitle(int height,int width)
    {
        Image img=new Image("imgs/softWareEngineerIcon.jpg"," ");
        img.setHeight(height+"px");
        img.setWidth(width+"px");
        title.add(img);
    }
    private void handleLoginClicked() {
        login.addClickListener((t) -> {
            User user = this.service.getUserById(un.getValue());
            try
            {
                if(user!=null && user.getPassword().equals(up.getValue()))
                {
                    Notification.show("Correct! Hello "+un.getValue()+"!\n We loading the page for you!");
                    VaadinSession.getCurrent().setAttribute("UserName", un.getValue());
                    login.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves"));
                }
                else
                {
                    Notification.show("User name or password arren't correct please try again or sign up!");
                }
            }
            catch(NoSuchElementException d)
            {
                Notification.show("User name or password arren't correct please try again or sign up!");
            }
        });
    }
    
}
