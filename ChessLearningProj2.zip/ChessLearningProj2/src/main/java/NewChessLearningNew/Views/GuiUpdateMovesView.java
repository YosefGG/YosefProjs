package NewChessLearningNew.Views;

import NewChessLearningNew.Models.Move;
import NewChessLearningNew.Models.Location;
import NewChessLearningNew.Models.BoardDesign;
import NewChessLearningNew.Models.MovesModel;
import NewChessLearningNew.Models.Piece;
import NewChessLearningNew.Run.IconsPieces;
import NewChessLearningNew.Run.Pieces;
import NewChessLearningNew.Services.*;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import java.util.ArrayList;
@Route("guiUpdate")
public class GuiUpdateMovesView extends VerticalLayout{
    private Button[] blackPieces;
    private Button[] whitePieces;
    private Button[][] board;
    private BoardDesign boardModel;
    private Button resetBoardBtn;
    private Button delPieceBtn;
    private Button createMoveStateBtn;
    private TextField txtNameMove;
    private MovesModelService service;
    private boolean createBtnClicked;
    private TextArea txtMoves;
    private ArrayList<Move> moves;
    private Button addNewMoves;
    private Piece[][] newBoard;
    private TextArea msg;
    private IconsPieces icons;
    private Button classicBoard;
    private TextField pawnChanging;
    public GuiUpdateMovesView(MovesModelService service)
    {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        pawnChanging=new TextField("Pawn changing");
        classicBoard=new Button("Create classic board");
        icons=new IconsPieces();
        msg=new TextArea("Give an explain");
        addNewMoves=new Button("Add new Moves");
        moves=new ArrayList<Move>();
        txtMoves=new TextArea("Moves:");
        createBtnClicked=false;
        this.service=service;
        createMoveStateBtn=new Button("Create Move");
        txtNameMove=new TextField("Name of move");
        resetBoardBtn=new Button("Reset board");
        delPieceBtn=new Button(new Icon(VaadinIcon.TRASH));
        boardModel=new BoardDesign();
        blackPieces=new Button[6];
        whitePieces=new Button[6];
        board=new Button[8][8];
        initSystem();
    }
    public void buildBoardDefulat()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j].setIcon(icons.getApropatePiece(Pieces.EMPTY_SIGN));
            }
        }
    }
    private String getApropateColor(Location loc)
    {
        int row=loc.getRow();
        int col=loc.getCol();
        if(((row%2==0)&&col%2>0)||(row%2>0&&(col%2==0)))
            return " green";
        return "black";
    }
    public void btnClickedOnBoard(Button btn)
    {
        int row=Integer.parseInt((btn.getId().get().charAt(0))+"");
        int col=Integer.parseInt((btn.getId().get().charAt(2))+"");
        if(boardModel.delBtnIsPressed())
        {
            boardModel.eraseMove(new Location(row,col));
            board[row][col].setIcon(icons.getApropatePiece(Pieces.EMPTY_SIGN));
            return;
        }
        if(!boardModel.thereIsPrevMoveNotDoingThing())
        {
            boardModel.setPrevMove(new Location(row,col));
            board[row][col].getStyle().set("background-color", "red");
            boardModel.setPrevMove(new Location(row,col));
        }
        else
        {
            boolean doSrcMove=true;
            Location prevMove=boardModel.getPrevMove();
            if(!boardModel.getPrevMove().equalsLocations(new Location(row,col)))
            {
                if(createBtnClicked)
                {
                    Piece sP=new Piece(boardModel.getBoard()[prevMove.getRow()][prevMove.getCol()]);
                    Piece dP=new Piece(boardModel.getBoard()[row][col]);
                    sP.setLoc(prevMove);
                    dP.setLoc(new Location(row,col));
                    if(pawnChanging.getValue().length()>0)
                    {
                        sP.setPiece(pawnChanging.getValue().charAt(0));
                        moves.add(new Move(new Location(prevMove),new Location(row,col),sP,dP,pawnChanging.getValue().charAt(0)));
                        doSrcMove=false;
                    }
                    else
                        moves.add(new Move(new Location(prevMove),new Location(row,col),sP,dP));
                    txtMoves.setValue(txtMoves.getValue()+","+moves.get(moves.size()-1).toString());
                }
                board[prevMove.getRow()][prevMove.getCol()].setIcon(icons.getApropatePiece(Pieces.EMPTY_SIGN));
                if(!doSrcMove)
                {
                    board[row][col].setIcon(icons.getApropatePiece(pawnChanging.getValue().charAt(0)));
                    boardModel.doMove(new Move(new Location(prevMove.getRow(),prevMove.getCol()),new Location(row,col)));
                    boardModel.getBoard()[row][col].setPiece(pawnChanging.getValue().charAt(0));
                    pawnChanging.setValue("");
                }
                else
                {
                    board[row][col].setIcon(icons.getApropatePiece(boardModel.getBoard()[prevMove.getRow()][prevMove.getCol()].getPiece()));
                    boardModel.doMove(new Move(new Location(prevMove.getRow(),prevMove.getCol()),new Location(row,col)));
                }
            }
            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", getColorOfLocationInBoard());
            boardModel.setPrevMoveDeafult();
        }
    }

    private String getColorOfLocationInBoard() {
        Location prevMove=boardModel.getPrevMove();
        int row=prevMove.getRow();
        int col=prevMove.getCol();
        if(((row%2==0)&&col%2>0)||(row%2>0&&(col%2==0)))
            return "green";
        return "black";
    }
    private void buildBoard()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(((i%2==0)&&j%2>0)||(i%2>0&&(j%2==0)))
                    board[i][j].getStyle().set("background-color"," green");
                else
                    board[i][j].getStyle().set("background-color"," black");
            }
        }
    }

    private void blackPieceClickedInArray(Button btn) {
        Location prevMove=boardModel.getPrevMove();
        if(boardModel.delBtnIsPressed())
        {
            boardModel.setDelBtnPressed(false);
            delPieceBtn.getStyle().set("background-color", " black");
        }
        if(boardModel.thereIsPrevMoveNotDoingThing()/*prevMove!=null*/)
        {
            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", " green");
            boardModel.setPrevMoveDeafult();
        }
        int pieceLoc=Integer.parseInt(btn.getId().get());
        if(boardModel.whitePieceClicked()/*whitePieceClickedLoc>-1*/)
        {
            whitePieces[boardModel.getWhitePieceClickedLoc()].getStyle().set("background-color", " green");
            boardModel.setWhitePieceClickedLoc(-1);
        }
        if(boardModel.blackPieceClicked()/*blackPieceClickedLoc>-1*/)
        {
            
            if(boardModel.twoBlackPieceNotEquals(boardModel.getBlackPieceClickedLoc(),pieceLoc))/*!(blackPieces[blackPieceClickedLoc].getId().get()).equals(blackPieces[pieceLoc].getId().get())*/
            {
                blackPieces[boardModel.getBlackPieceClickedLoc()].getStyle().set("background-color", " green");
                blackPieces[pieceLoc].getStyle().set("background-color", " red");
                boardModel.setBlackPieceClickedLoc(pieceLoc);
            }
            else
            {
                blackPieces[pieceLoc].getStyle().set("background-color", " green");
                boardModel.setBlackPieceClickedLoc(-1);
            }
        }
        else
        {
            boardModel.setBlackPieceClickedLoc(pieceLoc);
            blackPieces[pieceLoc].getStyle().set("background-color", " red");
        }

    }

    private void whitePieceClickedInArray(Button btn) {
        Location prevMove=boardModel.getPrevMove();
        if(boardModel.delBtnIsPressed())
        {
            System.out.println("1");
            boardModel.setDelBtnPressed(false);
            delPieceBtn.getStyle().set("background-color", " black");
        }
        if(boardModel.thereIsPrevMove())
        {
            System.out.println("2");
            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", " green");
            boardModel.setPrevMoveDeafult();
        }
        int pieceLoc=Integer.parseInt(btn.getId().get());
        if(boardModel.blackPieceClicked())
        {
            System.out.println("3");
            blackPieces[boardModel.getBlackPieceClickedLoc()].getStyle().set("background-color", " green");
            boardModel.setBlackPieceClickedLoc(-1);
        }
        if(boardModel.whitePieceClicked())
        {
            
            if(boardModel.twoWhitePieceNotEquals(boardModel.getWhitePieceClickedLoc(),pieceLoc))
            {
                System.out.println("4");
                whitePieces[boardModel.getWhitePieceClickedLoc()].getStyle().set("background-color", " green");
                whitePieces[pieceLoc].getStyle().set("background-color", " red");
                boardModel.setWhitePieceClickedLoc(pieceLoc);
            }
            else
            {
                System.out.println("5");
                whitePieces[pieceLoc].getStyle().set("background-color", " green");
                boardModel.setWhitePieceClickedLoc(-1);
            }
        }
        else
        {
            System.out.println("6");
            boardModel.setWhitePieceClickedLoc(pieceLoc);
            System.out.println("PieceLoc="+pieceLoc);
            whitePieces[pieceLoc].getStyle().set("background-color", " red");
        }

    }

    private void handleBlackPieceFromOutSideToInside(Button btn) {
        int row=Integer.parseInt(btn.getId().get().charAt(0)+"");
        int col=Integer.parseInt(btn.getId().get().charAt(2)+"");
        board[row][col].setIcon(icons.getApropatePiece(boardModel.getCorrectPieceByNum(blackPieces[boardModel.getBlackPieceClickedLoc()].getId().get(),true)));
        boardModel.bringBlackPieceToBoard(boardModel.getBlackPieceClickedLoc(), new Location(row, col));
    }

    private void handleWhitePieceFromOutSideToInside(Button btn) {
        int row=Integer.parseInt(btn.getId().get().charAt(0)+"");
        int col=Integer.parseInt(btn.getId().get().charAt(2)+"");
        board[row][col].setIcon(icons.getApropatePiece(boardModel.getCorrectPieceByNum(whitePieces[boardModel.getWhitePieceClickedLoc()].getId().get(),false)));
        boardModel.bringWhitePieceToBoard(boardModel.getWhitePieceClickedLoc(), new Location(row, col));
    }
    
    private Image loadImage(String fileName, int width, int height)
    {
        Image imgImage = new Image(fileName,"Image");
        if(width != -1 || height != -1)
        {
            imgImage.getStyle().set("width", width+"px");
            imgImage.getStyle().set("height", height+"px");
        }
        return imgImage;
    }

    private void handleDelBtnPressed() {
        if(boardModel.delBtnIsPressed())
        {
            if(boardModel.thereIsPrevMoveNotDoingThing())
            {
                Location loc=boardModel.getPrevMove();
                board[loc.getRow()][loc.getCol()].getStyle().set("background-color", " green");
                boardModel.setPrevMoveDeafult();
            }
            if(boardModel.whitePieceClicked())
            {
                whitePieces[boardModel.getWhitePieceClickedLoc()].getStyle().set("background-color", " green");
                boardModel.setWhitePieceClickedLoc(-1);
            }
            if(boardModel.blackPieceClicked())
            {
                blackPieces[boardModel.getBlackPieceClickedLoc()].getStyle().set("background-color", " green");
                boardModel.setBlackPieceClickedLoc(-1);
            }
            delPieceBtn.getStyle().set("background-color", " red");
        }
        else
        {
            System.out.println("dellllll");
            delPieceBtn.getStyle().set("background-color", " black");
        }
    }

    private void initSystem() {
        handleCreateAndNameBtns();
        classicBoard.addClickListener(t->{
            boardModel.createClassicBoard();
            buildBoardByModel();
        });
        resetBoardBtn.getStyle().set("background-color", " black");
        delPieceBtn.getStyle().set("background-color", " black");
        resetBoardBtn.addClickListener(t->{
            boardModel.initBoard();
            if(boardModel.thereIsPrevMoveNotDoingThing())
            {
                Location prevMove=boardModel.getPrevMove();
                int row=prevMove.getRow();
                int col=prevMove.getCol();
                board[row][col].getStyle().set("background-color"," "+getApropateColor(prevMove));
                boardModel.setPrevMoveDeafult();
            }
            boardModel.setDelBtnPressed(false);
            delPieceBtn.getStyle().set("background-color","black");
            buildBoardDefulat();
        });
        delPieceBtn.addClickListener(t->{
            boardModel.delBtnPressed();
            System.out.println("del="+boardModel.delBtnIsPressed());
            handleDelBtnPressed();
        });
        char[] blackPiecesNames={'P','R','B','N','K','Q'};
        char[] whitePiecesNames={'p','r','b','n','k','q'};

        for (int i = 0; i < 6; i++) {
             blackPieces[i]=new Button();
            whitePieces[i]=new Button();
            blackPieces[i].setId(i+"");
            whitePieces[i].setId(i+"");
            blackPieces[i].setIcon(icons.getApropatePiece(blackPiecesNames[i]));
            whitePieces[i].setIcon(icons.getApropatePiece(whitePiecesNames[i]));
            blackPieces[i].getStyle().set("background-color", "green");
            whitePieces[i].getStyle().set("background-color", "green");
            whitePieces[i].getStyle().set("width"," 80px");
            whitePieces[i].getStyle().set("height"," 80px");
            blackPieces[i].getStyle().set("width"," 80px");
            blackPieces[i].getStyle().set("height"," 80px");
            
            blackPieces[i].addClickListener((t)->{
                blackPieceClickedInArray(t.getSource());
//                blackPieceClickedLoc=Integer.parseInt(t.getSource().getId().get());
            });
            
            whitePieces[i].addClickListener((t)->{
                whitePieceClickedInArray(t.getSource());
//                whitePieceClickedLoc=Integer.parseInt(t.getSource().getId().get());
            });
        }
        
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j]=new Button();
                board[i][j].setId(i+","+j);
                board[i][j].getStyle().set("width"," 80px");
                board[i][j].getStyle().set("height"," 80px");
                board[i][j].getStyle().set("padding", "0");
                board[i][j].getStyle().set("margin", "0");
                board[i][j].addClickListener((t->{
                    
                    if(boardModel.blackPieceClicked())
                    {
                        handleBlackPieceFromOutSideToInside(t.getSource());
                        if(boardModel.thereIsPrevMove())
                        {
                            Location prevMove=boardModel.getPrevMove();
                            board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", "green");
                        }
                    }
                    
                    else
                        if(boardModel.whitePieceClicked())
                        {
                            handleWhitePieceFromOutSideToInside(t.getSource());
                            if(boardModel.thereIsPrevMove())
                            {
                                Location prevMove=boardModel.getPrevMove();
                                board[prevMove.getRow()][prevMove.getCol()].getStyle().set("background-color", "green");
                            }
                        }
                        else
                            if(boardModel.checkMoveOnBoard(new Location(Integer.parseInt(t.getSource().getId().get().charAt(0)+""),Integer.parseInt(t.getSource().getId().get().charAt(2)+""))))
                                btnClickedOnBoard(t.getSource());
                }
                ));
//                board[i][j].setSizeFull();
            }
        }
        
//        setAlignItems(Alignment.CENTER);
        buildBoard();
        add(new HorizontalLayout(new H1("Chess Board"),msg));
        add(new HorizontalLayout(blackPieces[0],blackPieces[1],blackPieces[2],blackPieces[3],blackPieces[4],blackPieces[5]));
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++) {
                board[i][j].getStyle().set("float"," left");
            }
            
            add(new HorizontalLayout(board[i][0],board[i][1],board[i][2],board[i][3],board[i][4],board[i][5],board[i][6],board[i][7]));
        }
//        for (int i = 0; i < 8; i++) {
//            for (int j = 0; j < 8; j++) {
////                board[i][j].getStyle().set("position"," fixed");
//                board[i][j].getStyle().set("float"," left");
//                board[i][j].getStyle().set("border"," 1px solid green");
//                
//            }
//        }
        Image img=new Image("/assets/pwanWhite.png", "My image");
        img.setWidth("16px");
        img.setHeight("16px");
//        blackPieces[0].setIcon(img);
//        addImagesForButtonsLists();
        add(new HorizontalLayout(whitePieces[0],whitePieces[1],whitePieces[2],whitePieces[3],whitePieces[4],whitePieces[5],delPieceBtn,resetBoardBtn));
        add(new HorizontalLayout(createMoveStateBtn,txtNameMove,addNewMoves,classicBoard,pawnChanging));
        setAlignItems(FlexComponent.Alignment.CENTER);
    }

    private void handleCreateAndNameBtns() {
        createMoveStateBtn.getStyle().set("background","green");
        createMoveStateBtn.getStyle().set("color","pink");
        createMoveStateBtn.addClickListener(t->{
            if(!createBtnClicked)
            {
                createBtnClicked=true;
                createMoveStateBtn.getStyle().set("background","red");
                createNewBoardByBtns();
            } 
            else
            {
                createBtnClicked=false;
                createMoveStateBtn.getStyle().set("background","green");
            }
        });
        addNewMoves.addClickListener(t->{
            MovesModel newMovesModel=new MovesModel(moves, newBoard, msg.getValue(),txtNameMove.getValue());
            Notification.show("Add!!!");
            service.addMovesModel(newMovesModel);
        });
    }
    private void createNewBoardByBtns()
    {
        char pieceName;
        newBoard=new Piece[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                newBoard[i][j]=new Piece(boardModel.getBoard()[i][j]);
            }
        }
    }
    private void buildBoardByModel()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j].setIcon(icons.getApropatePiece(boardModel.getBoard()[i][j].getPiece()));
            }
        }
    }
}
