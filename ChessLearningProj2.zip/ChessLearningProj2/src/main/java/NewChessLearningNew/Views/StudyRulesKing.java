package NewChessLearningNew.Views;

import NewChessLearningNew.Models.User;
import NewChessLearningNew.Models.UserMovesModelSize;
import NewChessLearningNew.Services.MovesModelService;
import NewChessLearningNew.Services.UserService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;
import java.util.ArrayList;

@Route("/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules/king")
public class StudyRulesKing extends VerticalLayout{
    private H1 title;
    private MovesModelService service;
    private UserService userService;
    private Button backWardPage;
    private Button rule_1;
    private Button rule_2;
    private Button rule_3;
    private Button rule_4;
    private Button rule_5;
    
    public StudyRulesKing(MovesModelService service,UserService userService) {
        if(VaadinSession.getCurrent().getAttribute("UserName")==null)
            UI.getCurrent().navigate("http://localhost:8080/login");
        this.service=service;
        this.userService=userService;
        Icon icon=new Icon(VaadinIcon.REPLY);
        icon.getStyle().set("height", 50+"px");
        icon.getStyle().set("width",50+"px");
        backWardPage=new Button(icon);
        title=new H1("The King");
        rule_1=new Button("King rule #1");
        rule_2=new Button("Learn Check");
        rule_3=new Button("Learn Checkmate");
        rule_4=new Button("Learn Pat");
        rule_5=new Button("Learn Castle");
        backWardPage.setHeight(100+"px");
        backWardPage.setWidth(100+"px");
        setSizeForButtons(80, 800);
        handleButtonsClickedListener();
        setFontSize(60);
        setColorForButtons();
        showStudyProceed();
        add(title,backWardPage,rule_1,rule_2,rule_3,rule_4,rule_5);
        this.setAlignItems(FlexComponent.Alignment.CENTER);
        
    }
    private void setSizeForButtons(int height,int width)
    {
        
        rule_1.setHeight(height+"px");
        rule_1.setWidth(width+"px");
        rule_2.setHeight(height+"px");
        rule_2.setWidth(width+"px");
        rule_3.setHeight(height+"px");
        rule_3.setWidth(width+"px");
        rule_4.setHeight(height+"px");
        rule_4.setWidth(width+"px");
        rule_5.setHeight(height+"px");
        rule_5.setWidth(width+"px");
        
    }
    private void setColorForButtons()
    {
        rule_1.getStyle().set("background", "black");
        rule_2.getStyle().set("background", "black");
        rule_3.getStyle().set("background", "black");
        rule_4.getStyle().set("background", "black");
        rule_5.getStyle().set("background", "black");
        backWardPage.getStyle().set("background", "black");
        rule_1.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        rule_2.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        rule_3.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        rule_4.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        rule_5.getStyle().set("text-shadow","-1px 0px 0px red," +
                                    "1px 0px 0px red," +
                                    "0px -1px 0px red," +"0px 1px 0px red");
        this.getStyle().set("background", "gray");
    }
    private void setFontSize(int size)
    {
        rule_1.getStyle().set("font-size",size+"px");
        rule_2.getStyle().set("font-size",size+"px");
        rule_3.getStyle().set("font-size",size+"px");
        rule_4.getStyle().set("font-size",size+"px");
        rule_5.getStyle().set("font-size",size+"px");
        backWardPage.getStyle().set("font-size",size+"px");
    }
    private void handleButtonsClickedListener()
    {
        backWardPage.addClickListener(t->{
            backWardPage.getUI().ifPresent(ui -> ui.navigate("http://localhost:8080/login/ChoiceOfBoardOrMoves/studyChoiceView/studyRules"));
        });
        rule_1.addClickListener(t->{
            UI.getCurrent().navigate(MovesView.class,"Study-King1");
        });
        rule_2.addClickListener(t->{
            UI.getCurrent().navigate(MovesView.class,"Study-King2");
        });
        rule_3.addClickListener(t->{
            UI.getCurrent().navigate(MovesView.class,"Study-King3");
        });
        rule_4.addClickListener(t->{
            UI.getCurrent().navigate(MovesView.class,"Study-King4");
        });
        rule_5.addClickListener(t->{
            UI.getCurrent().navigate(MovesView.class,"Study-King5");
        });
    }
    private void showStudyProceed()
    {
        User cUser=userService.getUserById(VaadinSession.getCurrent().getAttribute("UserName").toString());
        ArrayList<UserMovesModelSize> moves=cUser.getMaxIndexsOfMovesModel();
        rule_1.setText(rule_1.getText()+"       "+moves.get(16).getProccedInfo()+"%");
        rule_2.setText(rule_2.getText()+"       "+moves.get(17).getProccedInfo()+"%");
        rule_3.setText(rule_3.getText()+"       "+moves.get(18).getProccedInfo()+"%");
        rule_4.setText(rule_4.getText()+"       "+moves.get(19).getProccedInfo()+"%");
        rule_5.setText(rule_5.getText()+"       "+moves.get(20).getProccedInfo()+"%");
    }
}
