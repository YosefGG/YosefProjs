package Networking;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Objects;

public class AppSocket {
private Socket socket;
private Socket cmdSocket;
private Socket menuSocket;
private String id;
private ObjectInputStream is;
private ObjectOutputStream os;
private ObjectInputStream isCmd;
private ObjectOutputStream osCmd;
private ObjectInputStream isMenu;
private ObjectOutputStream osMenu;

public AppSocket(Socket socket,Socket cmdSocket)
{
    this.socket = socket;
    this.cmdSocket=cmdSocket;
    this.id = id;
    try {
        os=new ObjectOutputStream(this.socket.getOutputStream());
        is=new ObjectInputStream(this.socket.getInputStream());
        osCmd=new ObjectOutputStream(this.cmdSocket.getOutputStream());
        isCmd=new ObjectInputStream(this.cmdSocket.getInputStream());
    } 
    catch (Exception ex) {
        System.out.println("Constructor");
    }
    
    
}
public AppSocket(Socket socket, String id) 
{
    this.socket = socket;
    this.id = id;
    try {
        os=new ObjectOutputStream(this.socket.getOutputStream());
        is=new ObjectInputStream(this.socket.getInputStream());
    } catch (Exception ex) {
        System.out.println("Constructor");
    }
    
}
public AppSocket(Socket socket)
{
    this.socket=socket;
     try {
        os=new ObjectOutputStream(this.socket.getOutputStream());
        is=new ObjectInputStream(this.socket.getInputStream());
     } catch (Exception ex) {
        System.out.println("Constructor");
    }
}
public AppSocket(Socket socket, Socket cmdSocket, Socket menuSocket) 
{
    this.socket = socket;
    this.cmdSocket = cmdSocket;
    this.menuSocket = menuSocket;
    try {
        os=new ObjectOutputStream(this.socket.getOutputStream());
        is=new ObjectInputStream(this.socket.getInputStream());
        osCmd=new ObjectOutputStream(this.cmdSocket.getOutputStream());
        isCmd=new ObjectInputStream(this.cmdSocket.getInputStream());
        osMenu=new ObjectOutputStream(this.menuSocket.getOutputStream());
        isMenu=new ObjectInputStream(this.menuSocket.getInputStream());
    } 
    catch (Exception ex) {
        System.out.println("Constructor");
    }
}
public String getID()
{
    return id;

}
public void setID(String id)
{
    this.id=id;
}
public String getIP()
{
    return socket.getLocalAddress().toString();
}
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AppSocket other = (AppSocket) obj;
        return Objects.equals(this.socket, other.socket);
    }
public boolean writeMsg(Message msg)
{
    try
    {
        os.writeObject(msg);
        os.flush();
    }
    catch(Exception ex)
    {
        System.out.println("Class:AppSocket - writeMsg");
        return false;
    }
    return true;
}
public boolean writeCmdMsg(String msg)
{
    try
    {
        osCmd.writeObject(msg);
        osCmd.flush();
    }
    catch(Exception ex)
    {
        System.out.println("Class:AppSocket - writeMsg");
        return false;
    }
    return true;
}
public Message readMsg()
{
    try 
    {
        Message msg = (Message)is.readObject();
        return msg;
    }
    catch (Exception ex)
    {
        System.out.println("Class: AppSocket - readMsg");
        return new Message("Disconnected");
    }
}
public void disconnectSocket() 
{
    try
    {
        socket.close();
    }
    catch(Exception ex)
    {
        System.out.println("Class:AppSocket - disconnectSocket");
    }
}
public Message readMenuMsg()
{
     try 
    {
        Message msg = (Message)isMenu.readObject();
        System.out.println("-------------------------------");
        return msg;
    }
    catch (Exception ex)
    {
        System.out.println("Class: AppSocket - readMsg");
        return new Message("Disconnected");
    }
}
public boolean writeMenuMsg(Message msg) 
{
    try
    {
        osMenu.writeObject(msg);
        osMenu.flush();
    }
    catch(Exception ex)
    {
        System.out.println("Class:AppSocket - writeMenuMsg");
        return false;
    }
    return true;
}
public void disconnectMenuSocket() 
{
    try
    {
        menuSocket.close();
    }
    catch(Exception ex)
    {
        System.out.println("Class:AppSocket - disconnectSocket");
    }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
