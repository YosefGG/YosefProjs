package Networking;

import ChessClasses.Location;
import ChessClasses.View;
import java.awt.BorderLayout;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ClientGame {

    private JTextField messageWrite;
    private JTextArea chatShower;
    private JFrame win;
    private AppSocket appSocket;
    private View view;
    private String name;
    public ClientGame() {
        view=new View(this);
        messageWrite = null;
        chatShower = null;
    }
    
    public Socket getDataFromClient() {

        String messageIP = "Enter the Server's IP address";
        String messagePort = "Enter the Server's port";
        String inputIP="192.168.211.104";
        String inputPort="1111";
        Socket socket = null;
        boolean doLoop;
        int port = -1;
        do {
            doLoop = false;
            try
            {
                inputIP = (String) JOptionPane.showInputDialog(win, messageIP, "IP request", JOptionPane.DEFAULT_OPTION,null,null,""+inputIP);
                inputPort = (String) JOptionPane.showInputDialog(win, messagePort, "Port request", JOptionPane.DEFAULT_OPTION,null,null,"1111");
                port = Integer.parseInt(inputPort);
                socket = new Socket(inputIP, port);
            } 
            catch (Exception ex) 
            {
                doLoop = true;
            }

        } while (doLoop);

        return socket;
    }
    public void getClientConnect() {
        Socket socketForAppSocket=null;
        Socket socketForCmd=null;
        Socket socketForMenu=null;
        try {
            socketForAppSocket = getDataFromClient();//new Socket("192.168.56.1",1111);
            socketForCmd = new Socket(socketForAppSocket.getInetAddress().getHostAddress(),socketForAppSocket.getPort());
            socketForMenu = new Socket(socketForAppSocket.getInetAddress().getHostAddress(),socketForAppSocket.getPort());
            appSocket = new AppSocket(socketForAppSocket,socketForCmd,socketForMenu);
            view.showDialogForStart();
            name=(appSocket.readMsg()).getMsg();
            view.giveNumberOfGame(name);
            readFromServer();//מקביליות
        }
        catch (Exception ex) {
        }
    }

    public void readFromServer() {
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {

                while (true) {
                    Message msg=appSocket.readMsg();
                    if(msg.getSubject().equals("Disconnected"))
                    {
                        view.closeGameServerIsShatDown();
                        break;
                    }
                    String welcome = msg.getMsg();
                    sendTotheRightFunction(msg);
                }
            }
        });
        t1.start();

    }

    public void createGUI(String name) {
        win = new JFrame("Chater number" + name);
        win.setTitle("");
        win.setSize(400, 400);
        win.setLocationRelativeTo(null);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.setLayout(new BorderLayout());
        win.setTitle("I am chater number #" + name);
        chatShower = new JTextArea();
        messageWrite = new JTextField();
        win.add(chatShower, BorderLayout.CENTER);
        chatShower.setEditable(false);
        win.setVisible(true);
    }

    public void btnPressed(Location loc)
    {
        Message msg=new Message("btnPressed");
        msg.setLoc(loc);
        sendToServer(msg);
    }
    public void setUp(int num)
    {
        Message msg=new Message("setUpMenu");
        msg.setNum(num);
        sendToserverMenuMsg(msg);
    }
    public void setUp1()
    {
        sendToServer(new Message("setUp1"));
    }
    public void plyaerPlaying(String player)
    {
        Message msg = new Message(player);
        msg.setMsg(player);
        sendToServer(msg);
    }
    public void sendTotheRightFunction(Message msg)
    {
        switch(msg.getSubject()) {
            case "showWaitingForFlayerToConnected":view.showWaitingForFlayerToConnected();
                                                   break;
            case "disableBtns":view.disableBtns();
                               break;
            case "enableBtns":view.enableBtns();
                              break;
            case "setUp":view.setUp(msg.getPiece2d());
                         break;
            case "flipBoardForBlack":
                                     view.flipBoardForBlack(msg.getPiece2d());
                                     break;
            case "buildBoard":
                              view.buildBoard();
                              break;
            case "showPossibleSrc":
                                   view.showPossibleSrc(msg.getLoc());
                                   break;
            case "showPossibleMoves":
                                    view.showPossibleMoves(msg.getArrayLoc());
                                    break; 
            case "ShowWinnerByMate":
                                    view.ShowWinnerByMate(msg.getCh(),msg.getPiece2d());
                                    break;
            case "changeForPwan":
                                view.changeForPwan(msg.getMove());
                                break;
            case "showPat":
                           view.showPat(msg.getPiece2d());
                           break;
            case "showDraw":
                           view.showDraw(msg.getPiece2d());
                           break; 
            case "updateCurrentPlayer":
                                       view.updateCurrentPlayer(msg.getCh());
                                       break;
            case "updateCurrentPlayerDeafult":
                                               view.updateCurrentPlayerDeafult();
                                               break;
            case "showCheckOnKing":
                                   view.showCheckOnKing(msg.getLoc());
                                   break;
            case "setColorPlayer":
                                  view.SetColorPlayer(msg.getCh());
                                  break;
            case "closeGameOponentGivesUp":
                                           view.closeGameOponentGivesUp();
                                           break;
            case "checkingConnect":break;
            default:
                    view.clearBorders();
        }
    }
    
   
    public void windowClose() {
        try
        {
            appSocket.writeCmdMsg("Disconnected");
        }
        catch(Exception e){}
        System.exit(0);
    }
    public void sendToServer(Message msg)
    {
        try
        {
            appSocket.writeMsg(msg);
        }
        catch(Exception e){};
    }
    public void sendToserverMenuMsg(Message msg)
    {
        try
        {
            System.out.println(msg.getSubject());
            appSocket.writeMenuMsg(msg);
        }
        catch(Exception e)
        {
            System.out.println("Menu msg - ClientGame");
        }
    }
     public static void main(String[] args) {
        ClientGame client = new ClientGame();
        client.getClientConnect();
        
    }

}
