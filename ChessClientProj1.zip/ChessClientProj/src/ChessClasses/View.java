package ChessClasses;

import ChessClasses.Location;
import ChessClasses.Move;
import ChessClasses.Piece;
import Networking.ClientGame;
import Networking.Message;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;    
                                                                                        
public class View {
    private final ImageIcon iconPwanWhite=loadImage("/assets/pwanWhite.png", (int)(0.7 * 75), (int)(0.7 * 95));
    private final ImageIcon iconKingWhite=loadImage("/assets/kingWhite.png", (int)(0.7 * 95), (int)(0.7 * 95));
    private final ImageIcon iconQueenWhite=loadImage("/assets/queenWhite.png", (int)(0.7 * 105), (int)(0.7 * 95));
    private final ImageIcon iconknightWhite=loadImage("/assets/knightWhite.png", (int)(0.7 * 80), (int)(0.7 * 95));
    private final ImageIcon iconBishopWhite=loadImage("/assets/bishopWhite.png", (int)(0.7 *95), (int)(0.7 * 95));
    private final ImageIcon iconRookWhite=loadImage("/assets/rookWhite.png", (int)(0.7 * 85), (int)(0.7 * 90));
    private final ImageIcon iconPwanBlack=loadImage("/assets/pwanBlack.png", (int)(0.7 * 75), (int)(0.7 * 95));
    private final ImageIcon iconKingBlack=loadImage("/assets/kingBlack.png", (int)(0.7 * 95), (int)(0.7 * 95));
    private final ImageIcon iconQueenBlack=loadImage("/assets/queenBlack.png", (int)(0.7 * 105), (int)(0.7 * 95));
    private final ImageIcon iconknightBlack=loadImage("/assets/knightBlack.png", (int)(0.7 * 80), (int)(0.7 * 95));
    private final ImageIcon iconBishopBlack=loadImage("/assets/bishopBlack.png", (int)(0.7 * 95), (int)(0.7 * 95));
    private final ImageIcon iconRookBlack=loadImage("/assets/rookBlack.png", (int)(0.7 * 85), (int)(0.7 * 90));
    
    private JFrame win=new JFrame();
    
    
    private JButton[][] btnBoard=new JButton[8][8];
    private JLabel currentPlayerLabel=new JLabel("");
    private JLabel statusLabel=new JLabel("");
    private final Color brightBrown=new Color(239,228,176);
    private final Color brown=new Color(189,116,55);
    private ClientGame client;
    public final char WHITE_TURN = 'W';
    public final char BLACK_TURN = 'B';
    private Color colorPlayer;
    private String playerSign;
    private JButton setUpEndGameBtn;
    
    public View(ClientGame client)
    {
        this.client=client;
        createAndShowGui();
    }
    public void SetColorPlayer(char colorPlayer)
    {
        if(colorPlayer=='W')
            this.colorPlayer=Color.white;
        else
            this.colorPlayer=Color.black;
    }
    public void createAndShowGui()
    {
        ImageIcon winIcon=loadImage("/assets/boardWinIcon.png", 30, 30);
        try
        {
            win.setIconImage(winIcon.getImage());
        }
        catch(Exception e){}
        Font btnsFont = new Font("", Font.PLAIN, 70);
        win.setTitle("");
        win.setSize(750, 725);
        win.setLocationRelativeTo(null);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.setLayout(new BorderLayout());
        setUpEndGameBtn=new JButton("SetUp end game");
        
        setMenuBar();
        JPanel topPnl=new JPanel();
        JPanel gamePnl=new JPanel();
        JPanel groundPnl=new JPanel();
        gamePnl.setLayout(new GridLayout(8,8));
        currentPlayerLabel.setForeground(Color.cyan);
        topPnl.setBackground(Color.black);
        topPnl.setForeground(Color.cyan);
        topPnl.add(currentPlayerLabel);
        groundPnl.setBackground(Color.black);
        statusLabel.setForeground(Color.cyan);
        groundPnl.add(statusLabel);
        handleActionLies();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                btnBoard[i][j]=new JButton();//board[i][j]
                btnBoard[i][j].setActionCommand(i+","+j);
                btnBoard[i][j].setFont(btnsFont);
                btnBoard[i][j].setBorder(null);
                if(i%2==0 && j%2==0 || i%2>0 && j%2>0)
                    btnBoard[i][j].setBackground(Color.blue);
                else 
                    btnBoard[i][j].setBackground(Color.darkGray);
                btnBoard[i][j].setFocusable(false);
                btnBoard[i][j].addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent e)
                    {
                        JButton btn = (JButton) e.getSource();
                        String indexs = btn.getActionCommand();
                        int row = Integer.parseInt(indexs.substring(0, indexs.indexOf(',')));
                        int col = Integer.parseInt(indexs.substring(indexs.indexOf(',')+1));
                        Location loc=new Location(row,col);
                        if(colorPlayer!=null && colorPlayer.equals(Color.black))
                            loc=new Location(7-row,7-col);
                        client.btnPressed(loc);
                    }
                });
                
                gamePnl.add(btnBoard[i][j]);
            }
        }
        win.add(groundPnl,BorderLayout.SOUTH);
        win.add(gamePnl, BorderLayout.CENTER);
        win.add(topPnl,BorderLayout.NORTH);
        win.setVisible(true);
        win.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {
            }

            @Override
            public void windowClosing(WindowEvent e) {
                client.windowClose();
            }

            @Override
            public void windowClosed(WindowEvent e) {
            }

            @Override
            public void windowIconified(WindowEvent e) {
            }

            @Override
            public void windowDeiconified(WindowEvent e) {
            }

            @Override
            public void windowActivated(WindowEvent e) {
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
            }
        });
        
        
    }

    private void handleActionLies()
    {
        setUpEndGameBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                client.setUp1();
            }
        });
    }
    public void setUp(Piece[][] boardStart) {//--------------1
        if(colorPlayer.equals(Color.black))
        {
            flipBoardForBlack(boardStart);
            return;
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(boardStart[i][j].getColor().equals(Color.white))
                {
                    switch(boardStart[i][j].getName())
                    {
                        case 'R':btnBoard[i][j].setIcon(iconRookWhite);
                                 break;
                        case 'N':btnBoard[i][j].setIcon(iconknightWhite);
                                 break;
                        case 'B':btnBoard[i][j].setIcon(iconBishopWhite);
                                 break;
                        case 'Q':btnBoard[i][j].setIcon(iconQueenWhite);
                                 break;
                        case 'K':btnBoard[i][j].setIcon(iconKingWhite);
                                 break;
                        case 'p':btnBoard[i][j].setIcon(iconPwanWhite);
                                break;
                        default:btnBoard[i][j].setText(null);
                                 break;
                    }
                }
                else
                    switch(boardStart[i][j].getName())
                    {
                        case 'R':btnBoard[i][j].setIcon(iconRookBlack);
                             break;
                        case 'N':btnBoard[i][j].setIcon(iconknightBlack);
                                 break;
                        case 'B':btnBoard[i][j].setIcon(iconBishopBlack);
                                 break;
                        case 'Q':btnBoard[i][j].setIcon(iconQueenBlack);
                                 break;
                        case 'K':btnBoard[i][j].setIcon(iconKingBlack);
                                 break;
                        case 'p':btnBoard[i][j].setIcon(iconPwanBlack);
                                break;
                        default:btnBoard[i][j].setIcon(null);
                                 break;
                    }
            }
        }
        buildBoard();
    }
    public void flipBoardForBlack(Piece[][] boardStart)
    {
        int flipRow,flipCol;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                flipRow=7-i;
                flipCol=7-j;
                if(boardStart[i][j].getColor().equals(Color.white))
                {
                    switch(boardStart[i][j].getName())
                    {
                        case 'R':btnBoard[flipRow][flipCol].setIcon(iconRookWhite);
                                 break;
                        case 'N':btnBoard[flipRow][flipCol].setIcon(iconknightWhite);
                                 break;
                        case 'B':btnBoard[flipRow][flipCol].setIcon(iconBishopWhite);
                                 break;
                        case 'Q':btnBoard[flipRow][flipCol].setIcon(iconQueenWhite);
                                 break;
                        case 'K':btnBoard[flipRow][flipCol].setIcon(iconKingWhite);
                                 break;
                        case 'p':btnBoard[flipRow][flipCol].setIcon(iconPwanWhite);
                                break;
                        default:btnBoard[flipRow][flipCol].setText(null);
                                 break;
                    }
                }
                else
                    switch(boardStart[i][j].getName())
                    {
                        case 'R':btnBoard[flipRow][flipCol].setIcon(iconRookBlack);
                             break;
                        case 'N':btnBoard[flipRow][flipCol].setIcon(iconknightBlack);
                                 break;
                        case 'B':btnBoard[flipRow][flipCol].setIcon(iconBishopBlack);
                                 break;
                        case 'Q':btnBoard[flipRow][flipCol].setIcon(iconQueenBlack);
                                 break;
                        case 'K':btnBoard[flipRow][flipCol].setIcon(iconKingBlack);
                                 break;
                        case 'p':btnBoard[flipRow][flipCol].setIcon(iconPwanBlack);
                                break;
                        default:btnBoard[flipRow][flipCol].setIcon(null);
                                 break;
                    }
            }
        }
        buildBoardForBlackFlip();
    }
    private ImageIcon loadImage(String fileName, int width, int height)//--------------2
    {
        ImageIcon imgIcon=null;
        try
        {
            imgIcon = new ImageIcon(getClass().getResource(fileName));
            if(width != -1 || height != -1)
                imgIcon = new ImageIcon(imgIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
        }
        catch(Exception e){}
        return imgIcon;
    }
    public void updateBoardGame(Piece[][] board)////--------------3
    {
    }
    public void buildBoard()//--------------4
    {
        if(colorPlayer.equals(Color.black))
        {
            buildBoardForBlackFlip();
            return;
        }
        brightBrown.brighter();
        brown.brighter();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(i%2==0 && j%2==0 || i%2>0 && j%2>0)
                    btnBoard[i][j].setBackground(brightBrown);
                else 
                    btnBoard[i][j].setBackground(brown);
                btnBoard[i][j].setEnabled(true);
                btnBoard[i][j].setBorder(null);
            }
        }
    }
    public void buildBoardForBlackFlip()
    {
        brightBrown.brighter();
        brown.brighter();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(i%2==0 && j%2==0 || i%2>0 && j%2>0)
                    btnBoard[i][j].setBackground(brown);
                else 
                    btnBoard[i][j].setBackground(brightBrown);
                btnBoard[i][j].setEnabled(true);
                btnBoard[i][j].setBorder(null);
            }
        }
    }
    public void showPossibleSrc(Location loc)//--------------5
    {
        if(colorPlayer.equals(Color.black))
        {
            showPossibleSrcForBlack(loc);
            return;
        }
        Color gold=new Color(255,180,0);
        btnBoard[loc.getRow()][loc.getCol()].setBackground(gold);
    }
    public void showPossibleMoves(ArrayList<Location> PossibleMoves) {//--------------6
        if(colorPlayer.equals(Color.black))
        {
            showPossibleMovesForBlack(PossibleMoves);
            return;
        }
        Color colorDarkRed=new Color(255,30,24);
        Color colorLightRed=new Color(255,83,75);
        colorDarkRed.darker();
        colorLightRed.brighter();
        for (int i = 0; i < PossibleMoves.size(); i++) {
            int row=PossibleMoves.get(i).getRow();
            int col=PossibleMoves.get(i).getCol();
            if(btnBoard[row][col].getBackground()==brown)
                btnBoard[row][col].setBackground(colorDarkRed);
            else
                btnBoard[row][col].setBackground(colorLightRed);
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(!btnBoard[i][j].getBackground().equals(colorDarkRed))
                    if(!btnBoard[i][j].getBackground().equals(colorLightRed))
                        if(btnBoard[i][j].getIcon()==null)
                            btnBoard[i][j].setEnabled(false);
            }
        }
    }
    public void showPossibleSrcForBlack(Location loc)//--------------5
    {
        Color gold=new Color(255,180,0);
        btnBoard[7-loc.getRow()][7-loc.getCol()].setBackground(gold);
    }
    public void showPossibleMovesForBlack(ArrayList<Location> PossibleMoves) {//--------------6
        for (int i = 0; i < PossibleMoves.size(); i++) {
        }
        Color colorDarkRed=new Color(255,30,24);
        Color colorLightRed=new Color(255,83,75);
        colorDarkRed.darker();
        colorLightRed.brighter();
        for (int i = 0; i < PossibleMoves.size(); i++) {
            int row=7-PossibleMoves.get(i).getRow();
            int col=7-PossibleMoves.get(i).getCol();
            if(btnBoard[row][col].getBackground()==brown)
                btnBoard[row][col].setBackground(colorDarkRed);
            else
                btnBoard[row][col].setBackground(colorLightRed);
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(!btnBoard[i][j].getBackground().equals(colorDarkRed))
                    if(!btnBoard[i][j].getBackground().equals(colorLightRed))
                        if(btnBoard[i][j].getIcon()==null)
                            btnBoard[i][j].setEnabled(false);
            }
        }
    }
    public void addToMenuBarSetUps()
    {
        JMenu setUp=new JMenu("Set up");
        JMenuItem[] setUps=new JMenuItem[5];
        setSetUpEndGame(setUps);
        setUp.add(setUps[0]);
//        setUp.add(setUps[1]);
//        setUp.add(setUps[2]);
//        setUp.add(setUps[3]);
        setUp.add(setUps[4]);
        win.getJMenuBar().add(setUp);
    }
    public void setMenuBar()//--------------7
    {
        JMenuBar menuBar=new JMenuBar();
        menuBar.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        JMenu aboutMenu = new JMenu("About");
        JMenuItem rules = new JMenuItem("Game & Rules");
        JMenuItem creditsMenuItem = new JMenuItem("Credits");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        aboutMenu.add(rules);
        aboutMenu.add(creditsMenuItem);
        aboutMenu.add(exitMenuItem);
        menuBar.add(aboutMenu);
        setExit(exitMenuItem);
        setCredits(creditsMenuItem);
        setRules(rules);
        win.setJMenuBar(menuBar);
    }
    public void setRules(JMenuItem rules)//--------------9
    {
        String str=
                "The Game:\n"
                +"Chess is an abstract strategy game and involves no hidden information. It is played on a square chessboard with 64 squares arranged\n"
                +"in an eight-by-eight grid. At the start, each player (one controlling the white pieces, the other controlling the black pieces) controls\n"
                +"sixteen pieces: one king, one queen, two rooks, two bishops, two knights, and eight pawns\n"
                +"The object of the game is to checkmate the opponent's king, whereby the king is under immediate attack (in \"check\") and there is no way for it to escape.\n"
                +"ways a game can end in a draw.\n"
                +"The rules:\n"
                +"King moves:\n"
                +"The king moves one square in any direction. \nThere is also a special move called castling that involves moving the king and a rook. \nThe king is the most valuable piece — attacks"
                +"on the king must be immediately countered, and if this is impossible, immediate loss of the game ensues.\n"
                +"Rook moves:\n"
                +"A rook can move any number of squares along a rank or file, but cannot leap over other pieces.\n"
                +"Along with the king, a rook is involved during the king's castling move.\n"
                +"Bishop moves:\n"
                +"A bishop can move any number of squares diagonally, but cannot leap over other pieces.\n"
                +"Queen moves:\n"
                +"A queen combines the power of a rook and bishop and can move any number of squares along a rank, file, or diagonal, but cannot leap over other pieces.\n"
                +"Knight moves:\n"
                +"A knight moves to any of the closest squares that are not on the same rank, file, or diagonal. (Thus the move forms an \"L\"-shape: two squares vertically and one square horizontally, or two squares horizontally and one square vertically.) \n"
                +"The knight is the only piece that can leap over other pieces.\n"
                +"Pawn moves:\n"
                +"A pawn can move forward to the unoccupied square immediately in front of it on the same file, or on its first move it can advance two squares along the same file, provided both squares are unoccupied (black dots in the diagram).\n"
                +" A pawn can capture an opponent's piece on a square diagonally in front of it by moving to that square (black crosses). It cannot capture a piece while advancing along the same file. \n"
                +"A pawn has two special moves: the en passant capture and promotion.";
        rules.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(win, str, "Rules", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }
    
    public void setCredits(JMenuItem credits)//--------------14
    {
        String msg="Engine by Yosef buskila\n"
                +"Icons desined by Orel yanay";
        
        ImageIcon softWareEngineerIcon=loadImage("/assets/softWareEngineerIcon.png", 60, 60);
        credits.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(win,msg,"Game credits",JOptionPane.PLAIN_MESSAGE,softWareEngineerIcon);
            }
        });
    }
    public void setExit(JMenuItem exit)//--------------15
    {
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                client.windowClose();
            }
        });
    }
    private void setSetUpEndGame(JMenuItem[] endGameState)
    {
        
        for (int i = 0; i < 5; i++) {
            endGameState[i]=new JMenuItem("Set up #"+(i+1));
            endGameState[i].setActionCommand(""+(i+1));
            endGameState[i].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int num=1;
                try
                {
                    num=Integer.parseInt(((JMenuItem)e.getSource()).getActionCommand());
                }
                catch(Exception t)
                {
                    num=1;
                }
                client.setUp(num);
            }
        });
            
        }
        endGameState[0].setText("Classic state");
        endGameState[4].setText("End game state");
        
    }
    public void ShowWinnerByMate(char currentPlayer,Piece[][] board) {//--------------17
        String msg;
        if(currentPlayer=='B')
            msg="The winner is Black";
        else
            msg="The winner is White";
        statusLabel.setText(msg);
        countBackForEndGame(board);
    }
    public void changeForPwan(Move move)//--------------18
    {
        if(move.getSrcPiece().getColor()==Color.white)
            btnBoard[move.getSrcLoc().getRow()][move.getSrcLoc().getCol()].setIcon(iconQueenWhite);
        else
            btnBoard[move.getSrcLoc().getRow()][move.getSrcLoc().getCol()].setIcon(iconQueenBlack);
    }

    public void showPat(Piece[][] board) {//--------------19
        String msg="Pat!\nGood game!";
        statusLabel.setText(msg);
        countBackForEndGame(board);
    }

    public void showDraw(Piece[][] board) {//--------------20
        String msg="Draw!\nGood game!";
        statusLabel.setText(msg);
        countBackForEndGame(board);
    }
    public void countBackForEndGame(Piece[][] board)
    {
        String winner=statusLabel.getText();
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (long i = 5; i > 0; i--) {
                    statusLabel.setText(winner+", Game restart! in "+i);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }       
                setUp(board);
            }
        }).start();
    }
    public void updateCurrentPlayer(char currentPlayer)//--------------21
    {
        if(currentPlayer==WHITE_TURN)
        {
            if(colorPlayer.equals(Color.black))
                statusLabel.setText("Play turn");
            else 
                statusLabel.setText("Wait turn");
        }
        else
        {
            if(colorPlayer.equals(Color.white))
                statusLabel.setText("Play turn");
            else 
                statusLabel.setText("Wait turn");
        }
    }
    public void updateCurrentPlayerDeafult()//--------------22
    {
        updateCurrentPlayer(BLACK_TURN);
        if(colorPlayer.equals(Color.white))
           playerSign="You're playing white!";
        else
            playerSign="You're playing black!";
        currentPlayerLabel.setText(playerSign);
    }

    public void showCheckOnKing(Location kingCheckPosition) {//--------------23
        if(kingCheckPosition!=null)
        {
            int row=kingCheckPosition.getRow();
            int col=kingCheckPosition.getCol();
            btnBoard[row][col].setBorder(BorderFactory.createLineBorder(Color.red,3));
        }
    }

    public void clearBorders() {//--------------24
        for (int i = 0; i < 8; i++) 
            for (int j = 0; j < 8; j++) 
                btnBoard[i][j].setBorder(null);
        
    }
    public void disableBtns()
    {
        for (int i = 0; i < 8; i++) 
            for (int j = 0; j < 8; j++) 
            {
                if(btnBoard[i][j].getIcon()!=null)
                    btnBoard[i][j].setDisabledIcon(btnBoard[i][j].getIcon());
                btnBoard[i][j].setEnabled(false);
            }
    }
    public void enableBtns()
    {
        for (int i = 0; i < 8; i++) 
            for (int j = 0; j < 8; j++) 
            {
                if(btnBoard[i][j].getIcon()!=null)
                    btnBoard[i][j].setIcon(btnBoard[i][j].getIcon());
                btnBoard[i][j].setEnabled(true);
            }
    }
    public void showWaitingForFlayerToConnected()
    {
        statusLabel.setText("Waiting for another player...");
    }
    public void giveNumberOfGame(String game)
    {
        win.setTitle(win.getTitle()+"Game #"+game);
    }
    public void showDialogForStart()
    {
        JFrame joptionFrame=new JFrame();
        JButton[] option=new JButton[2];
        option[0]=new JButton("AI");
        option[0].setActionCommand("AI");
        option[1]=new JButton("Player Net");
        option[1].setActionCommand("Online");
        for (int i = 0; i < 2; i++) {
            option[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    joptionFrame.setVisible(false);
                    JButton btn=(JButton)e.getSource();
                    client.plyaerPlaying(btn.getActionCommand());
                    if(btn.getActionCommand().equals("AI"))
                    {
                        win.setTitle(win.getTitle()+"-AI-");
                        addToMenuBarSetUps();
                    }
                    else
                        win.setTitle(win.getTitle()+"-Player Net-");
                }
            });
        }
        JOptionPane.showOptionDialog(joptionFrame, "What do you want to play?", "",
                JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,null, option, option[0]);
        showWaitingForFlayerToConnected();
        
    }
    
    public void closeGameOponentGivesUp() {
        JOptionPane.showMessageDialog(win, "Oponent disconnected you are the winner!");
        win.setVisible(false);
        System.exit(0);
    }
    public void closeGameServerIsShatDown()
    {
        JOptionPane.showMessageDialog(win, "Server is shat down, Dood bye:(");
        win.setVisible(false);
        System.exit(0);
    }

}