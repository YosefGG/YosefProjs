package ChessClasses;
import java.awt.Color;
import java.io.Serializable;

public class Piece implements Serializable{
    private final char ROOK='R';
    private final char KINGHT='N';
    private final char BISHOP='B';
    private final char QUEEN='Q';
    private final char KING='K';
    private final char PAWN='p';
    private final char EMPTY_SIGN=' ';
    private char name;
    private Color color;
    private int indexInArray;
    public Piece(char name, Color color) {
        this.name = name;
        this.color = color;
    }
    public Piece(char name, Color color,boolean doBuildsBoards) {
        this.name = name;
        this.color = color;
    }

    public Piece() {
        name='n';
        color=Color.CYAN;
    }
    
    public Piece(Piece piece) 
    {
        name=piece.getName();
        color=piece.getColor();
    }

    public int getIndexInArray() {
        return indexInArray;
    }

    public void setIndexInArray(int indexInArray) {
        this.indexInArray = indexInArray;
    }
    
    public char getName() {
        return name;
    }
    
    public Color getColor() {
        return color;
    }

    public void setName(char name) {
        this.name = name;
    }

    public void setColor(Color color) {
        this.color = color;
    }
    public int getScoreBypiece()
    {
        switch(name)
        {
            case KING:return 500;
            case PAWN:return 100;
            case KINGHT:return 300;
            case BISHOP:return 300;
            case ROOK:return 500;
            case QUEEN:return 900;
        };
        return 0;
    }
    @Override
    public String toString() {
        return "name=" + name + ", color=" + color + ", ";
    }
    
}