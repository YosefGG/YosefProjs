package ChessClasses;

import ChessClasses.Location;
import ChessClasses.Move;
import ChessClasses.State;
import ChessClasses.Piece;
import ChessClasses.State;
import java.util.ArrayList;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import Networking.ServerGame;

public class Game {
    private Player player1;
    private Player player2;
    private State state;
    private boolean WhileMove;
    private Location KeepLoc;
    private ServerGame server;
    private boolean keepGame;
    private boolean playerWon;
    public Game(Player player1,Player player2,ServerGame server)
    {
        playerWon=false;
        keepGame=true;
        this.server=server;
        WhileMove=false;
        state=player1.getState();
        this.player1=player1;
        this.player2=player2;
        player1.setGame(this);
        player2.setGame(this);
        startNewGameTheFirst();
    }
    public void startNewGameTheFirst() {
        state.setUp(1);
        state.setCurrentPlyer(Pieces_Signs.WHITE_TURN);
        state.resetCastle();
        player1.setUpBoard();
        player2.setUpBoard();
        player1.updateCurrentPlayerDeafult();//צריך לשנות לכל אחד אם תורו זה פה!!!!
        player2.updateCurrentPlayerDeafult();
        menageGame();
    }
    public void startNewGame() {
        playerWon=true;
        state.setUp(1);
        state.setCurrentPlyer(Pieces_Signs.WHITE_TURN);
        state.resetCastle();
        player1.setUpBoard();
        player2.setUpBoard();
        player1.updateCurrentPlayerDeafult();//צריך לשנות לכל אחד אם תורו זה פה!!!!
        player2.updateCurrentPlayerDeafult();
        
    }
    public void startNewGame(int setUp) {
        keepMovesForPlayer(1);
        state.setUp(setUp);
        state.setCurrentPlyer(Pieces_Signs.WHITE_TURN);
//        state.resetCastle();
        player1.setUpBoard();
        player2.setUpBoard();
        player1.updateCurrentPlayerDeafult();//צריך לשנות לכל אחד אם תורו זה פה!!!!
        player2.updateCurrentPlayerDeafult();
        
    }
    public char getCurrentPlayerFromstate()
    {
        return state.getCurrentPlayer();
    }
    public void waitForMoveP1()
    {
        Move move;
        do
        {
            move=player1.makeMove();
            if(move.getSrcLoc()==null)
                break;
        }while(!btnPressed(move.getSrcLoc(), player1));
    }
    public void waitForMoveP2()
    {
        Move move;
        move=player2.makeMove();
        if(move.getSrcLoc()!=null)
        {
            if(move.getDstLoc().getRow()!=-1)
            {
                btnPressed(move.getSrcLoc(), player2);
                btnPressed(move.getDstLoc(), player2);
            }
            else
                while(move.getSrcLoc()!=null && !btnPressed(move.getSrcLoc(), player2))
                    move=player2.makeMove();
        }
            
    }
   public void menageGame()
    {
        new Thread(new Runnable() 
        {
            @Override
            public void run() 
            {
                while(true&&playerWon==false&&keepGame)
                {
                    stopMovesFromPlayer(2);
                    waitForMoveP1();
                    if(!keepGame)
                        break;
                    if(!playerWon)
                    {
                        updateTwoPlayers();
                        stopMovesFromPlayer(1);
                        keepMovesForPlayer(2);
                        waitForMoveP2();
                        if(!keepGame)
                                break;
                            updateTwoPlayers();
                            keepMovesForPlayer(1);
                    }
                    else
                        playerWon=false;
                }
                if(playerWon && keepGame)
                {
                    playerWon=false;
                    menageGame();
                }
          }
            
        }).start();
    }
    public void stopMovesFromPlayer(int player)
    {
        if(player==1)
            player1.stopMovesFromPlayer();
        else
            player2.stopMovesFromPlayer();
    }
    public void keepMovesForPlayer(int player)
    {
        if(player==1)
            player1.keepMovesForPlayer();
        else
            player2.keepMovesForPlayer();
    }
    public void updateTwoPlayers()
    {
        
        player1.setUpBoard();
        player2.setUpBoard();
//            view.setUp(state.getBoard());
        player1.updateCurrentPlayer();
        player2.updateCurrentPlayer();
    }
    

   public boolean checkGameStatus() {
        char oponenetTurn = state.getOponenet(state.getCurrentPlayer());
        boolean thereIsPat = state.checkPat(state);
        if (thereIsPat) {
            if (state.checkMove(oponenetTurn, false)) {
                {
                    updateTwoPlayers();
                    player1.ShowWinnerByMate();
                    player2.ShowWinnerByMate();
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException ex) {
//                        ex.printStackTrace();
                    }
                    startNewGame();
                    return true;
                }//יש מנצח
            }
        }
        if (thereIsPat) {
            updateTwoPlayers();
            player1.showPat();
            player2.showPat();
//            view.showPat();
            startNewGame();
            return true;
        }
        if (state.checkDraw()) {
            updateTwoPlayers();
            player1.showDraw();
            player2.showDraw();
//            view.showDraw();
            startNewGame();
            state.setCurrentPlyer(Pieces_Signs.WHITE_TURN);
            return true;
        }
        return false;
    }
   public boolean btnPressed(Location loc,Player current) {
        if (!WhileMove) {
            ArrayList<Location> tmp = state.possibleMoves(loc,state);
            if (tmp != null) {
                current.showPossibleMoves(tmp);
                current.showPossibleSrc(loc);
                current.showPossibleSrc(loc);
                KeepLoc = new Location(loc.getRow(), loc.getCol());
                WhileMove = true;
            }
            return false;
            }
        Location srcLoc = new Location(KeepLoc.getRow(), KeepLoc.getCol());
        Location dstLoc = new Location(loc.getRow(), loc.getCol());
        Move move = new Move(srcLoc, dstLoc);
        if (state.isLegalToMakeMove(move, state.getCurrentPlayer())) {
            state.makeMove(move);
            state.resetRookCast();
            char oponenetTurn = state.getOponenet(state.getCurrentPlayer());
            Move testPwanChange = state.pwanChange();
            if (testPwanChange != null)
                current.changeForPwan(testPwanChange);
                
            
            if (checkGameStatus()) {//יש מנצח
                playerWon=true;
                return true;
            }
            current.buildBoard();
            WhileMove = false;
            state.switchTurn();
            if(state.checkMove(state.getTurn(), false))
                current.showCheckOnKing(state.getTurn());
            else
                current.clearBorders();
            return true;
        } else {
            WhileMove = false;
            current.buildBoard();
            if(state.sameColor(loc, KeepLoc))
                btnPressed(new Location(loc.getRow(), loc.getCol()),current);
        }
        return false;
    }
    public void setCurrent(char turn)
    {
        state.setCurrentPlyer(turn);
    }
    public void closeGame(Player player)
    {
        synchronized (player1) 
        {
            synchronized (player2) 
            {
                if(player.equals(player1))
                    player2.closeGameOponentGivesUp();
                else
                    player1.closeGameOponentGivesUp();
                server.removeGame(this);
                keepGame=false;
            }
        }
    }
}
