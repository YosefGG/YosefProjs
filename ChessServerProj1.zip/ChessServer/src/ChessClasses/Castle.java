package ChessClasses;

import java.io.Serializable;


public class Castle implements Serializable{
    private boolean kingWhiteHasMoved;
    private boolean threeSqRookWhiteHasMoved;
    private boolean twoSqRookWhiteHasMoved;
    private boolean kingBlackHasMoved;
    private boolean threeSqRookBlackHasMoved;
    private boolean twoSqRookBlackHasMoved;

    public Castle(boolean kingWhiteHasMoved, boolean threeSqRookWhiteHasMoved, boolean twoSqRookWhiteHasMoved, boolean kingBlackHasMoved, boolean threeSqRookBlackHasMoved, boolean twoSqRookBlackHasMoved) {
        this.kingWhiteHasMoved = kingWhiteHasMoved;
        this.threeSqRookWhiteHasMoved = threeSqRookWhiteHasMoved;
        this.twoSqRookWhiteHasMoved = twoSqRookWhiteHasMoved;
        this.kingBlackHasMoved = kingBlackHasMoved;
        this.threeSqRookBlackHasMoved = threeSqRookBlackHasMoved;
        this.twoSqRookBlackHasMoved = twoSqRookBlackHasMoved;
    }
    public Castle(Castle castle)
    {
        this.kingWhiteHasMoved = castle.kingWhiteHasMoved;
        this.threeSqRookWhiteHasMoved = castle.threeSqRookWhiteHasMoved;
        this.twoSqRookWhiteHasMoved = castle.twoSqRookWhiteHasMoved;
        this.kingBlackHasMoved = castle.kingBlackHasMoved;
        this.threeSqRookBlackHasMoved = castle.threeSqRookBlackHasMoved;
        this.twoSqRookBlackHasMoved = castle.twoSqRookBlackHasMoved;
    }
    public boolean isKingWhiteHasMoved() {
        return kingWhiteHasMoved;
    }

    public void setKingWhiteHasMoved(boolean kingWhiteHasMoved) {
        this.kingWhiteHasMoved = kingWhiteHasMoved;
    }

    public boolean isThreeSqRookWhiteHasMoved() {
        return threeSqRookWhiteHasMoved;
    }

    public void setThreeSqRookWhiteHasMoved(boolean threeSqRookWhiteHasMoved) {
        this.threeSqRookWhiteHasMoved = threeSqRookWhiteHasMoved;
    }

    public boolean isTwoSqRookWhiteHasMoved() {
        return twoSqRookWhiteHasMoved;
    }

    public void setTwoSqRookWhiteHasMoved(boolean twoSqRookWhiteHasMoved) {
        this.twoSqRookWhiteHasMoved = twoSqRookWhiteHasMoved;
    }

    public boolean isKingBlackHasMoved() {
        return kingBlackHasMoved;
    }

    public void setKingBlackHasMoved(boolean kingBlackHasMoved) {
        this.kingBlackHasMoved = kingBlackHasMoved;
    }

    public boolean isThreeSqRookBlackHasMoved() {
        return threeSqRookBlackHasMoved;
    }

    public void setThreeSqRookBlackHasMoved(boolean threeSqRookBlackHasMoved) {
        this.threeSqRookBlackHasMoved = threeSqRookBlackHasMoved;
    }

    public boolean isTwoSqRookBlackHasMoved() {
        return twoSqRookBlackHasMoved;
    }

    public void setTwoSqRookBlackHasMoved(boolean twoSqRookBlackHasMoved) {
        this.twoSqRookBlackHasMoved = twoSqRookBlackHasMoved;
    }

    @Override
    public String toString() {
        return "Castle{" + "kingWhiteHasMoved=" + kingWhiteHasMoved + ", threeSqRookWhiteHasMoved=" + threeSqRookWhiteHasMoved + ", twoSqRookWhiteHasMoved=" + twoSqRookWhiteHasMoved + ", kingBlackHasMoved=" + kingBlackHasMoved + ", threeSqRookBlackHasMoved=" + threeSqRookBlackHasMoved + ", twoSqRookBlackHasMoved=" + twoSqRookBlackHasMoved + '}';
    }
    
}
