package ChessClasses;

import java.io.Serializable;



public class Move implements Serializable{
    private Location srcLoc;
    private Location dstLoc;
    private Piece srcPiece;
    private Piece dstPiece;
    private int score;
    private int depth;
    public Move(Move move)
    {
        srcLoc = move.getSrcLoc();
        dstLoc = move.getDstLoc();
        srcPiece = move.getSrcPiece();
        dstPiece = move.getDstPiece();
        score=move.getScore();
        depth=move.getDepth();
    }
    public Move(Location srcLoc, Location dstLoc, Piece srcPiece, Piece dstPiece) {
        this.srcLoc = srcLoc;
        this.dstLoc = dstLoc;
        this.srcPiece = srcPiece;
        this.dstPiece = dstPiece;
        score = 0;
        depth=0;
    }
    public Move(Piece srcPiece, Piece dstPiece) {
        this.srcPiece = srcPiece;
        this.dstPiece = dstPiece;
        score=0;
    }
    public Move(Location srcLoc,Piece srcPiece)
    {
        this.srcLoc=srcLoc;
        this.srcPiece=srcPiece;
        score=0;
    }
    public Move(Location srcLoc,Location dstLoc) {
        this.dstLoc = dstLoc;
        this.srcLoc = srcLoc;
        score=0;
    }
    
    public Move(int score) {
        this.score = score;
    }
    public Move(int score,int depth) {
        this.score = score;
        this.depth=depth;
    }
    public int getScore()
    {
        return score;
    }
    public void setScore(int score)
    {
        this.score=score;
    }

    public Location getSrcLoc() {
        return srcLoc;
    }

    public void setSrcLoc(Location srcLoc) {
        this.srcLoc = srcLoc;
    }

    public Location getDstLoc() {
        return dstLoc;
    }

    public void setDstLoc(Location dstLoc) {
        this.dstLoc = dstLoc;
    }

    public Piece getSrcPiece() {
        return srcPiece;
    }

    public void setSrcPiece(Piece srcPiece) {
        this.srcPiece = srcPiece;
    }

    public Piece getDstPiece() {
        return dstPiece;
    }

    public void setDstPiece(Piece dstPiece) {
        this.dstPiece = dstPiece;
    }
    public void setDepth(int depth)
    {
        this.depth=depth;
    }
    public int getDepth()
    {
        return depth;
    }
    @Override
    public String toString() {
        return "Move{" + "srcLoc=" + srcLoc + ", dstLoc=" + dstLoc + ", srcPiece=" + srcPiece + ", dstPiece=" + dstPiece + ", score=" + score + ", depth:="+depth+'}';
    }
    
    
}