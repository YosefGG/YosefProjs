package ChessClasses;

import java.io.Serializable;

public class AlphaBeta implements Serializable{
    private int val;
    private int depth;

    public AlphaBeta(int val, int depth) {
        this.val = val;
        this.depth = depth;
    }
    public AlphaBeta(AlphaBeta var)
    {
        val=var.val;
        depth=var.depth;
    }
    public int getVal() {
        return val;
    }

    public void setVal(int val) {
        this.val = val;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }
    
}
