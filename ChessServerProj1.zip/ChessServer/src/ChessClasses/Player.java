package ChessClasses;

import ChessClasses.Location;
import ChessClasses.Move;
import ChessClasses.State;
import Networking.Message;
import java.awt.Color;
import java.util.ArrayList;

public abstract class Player {
    protected Color color;
    protected State state;
    protected boolean WhileMove;
    protected Location KeepLoc;
    protected Game game;
    public Player(State state,Color color) {
        this.color = color;
        this.state=state;
    }
    public abstract void sendToClient(Message msg);
        
    public abstract Move makeMove();

    public Game getGame() {
        return game;
    }
    public abstract void stopMovesFromPlayer();
    public abstract void keepMovesForPlayer();
    public abstract void setGame(Game game);
    public abstract void setUpBoard();
    public abstract void updateCurrentPlayer();
    public abstract void updateCurrentPlayerDeafult();
    public abstract void ShowWinnerByMate();
    public abstract void showPat();
    public abstract void showDraw();
    public abstract void showPossibleMoves(ArrayList<Location> tmp);
    public abstract void showPossibleSrc(Location loc);
    public abstract void changeForPwan(Move testPwanChange);
    public abstract void buildBoard();
    public abstract void showCheckOnKing(char turn);
    public abstract void clearBorders();
    public abstract void closeGameOponentGivesUp();
    
    
    public Color getColor()
    {
        return color;
    }
    public void setColor(Color color)
    {
        this.color=color;
    }
    public State getState()
    {
        return state;
    }
    public void setState(State state)
    {
        this.state=state;
    }

    

    
}
