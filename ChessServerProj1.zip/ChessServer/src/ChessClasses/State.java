package ChessClasses;

import java.awt.Color;
import java.util.ArrayList;

public class State {
    private char turn;
    private Piece[][] board;
    
    private Castle castle;
    private Move rookCast;
    private ArrayList<Location> list;
    private ArrayList<Location> doingCheck;
    private Location KingLoc;
    private ArrayList<Location> possibleMove;
    private boolean checkPossible;
   
    private char current;
    public State(int numOfSetUp,char turn) {
        this.turn = turn;
        board = new Piece[8][8];
        castle=new Castle(false, false, false, false, false, false);
        doingCheck=new ArrayList<Location>();
        checkPossible=false;
        KingLoc=new Location(-1, -1);
        list=new ArrayList();
        possibleMove=new ArrayList<Location>();
    }
    public State(Piece[][] board,char turn,Castle castle) {
        this.turn = turn;
        this.board = board;
        this.castle = new Castle(castle);
        rookCast=null;
        KingLoc=new Location(-1, -1);
        list=new ArrayList();
        possibleMove=new ArrayList<Location>();
        checkPossible=false;
        doingCheck=new ArrayList<Location>();
    }
    public State(int numOfSetUp,char turn,Castle castle) {
        this.turn = turn;
        board=new Piece[8][8];
        this.castle = new Castle(castle);
        rookCast=null;
        doingCheck=new ArrayList<Location>();
        checkPossible=false;
        KingLoc=new Location(-1, -1);
        list=new ArrayList();
        possibleMove=new ArrayList<Location>();
        setUp(numOfSetUp);
    }
    
    public State(int numOfSetUp) {
        turn=Pieces_Signs.WHITE_TURN;
        board=new Piece[8][8];
        doingCheck=new ArrayList<Location>();
        checkPossible=false;
        KingLoc=new Location(-1, -1);
        list=new ArrayList();
        possibleMove=new ArrayList<Location>();
        setUp(numOfSetUp);
    }
    public State(State state)
    {
        board=new Piece[8][8];
        for (int i = 0; i < 8; i++) 
            for (int j = 0; j < 8; j++) 
                board[i][j]=new Piece(state.getBoard()[i][j]);
        this.turn=state.getTurn();
        castle=new Castle(state.getCastle());
        doingCheck=new ArrayList<Location>();
        checkPossible=false;
        KingLoc=new Location(-1, -1);
        list=new ArrayList();
        possibleMove=new ArrayList<Location>();
        
    }
     public State(Piece[][] board,char turn) {
        this.turn = turn;
        this.board = board;
        castle=new Castle(false, false, false, false, false, false);
        
    }
    public char getOponenet(char turn)
    {
        if(turn==Pieces_Signs.WHITE_TURN)
            return Pieces_Signs.BLACK_TURN;
        return Pieces_Signs.WHITE_TURN;
    }
//    public State getState()
//    {
//        return state;
//    }
    public void setCurrentPlyer(char turn)
    {
        setTurn(turn);
    }
    public Piece[][] getBoard()
    {
        return board;
    }
    public char getTurn()
    {
        return turn;
    }
    public char currentOfminiMax()
    {
        return current;
    }
    public void resetCastle()
    {
        setCastle(new Castle(false, false, false, false, false, false));
    }
    
    public void switchTurn()
    {
        if(getTurn()==Pieces_Signs.WHITE_TURN)
            setTurn(Pieces_Signs.BLACK_TURN);
        else
            setTurn(Pieces_Signs.WHITE_TURN);
    }
    public void setUp(int setUp) 
    {
        switch(setUp)
        {
            case 1:setUp1();
                   break;
            case 2:setUp2();
                   setCastle(new Castle(true,true,true,true,true,true));
                   break;
            case 3:setUp3();
                   setCastle(new Castle(true,true,true,true,true,true));
                   break;
            case 4:setUp4();
                   setCastle(new Castle(true,true,true,true,true,true));
                   break;
            default:setUp5();
                    setCastle(new Castle(true,true,true,true,true,true));
        };
    }
    public void setUp1() 
    {
        char[] piece=
            {Pieces_Signs.ROOK,Pieces_Signs.KNIGHT,Pieces_Signs.BISHOP,Pieces_Signs.QUEEN,Pieces_Signs.KING,Pieces_Signs.BISHOP,Pieces_Signs.KNIGHT,Pieces_Signs.ROOK,Pieces_Signs.PAWN,Pieces_Signs.EMPTY_SIGN};
        char Return[][]=new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                switch (i) {
                    case 0:
                        board[i][j]=new Piece(piece[j], Color.black);
                        break;
                    case 1:
                        board[i][j]=new Piece(piece[8], Color.black);
                        break;
                    case 6:
                        board[i][j]=new Piece(piece[8], Color.white);
                        break;
                    case 7:
                        board[i][j]=new Piece(piece[j], Color.white);
                        break;
                    default:
                        board[i][j]=new Piece(piece[9], Color.yellow);
                        break;
                }
            }
        }
    }
    public void setUp2() {
        char[] piece=
            {Pieces_Signs.ROOK,Pieces_Signs.KNIGHT,Pieces_Signs.BISHOP,Pieces_Signs.QUEEN,Pieces_Signs.KING,Pieces_Signs.BISHOP,Pieces_Signs.KNIGHT,Pieces_Signs.ROOK,Pieces_Signs.PAWN,Pieces_Signs.EMPTY_SIGN};
        for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) 
                    board[i][j]=new Piece(Pieces_Signs.EMPTY_SIGN,Color.yellow);
            }
        board[2][2]=new Piece(Pieces_Signs.KING,Color.black);
        board[6][2]=new Piece(Pieces_Signs.KING,Color.white);
        board[3][4]=new Piece(Pieces_Signs.QUEEN,Color.black);
        board[5][0]=new Piece(Pieces_Signs.PAWN,Color.white);
        }
    public void setUp3()
    {
        char[] piece=
            {Pieces_Signs.ROOK,Pieces_Signs.KNIGHT,Pieces_Signs.BISHOP,Pieces_Signs.QUEEN,Pieces_Signs.KING,Pieces_Signs.BISHOP,Pieces_Signs.KNIGHT,Pieces_Signs.ROOK,Pieces_Signs.PAWN,Pieces_Signs.EMPTY_SIGN};
        for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) 
                {
                    if(i<2)
                        board[i][j]=new Piece(Pieces_Signs.QUEEN, Color.black);
                    else if(i>5)
                        board[i][j]=new Piece(Pieces_Signs.QUEEN, Color.white);
                    else 
                        board[i][j]=new Piece(Pieces_Signs.EMPTY_SIGN,Color.yellow);
                }
            }
        board[0][4]=new Piece(Pieces_Signs.KING, Color.black);
        board[7][4]=new Piece(Pieces_Signs.KING, Color.white);
    }
    public void setUp4()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j]=new Piece(Pieces_Signs.EMPTY_SIGN,Color.yellow);
            }
        }
        board[1][0]=new Piece(Pieces_Signs.PAWN, Color.black);
        board[1][1]=new Piece(Pieces_Signs.KING, Color.black);
        board[1][2]=new Piece(Pieces_Signs.PAWN, Color.black);
        board[2][2]=new Piece(Pieces_Signs.ROOK, Color.black);
        board[3][3]=new Piece(Pieces_Signs.KNIGHT, Color.black);
        board[4][5]=new Piece(Pieces_Signs.BISHOP, Color.black);
        board[2][6]=new Piece(Pieces_Signs.ROOK, Color.white);
        board[4][6]=new Piece(Pieces_Signs.PAWN, Color.white);
        board[5][0]=new Piece(Pieces_Signs.PAWN, Color.white);
        board[5][2]=new Piece(Pieces_Signs.PAWN, Color.white);
        board[6][1]=new Piece(Pieces_Signs.PAWN, Color.white);
        board[6][5]=new Piece(Pieces_Signs.PAWN, Color.white);
        board[7][1]=new Piece(Pieces_Signs.KING, Color.white);
        board[7][2]=new Piece(Pieces_Signs.BISHOP, Color.white);
    }
     public void setUp5()
    {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j]=new Piece(Pieces_Signs.EMPTY_SIGN,Color.yellow);
            }
        }
        board[4][1]=new Piece(Pieces_Signs.PAWN,Color.black);
        board[3][0]=new Piece(Pieces_Signs.PAWN,Color.black);
        board[4][2]=new Piece(Pieces_Signs.KING,Color.black);
        board[6][0]=new Piece(Pieces_Signs.KING,Color.white);
    }
    public char getCurrentPlayer()
    {
        return getTurn();
    }
    public Move pwanChange() {
        for (int i = 0; i < 8; i++) {
            if(board[0][i].getName()==Pieces_Signs.PAWN)
            {
                board[0][i].setName(Pieces_Signs.QUEEN);
                return new Move(new Location(0, i),new Piece(board[0][i]));
            }
                
            if(board[7][i].getName()==Pieces_Signs.PAWN)
            {
                board[7][i].setName(Pieces_Signs.QUEEN);
                return new Move(new Location(7, i),new Piece(board[7][i]));
            }
        }
        return null;
    }
    public void makeMove(Move move)
    {
        makeMove(move,true);
    }
    public boolean isLegalToMakeMove(Move move,char turn)
    {
        list=new ArrayList<Location>();
        Location srcLoc=move.getSrcLoc();
        Location dstLoc=move.getDstLoc();
        Piece p1=board[srcLoc.getRow()][srcLoc.getCol()];
        Piece p2=board[dstLoc.getRow()][dstLoc.getCol()];
        Move moveForCheck=new Move(new Piece(p1),new Piece(p2));
        if(checkPossible==false)
            for (int i = 0; i < possibleMove.size(); i++) 
                if(possibleMove.get(i).getRow()==dstLoc.getRow() && possibleMove.get(i).getCol()==dstLoc.getCol())
                    return true;
        if(checkPossible)
        {
                makeMove(move,false);
                if(!checkMove(turn,false))
                {
                    unMakeMove(new Move(srcLoc,dstLoc,moveForCheck.getSrcPiece(),moveForCheck.getDstPiece()));
                    return true;
                }
        }
        unMakeMove(new Move(srcLoc,dstLoc,moveForCheck.getSrcPiece(),moveForCheck.getDstPiece()));
        return false;
    }
    /**
     * Run time - O(n^2*O(possibleMoves))
     * n^2 - מעבר על כל המטריצה
     * @param state - חישוב כל מהלכים האפשריים עבור מצב מסוים
     * @return רשימת כל המהלכים האפשריים עבור מצב מסוים
     */
    public ArrayList getAllpossibleMoves(State state)
    {
        char turn = state.getTurn();
        boolean thereIsDraw=true;
        ArrayList moves=new ArrayList<Move>();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(board[i][j].getName()!=Pieces_Signs.EMPTY_SIGN)
                    if(board[i][j].getName()!=Pieces_Signs.KING)
                        thereIsDraw=false;
                if(possibleMoves(new Location(i, j),state)!=null)
                    for (int k = 0; k < possibleMove.size(); k++) {
                        int row=possibleMove.get(k).getRow();
                        int col=possibleMove.get(k).getCol();
                        moves.add(new Move(new Location(i, j),possibleMove.get(k),new Piece(board[i][j].getName(),board[i][j].getColor()),new Piece(board[row][col].getName(),board[row][col].getColor())));
                    }
            }
        }
        if(thereIsDraw||(moves.isEmpty()))
            return null;
        return moves;
    }
   /**
    * Run time - O(m*O(Check))
    * m - מספר המהלכים האפשריים ללא הגנה על המלך
    * @param pieceLoc - מיקום של כלי מסוים עליו נרצה לבדוק את המהלכים האפשריים עבורו
    * @param state - מצב שעליו נרצה לבדוק את חוקיהמשחק
    * @return את כל המהלכים האפשריים עבור שחקן מסויים
    */
   public ArrayList<Location> possibleMoves(Location pieceLoc,State state)
    {
        char turn = state.getTurn();
        possibleMove=new ArrayList<Location>();
        list=new ArrayList<Location>();
        if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getColor().equals(Color.white))
            if(turn==Pieces_Signs.BLACK_TURN)
                return null;
        if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getColor().equals(Color.black))
            if(turn==Pieces_Signs.WHITE_TURN)
                return null;
        if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getName()==Pieces_Signs.QUEEN)
        {
            checkPossible=true;
            checkLowHigh(turn, pieceLoc, true,true);
            checkRightLeft(turn, pieceLoc, true,true);
            checkMainDiagnole(turn, pieceLoc, true,true);
            checkSecondDiagnole(turn, pieceLoc, true,true);
            possibleMove=list;
            int size=possibleMove.size();
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.EMPTY_SIGN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(Color.yellow);
            if(checkMove(turn, true))
            {
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.QUEEN);
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
                for(int i = 0; i < size; i++) {
                    Location srcLoc=new Location(pieceLoc.getRow(),pieceLoc.getCol());
                    Location dstLoc=new Location(possibleMove.get(i).getRow(), possibleMove.get(i).getCol());
                    boolean test=isLegalToMakeMove(new Move(srcLoc,dstLoc),turn);
                    if(!test)
                    {
                        possibleMove.remove(i);
                        i--;
                        size--;
                    }
                }
            }
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.QUEEN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
            checkPossible=false;
            return possibleMove;
        }
        else if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getName()==Pieces_Signs.BISHOP)
        {
            checkMainDiagnole(turn, pieceLoc, true,true);
            checkSecondDiagnole(turn, pieceLoc, true,true);
            possibleMove=list;
            checkPossible=true;
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.EMPTY_SIGN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(Color.yellow);
            if(checkMove(turn, true))
            {
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.BISHOP);
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
                for(int i = 0; i < possibleMove.size(); i++) { 
                   Location srcLoc=new Location(pieceLoc.getRow(),pieceLoc.getCol());
                   Location dstLoc=new Location(possibleMove.get(i).getRow(), possibleMove.get(i).getCol());
                   boolean test=isLegalToMakeMove(new Move(srcLoc,dstLoc),turn);
                   if(!test)
                   {
                       possibleMove.remove(i);
                       i--;
                   }
                }
            }
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.BISHOP);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
            checkPossible=false;
            return possibleMove;
            
        }
        else if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getName()==Pieces_Signs.ROOK)
        {
            checkLowHigh(turn, pieceLoc, true,true);
            checkRightLeft(turn, pieceLoc, true,true);
            possibleMove=list;
            checkPossible=true;
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.EMPTY_SIGN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(Color.yellow);
            if(checkMove(turn, true))
            {
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.ROOK);
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
                for(int i = 0; i < possibleMove.size(); i++) { 
                   Location srcLoc=new Location(pieceLoc.getRow(),pieceLoc.getCol());
                   Location dstLoc=new Location(possibleMove.get(i).getRow(), possibleMove.get(i).getCol());
                   boolean test=isLegalToMakeMove(new Move(srcLoc,dstLoc),turn);
                   if(!test)
                   {
                       possibleMove.remove(i);
                       i--;
                   }
               }
            }
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.ROOK);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
            checkPossible=false;
            return possibleMove;
        }
        else if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getName()==Pieces_Signs.KNIGHT)
        {
            checkKniget(turn, pieceLoc, true, true);
            possibleMove=list;
            checkPossible=true;
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.EMPTY_SIGN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(Color.yellow);
            if(checkMove(turn, true))
            {
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.KNIGHT);
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
                for(int i = 0; i < possibleMove.size(); i++) { 
                   Location srcLoc=new Location(pieceLoc.getRow(),pieceLoc.getCol());
                   Location dstLoc=new Location(possibleMove.get(i).getRow(), possibleMove.get(i).getCol());
                   boolean test=isLegalToMakeMove(new Move(srcLoc,dstLoc),turn);
                   if(!test)
                   {
                       possibleMove.remove(i);
                       i--;
                   }
               }
            }
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.KNIGHT);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
            checkPossible=false;
            return possibleMove;
        }
        else if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getName()==Pieces_Signs.KING)
        {
                
            Location[] KingPlace={
                new Location(pieceLoc.getRow()-1,pieceLoc.getCol()),
                new Location(pieceLoc.getRow()-1,pieceLoc.getCol()-1),
                new Location(pieceLoc.getRow(),pieceLoc.getCol()-1),
                new Location(pieceLoc.getRow()-1,pieceLoc.getCol()+1),
                new Location(pieceLoc.getRow()+1,pieceLoc.getCol()),
                new Location(pieceLoc.getRow()+1,pieceLoc.getCol()-1),
                new Location(pieceLoc.getRow()+1,pieceLoc.getCol()+1),
                new Location(pieceLoc.getRow(),pieceLoc.getCol()+1)
            };
            Color TurnColor=Color.white;
            if(turn==Pieces_Signs.BLACK_TURN)
                TurnColor=Color.black;
//            System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            for (int i = 0; i < 8; i++) {
               if(KingPlace[i].getRow()>=0 && KingPlace[i].getRow()<8)
                   if(KingPlace[i].getCol()>=0 && KingPlace[i].getCol()<8)
                        if(!state.getBoard()[KingPlace[i].getRow()][KingPlace[i].getCol()].getColor().equals(TurnColor))
                        {
                            list.add(new Location(KingPlace[i].getRow(),KingPlace[i].getCol()));
//                            System.out.println("--------- "+i+"--------");
                        }
            }
            
            ArrayList<Location> tmp=new ArrayList<Location>();
            for (int i = 0; i < list.size(); i++) 
                tmp.add(new Location(list.get(i)));
            boolean thereIsCheck=false;
            if(turn==Pieces_Signs.WHITE_TURN)
            {
                if(!state.getCastle().isKingWhiteHasMoved())
                {
                    if(!state.getCastle().isThreeSqRookWhiteHasMoved())
                    {
                       for (int i = 0; i < 5; i++) {
                            if(i>0&&i<4)
                                if(state.getBoard()[7][i].getName()!=Pieces_Signs.EMPTY_SIGN)
                                {
                                    thereIsCheck=true;
                                    break;
                                }
                            if(Check(turn , new Location(7, i), false, false))
                            {
                                thereIsCheck=true;
                                break;
                            }
                        }
                        if(!thereIsCheck)
                            tmp.add(new Location(7,2));
                    }
                    
                    thereIsCheck=false;
                    if(!state.getCastle().isTwoSqRookWhiteHasMoved())
                    {
                        for (int i = 4; i < 8; i++) {
                            if(i>4&&i<7)
                                if(state.getBoard()[7][i].getName()!=Pieces_Signs.EMPTY_SIGN)
                                {
                                    thereIsCheck=true;
                                    break;
                                }
                            if(Check(turn , new Location(7, i), false, false))
                            {
                                thereIsCheck=true;
                                break;
                            }
                        }
                     
                     if(!thereIsCheck)
                         tmp.add(new Location(7,6));
                    }
                }
            }
            //-----------------------------------------------------------------------//black turn
            else
            {
                if(!state.getCastle().isKingBlackHasMoved())
                {
                    if(!state.getCastle().isTwoSqRookBlackHasMoved())
                    {
                        for (int i = 4; i < 8; i++) {
                            if(i>4&&i<7)
                                if(state.getBoard()[0][i].getName()!=Pieces_Signs.EMPTY_SIGN)
                                {
                                    thereIsCheck=true;
                                    break;
                                }
                            if(Check(turn , new Location(0, i), false, false))
                            {
                                thereIsCheck=true;
                                break;
                            }
                        }
                        if(!thereIsCheck)
                            tmp.add(new Location(0,6));
                    }
                    thereIsCheck=false;
                    if(!state.getCastle().isThreeSqRookBlackHasMoved())
                    {
                        for (int i = 0; i < 5; i++) {
                            if(i>0&&i<4)
                                if(state.getBoard()[0][i].getName()!=Pieces_Signs.EMPTY_SIGN)
                                {
                                    thereIsCheck=true;
                                    break;
                                }
                            if(Check(turn , new Location(0, i), false, false))
                            {
                                thereIsCheck=true;
                                break;
                            }
                        }
                        if(!thereIsCheck)
                            tmp.add(new Location(0,2));
                    }
               }
                
            }
//            for (int i = 0; i < list.size(); i++) {
//                tmp.add(new Location(list.get(i)));
//            }
            list=tmp;
//            for (int i = 0; i < tmp.size(); i++) 
//                list.add(tmp.get(i));
            
            possibleMove = new ArrayList<Location>();
            for (int i = 0; i < list.size(); i++)
                possibleMove.add(new Location(list.get(i)));
//            possibleMove=list;
            checkPossible=true;
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.EMPTY_SIGN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(Color.yellow);
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.KING);
                state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
                for(int i = 0; i < possibleMove.size(); i++) { 
                   Location srcLoc=new Location(pieceLoc.getRow(),pieceLoc.getCol());
                   Location dstLoc=new Location(possibleMove.get(i));
                   boolean test=isLegalToMakeMove(new Move(srcLoc,dstLoc),turn);
                   if(!test)
                   {
                       possibleMove.remove(i);
                       printBoard(state.getBoard());
                       i--;
                   }
               }
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.KING);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
            checkPossible=false;
            return possibleMove;
        }
        else if(state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].getName()!=Pieces_Signs.EMPTY_SIGN)//עובד
        {
            if(turn==Pieces_Signs.WHITE_TURN)
            {
                if(pieceLoc.getRow() - 1 >= 0 && state.getBoard()[pieceLoc.getRow()-1][pieceLoc.getCol()].getColor()==Color.yellow)
                {
                    list.add(new Location(pieceLoc.getRow()-1, pieceLoc.getCol()));
                    if(pieceLoc.getRow()==6 && pieceLoc.getRow() - 2 >= 0 && state.getBoard()[pieceLoc.getRow()-2][pieceLoc.getCol()].getColor()==Color.yellow)
                        list.add(new Location(pieceLoc.getRow()-2, pieceLoc.getCol()));
                }
                if(pieceLoc.getRow() - 1 >= 0 && pieceLoc.getCol()-1 >= 0)
                    if(state.getBoard()[pieceLoc.getRow() - 1][pieceLoc.getCol()-1].getColor()==Color.black)//לבדוק אם יש מהלך חוקי
                        list.add(new Location(pieceLoc.getRow()-1,pieceLoc.getCol()-1));
                if(pieceLoc.getRow() - 1 >= 0 && pieceLoc.getCol()+1 < 8)
                    if(state.getBoard()[pieceLoc.getRow() - 1][pieceLoc.getCol()+1].getColor()==Color.black)
                        list.add(new Location(pieceLoc.getRow()-1,pieceLoc.getCol()+1));
            }
            if(turn==Pieces_Signs.BLACK_TURN)
            {
                if(pieceLoc.getRow() + 1 < 8 && state.getBoard()[pieceLoc.getRow()+1][pieceLoc.getCol()].getColor()==Color.yellow)
                {
                    list.add(new Location(pieceLoc.getRow()+1, pieceLoc.getCol()));
                    if(pieceLoc.getRow()==1 && pieceLoc.getRow() + 2 < 8 && state.getBoard()[pieceLoc.getRow()+2][pieceLoc.getCol()].getColor()==Color.yellow)
                        list.add(new Location(pieceLoc.getRow()+2, pieceLoc.getCol()));
                }
                if(pieceLoc.getRow() + 1 < 8 && pieceLoc.getCol()-1 >= 0)
                    if(state.getBoard()[pieceLoc.getRow() + 1][pieceLoc.getCol()-1].getColor()==Color.white)
                        list.add(new Location(pieceLoc.getRow()+1,pieceLoc.getCol()-1));
                if(pieceLoc.getRow() + 1 < 8 && pieceLoc.getCol()+1 < 8)
                    if(state.getBoard()[pieceLoc.getRow() + 1][pieceLoc.getCol()+1].getColor()==Color.white)
                        list.add(new Location(pieceLoc.getRow()+1,pieceLoc.getCol()+1));
            }
            possibleMove=list;
            checkPossible=true;
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.EMPTY_SIGN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(Color.yellow);
            if(checkMove(turn, true))
            {
                for(int i = 0; i < possibleMove.size(); i++) {
                    state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.PAWN);
                    state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
                   Location srcLoc=new Location(pieceLoc.getRow(),pieceLoc.getCol());
                   Location dstLoc=new Location(possibleMove.get(i).getRow(), possibleMove.get(i).getCol());
                   boolean test=isLegalToMakeMove(new Move(srcLoc,dstLoc),turn);
                   if(!test)
                   {
                       possibleMove.remove(i);
                       i--;
                   }
               }
            }
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setName(Pieces_Signs.PAWN);
            state.getBoard()[pieceLoc.getRow()][pieceLoc.getCol()].setColor(getColor(turn));
            checkPossible=false;
            return possibleMove;
        }
        return null;
    }
    
    public boolean checkMove(char turn,boolean inMate)
    {
        Color rightColor=getColor(turn);
//        if(!inMate)
        {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if((board[i][j]).getName()==Pieces_Signs.KING&&board[i][j].getColor().equals(rightColor))
                    {
                        KingLoc.setRow(i);
                        KingLoc.setCol(j);
                        break;
                    }
                }
            }
        }
        boolean help = pwanCheck(turn, KingLoc,true)||checkMainDiagnole(turn,KingLoc,!inMate,false)||checkLowHigh(turn, KingLoc,!inMate,false)||checkSecondDiagnole(turn, KingLoc,!inMate,false)||checkRightLeft(turn, KingLoc,!inMate,false)||checkKniget(turn, KingLoc,!inMate,false);
        return help || nearToKing(turn,KingLoc);
    }
    public boolean checkMainDiagnole(char turn, Location KingLoc,boolean NotInMate,boolean KeepLookFor) {
        boolean defualt=false;
        int i=KingLoc.getRow()+1;
        Color rightColor=Color.black;
        if(turn==Pieces_Signs.WHITE_TURN)
            rightColor=Color.white;
        for (int j=KingLoc.getCol()+1;  i < 8 && j<8;i++,j++) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            if(NotInMate)
                list.add(new Location(i, j));
            if((p==Pieces_Signs.QUEEN || p==Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor))
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
            {
                if(NotInMate && !KeepLookFor)
                    list=new ArrayList<Location>();
                break;
            }
        }
        i=KingLoc.getRow()-1;
        for (int j = KingLoc.getCol()-1; i>=0 && j>=0; j--,i--) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            if(NotInMate)
                list.add(new Location(i, j));
            if((p==Pieces_Signs.QUEEN||p==Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor) )
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
                return false;
        }
        if(NotInMate && !KeepLookFor)
            list=new ArrayList<Location>();
        return defualt;
    }
    public boolean checkSecondDiagnole(char turn, Location KingLoc,boolean NotInMate,boolean KeepLookFor)
   {
        boolean defualt=false;   
        int i=KingLoc.getRow()-1;
        Color white=Color.white;
        Color black=Color.black;
        Color rightColor=Color.black;
        if(turn==Pieces_Signs.WHITE_TURN)
            rightColor=Color.white;
        for (int j=KingLoc.getCol()+1; i>=0 && j<8; j++,i--) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            if(NotInMate)
                list.add(new Location(i, j));
            if((p==Pieces_Signs.QUEEN || p==Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor))
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
            {
                if(NotInMate && !KeepLookFor)
                    list=new ArrayList<Location>();
                break;
            }
                
        }
        i=KingLoc.getRow()+1;
        for (int j = KingLoc.getCol()-1; i < 8 && j>=0; j--,i++) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            if(NotInMate)
                list.add(new Location(i, j));
            if((p==Pieces_Signs.QUEEN||p==Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor) )
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.BISHOP) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
                return false;
        
    }
        if(NotInMate && !KeepLookFor)
            list=new ArrayList<Location>();
        return defualt;
   }
   public boolean checkLowHigh(char turn, Location KingLoc,boolean NotInMate,boolean KeepLookFor)
   {
       boolean defualt=false;
       int i=KingLoc.getRow()-1;
        Color white=Color.white;
        Color black=Color.black;
        Color rightColor=Color.black;
        if(turn==Pieces_Signs.WHITE_TURN)
            rightColor=Color.white;
        for (int j=KingLoc.getCol(); i>=0 ;i--) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            if(NotInMate)
                list.add(new Location(i,j));
            Color TurnColor=board[i][j].getColor();
            if((p==Pieces_Signs.QUEEN||p==Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) )
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
            {
                if(!KeepLookFor)
                    list=new ArrayList<Location>();
                break;
            }
        }
        i=KingLoc.getRow()+1;
        for (int j = KingLoc.getCol(); i < 8; i++) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            Color TurnColor=board[i][j].getColor();
            if(NotInMate)
                list.add(new Location(i, j));
            if((p==Pieces_Signs.QUEEN||p==Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) )
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
            {
                if(!KeepLookFor)
                    list=new ArrayList<Location>();
                return false;
            }
        }
       if(NotInMate)
           if(!KeepLookFor)
               list=new ArrayList<Location>();
       return defualt;
   }
   public boolean checkRightLeft(char turn, Location KingLoc,boolean NotInMate,boolean KeepLookFor)
   {
        boolean defualt=false;
       int i=KingLoc.getRow();
        Color white=Color.white;
        Color black=Color.black;
        Color rightColor=Color.black;
        if(turn==Pieces_Signs.WHITE_TURN)
            rightColor=Color.white;
        for (int j=KingLoc.getCol()-1; j>=0;j--) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            if(NotInMate)
                list.add(new Location(i,j));
            Color TurnColor=board[i][j].getColor();
            if((p==Pieces_Signs.QUEEN||p==Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) )
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
            {
                if(!KeepLookFor)
                    list=new ArrayList<Location>();
                break;
            }
        }
        i=KingLoc.getRow();
        for (int j = KingLoc.getCol()+1;  j < 8; j++) {
            char p=board[i][j].getName();
            if(board[i][j].getColor().equals(rightColor))
                break;
            Color TurnColor=board[i][j].getColor();
            if(NotInMate)
                list.add(new Location(i, j));
            if((p==Pieces_Signs.QUEEN||p==Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) )
            {
                doingCheck.add(new Location(i, j));
                if(!KeepLookFor)
                    return true;
            }
            if(board[i][j].getColor().equals(rightColor) || (p!=Pieces_Signs.QUEEN || p!=Pieces_Signs.ROOK) && !board[i][j].getColor().equals(rightColor) && p!=Pieces_Signs.EMPTY_SIGN)
            {
                if(!KeepLookFor)
                    list=new ArrayList<Location>();
                return false;
            }
        }
       if(NotInMate)
           if(!KeepLookFor)
               list=new ArrayList<Location>();
       return defualt;
   }
   public boolean checkKniget(char turn, Location KingLoc,boolean NotInMate,boolean KeepLookFor)
   {
       boolean deafualt=false;
       int row=KingLoc.getRow();
       int col=KingLoc.getCol();
       Color TurnColor=Color.white;
       if(turn==Pieces_Signs.BLACK_TURN)
           TurnColor=Color.black;
       Location[] arr={
           new Location(row-2, col+1),new Location(row-2, col-1),
           new Location(row+2, col+1),new Location(row+2, col-1),
           new Location(row-1, col+2),new Location(row+1, col+2),
           new Location(row+1, col-2),new Location(row-1, col-2)
       };
       for (int i = 0; i < 8; i++) {
           if(arr[i].getRow()<8 && arr[i].getRow()>=0 && arr[i].getCol()<8 && arr[i].getCol()>=0)   
           {
               if(board[arr[i].getRow()][arr[i].getCol()].getName()==Pieces_Signs.KNIGHT && !board[arr[i].getRow()][arr[i].getCol()].getColor().equals(TurnColor))
                {
                    doingCheck.add(new Location(arr[i].getRow(),arr[i].getCol()));
                    if(NotInMate)
                        list.add(new Location(arr[i].getRow(), arr[i].getCol()));
                    if(!KeepLookFor)
                        return true;
                }
               if(KeepLookFor)
                   if(!board[arr[i].getRow()][arr[i].getCol()].getColor().equals(TurnColor))
                       list.add(new Location(arr[i].getRow(), arr[i].getCol()));
           }
       }
       if(NotInMate && !KeepLookFor)
           list=new ArrayList<Location>();
       return deafualt;
   }
   public boolean pwanCheck(char turn,Location KingLocation,boolean IsKingLoc)
   {
       try
       {
       boolean ThereIsCheck=false;
       if(turn==Pieces_Signs.WHITE_TURN)
       {
           if(KingLocation.getRow() == 3 && !IsKingLoc)
               if(board[1][KingLocation.getCol()].getName() == Pieces_Signs.PAWN)
                   if(board[2][KingLocation.getCol()].getName() == Pieces_Signs.EMPTY_SIGN)
                   {
                       doingCheck.add(new Location(1,KingLocation.getCol()));
                       ThereIsCheck=true;
                   }
               
           if(board[KingLocation.getRow()][KingLocation.getCol()].getName()==Pieces_Signs.EMPTY_SIGN && KingLocation.getRow() - 1 >= 0 && !IsKingLoc)
           {
               Piece place=board[KingLocation.getRow()-1][KingLocation.getCol()];
               if(place.getName() == Pieces_Signs.PAWN && place.getColor() == Color.black)
               {
                   doingCheck.add(new Location(KingLocation.getRow(),KingLocation.getCol()-1));
                   if(!IsKingLoc)
                    ThereIsCheck=true;
               }
           }
           if(KingLocation.getRow()-1 >= 0 && KingLocation.getCol()+1 < 8 && IsKingLoc)
           {
               Piece pawn=board[KingLocation.getRow()-1][KingLocation.getCol()+1];
               if(pawn.getName() == Pieces_Signs.PAWN && pawn.getColor().equals(Color.black))
               {
                   doingCheck.add(new Location(KingLocation.getRow()-1,KingLocation.getCol()+1));
                   ThereIsCheck=true;
               }
           }
           if(KingLocation.getRow()-1 >= 0 && KingLocation.getCol()-1 >= 0 && IsKingLoc)
           {
               Piece pawn=board[KingLocation.getRow()-1][KingLocation.getCol()-1];
               if(pawn.getName() == Pieces_Signs.PAWN && pawn.getColor().equals(Color.black))
               {
                   doingCheck.add(new Location(KingLocation.getRow()-1,KingLocation.getCol()-1));
                   ThereIsCheck=true;
               }
           }
       }
       else 
       {
           if(turn==Pieces_Signs.BLACK_TURN)
           {
               if(KingLocation.getRow() == 4 && !IsKingLoc)
                 if(board[6][KingLocation.getCol()].getName() == Pieces_Signs.PAWN)
                   if(board[5][KingLocation.getCol()].getName() == Pieces_Signs.EMPTY_SIGN)
                   {
                       doingCheck.add(new Location(6,KingLocation.getCol()));
                       ThereIsCheck=true;
                   }
               if(board[KingLocation.getRow()][KingLocation.getCol()].getName()==Pieces_Signs.EMPTY_SIGN && KingLocation.getRow()+1 < 8 && !IsKingLoc)
               {
                    Piece place=board[KingLocation.getRow()+1][KingLocation.getCol()];
                    if(place.getName() == Pieces_Signs.PAWN && place.getColor() == Color.white)
                        if(!IsKingLoc)
                        {
                            doingCheck.add(new Location(KingLocation.getRow()+1,KingLocation.getCol()));
                            ThereIsCheck=true;
                        }
               }
               if(KingLocation.getRow()+1 <8 && KingLocation.getCol()+1 < 8 && IsKingLoc)
                {
                    Piece pawn=board[KingLocation.getRow()+1][KingLocation.getCol()+1];
                    if(pawn.getName() == Pieces_Signs.PAWN && pawn.getColor().equals(Color.white))
                    {
                        doingCheck.add(new Location(KingLocation.getRow()+1,KingLocation.getCol()+1));
                        ThereIsCheck=true;
                    }
                }
               if(KingLocation.getRow()+1 < 8 && KingLocation.getCol()-1 >= 0 && IsKingLoc)
                {
                    Piece pawn=board[KingLocation.getRow()+1][KingLocation.getCol()-1];
                    if(pawn.getName() == Pieces_Signs.PAWN && pawn.getColor().equals(Color.white))
                    {
                        doingCheck.add(new Location(KingLocation.getRow()+1,KingLocation.getCol()-1));
                        ThereIsCheck=true;
                    }
                }
           }
       }
       
       return ThereIsCheck;
       }
       catch(Exception e)
       {
           return false;
       }
   }
   /**
    * מחשבת איום על כלי מסוים שעל הלוח
    * Run time - O(d+s+p+k)
    * d - חישוב אורך האלכסונים
    * s - חישוב הקווים הישרים
    * k - חישוב איום על ידי הפרש 
    * p - חישוב איום על ידי הרגלי
    * @param turn - תור שעליו רוצים לבצע האם יש איום
    * @param PlayerLoc - מיקום הכלי שעליו נרצה לבצע את האיום
    * @param NotInMate - האם זה בדיקה של לפני מט
    * @param IsKingLoc - האם מדובר במיקום של המלך או סתם כלי אחר שעל הלוח
    * @return האם הכלי המדובר מאויים או לא
    */
   public boolean Check(char turn,Location PlayerLoc,boolean NotInMate,boolean IsKingLoc)
   {
       boolean CheckLocation=false;
       boolean ThereIsCheck=false;
       if(!(board[PlayerLoc.getRow()][PlayerLoc.getCol()].getName()==Pieces_Signs.EMPTY_SIGN))
           IsKingLoc=true;
       for (int k = 0; k < 6 ; k++) {
                    switch(k)
                    {
                     case 0 -> CheckLocation=checkMainDiagnole(turn, PlayerLoc,NotInMate,false);
                     case 1 -> CheckLocation=checkSecondDiagnole(turn, PlayerLoc,NotInMate,false);
                     case 2 -> CheckLocation=checkLowHigh(turn, PlayerLoc,NotInMate,false);
                     case 3 -> CheckLocation=checkRightLeft(turn, PlayerLoc,NotInMate,false);
                     case 4-> CheckLocation=checkKniget(turn, PlayerLoc, NotInMate,false);//צריך בדיקה
                     default -> CheckLocation=pwanCheck(turn, PlayerLoc,IsKingLoc);//צריך בדיקה
                     }
                    if(CheckLocation==true)
                    {
                        ThereIsCheck=true;
                        break;
                    }
               }
       return ThereIsCheck;
   }
   /**
    * חישוב האם המלך היריב במרחק משבצת מן המלך הנוכחי
    * Run time - O(1)
    * @param oponentTurn - תור השחקן היריב
    * @param KingLoc - תור המלך הנוכחי
    * @return האם המלך היריב במרחק משבצת מן המלך הנוכחי
    */
   public boolean nearToKing(char oponentTurn,Location KingLoc)
   {
       Location[] arrLoc=
       {
            new Location(KingLoc.getRow()-1,KingLoc.getCol()),
            new Location(KingLoc.getRow()-1,KingLoc.getCol()-1),
            new Location(KingLoc.getRow(),KingLoc.getCol()-1),
            new Location(KingLoc.getRow()-1,KingLoc.getCol()+1),
            new Location(KingLoc.getRow()+1,KingLoc.getCol()),
            new Location(KingLoc.getRow()+1,KingLoc.getCol()-1),
            new Location(KingLoc.getRow()+1,KingLoc.getCol()+1),
            new Location(KingLoc.getRow(),KingLoc.getCol()+1)
       };
       for (int i = 0; i < 8; i++) {
           int row=arrLoc[i].getRow();
           int col=arrLoc[i].getCol();
           if(row>=0 && row < 8 && col >=0 && col <8)
            if(board[row][col].getName()==Pieces_Signs.KING)
               return true;
       }
       return false;
   }
   /**
    * Run time - O(getAllpossibleMoves(Runtime))
    * @param state - חישוב פט עבור מצב מסוים של לוח
    * @return האם יש פט 
    */
   public boolean checkPat(State state)
   {
       State st=new State(state);
       st.setTurn(st.getOponenet(st.getTurn()));
       ArrayList<Move> pat=getAllpossibleMoves(st);
       if(pat!=null)
           return false;
       return true;
       
   }
   /**
    * Run time - O(n^2)
    * @return האם יש תיקו
    */
   public boolean checkDraw()
   {
        for (int i = 0; i < 8; i++) {
           for (int j = 0; j < 8; j++) {
               if(board[i][j].getName()!=Pieces_Signs.KING && board[i][j].getName()!=Pieces_Signs.EMPTY_SIGN)
                   return false;
           }
       }
        return true;
   }


    
    public Location findKing(char turn)
    {
        Color color=getColor(turn);
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(board[i][j].getName()==Pieces_Signs.KING && board[i][j].getColor()==color)
                    return new Location(i, j);
            }
        }
        return null;
    }

    public Color getColor(char turn) {
        if(turn==Pieces_Signs.WHITE_TURN)
            return Color.white;
        return Color.black;
    }
    public void printBoard(Piece[][] board)
    {
//        for (int i = 0; i < 8; i++) {
//            for (int j = 0; j < 8; j++) {
//            }
//        }
    }
    
    
    public boolean sameColor(Location loc1,Location loc2)
    {
        if(loc1.getRow()==loc2.getRow()&&loc1.getCol()==loc2.getCol())
            return false;
        if(board[loc2.getRow()][loc2.getCol()].getColor()==board[loc1.getRow()][loc1.getCol()].getColor())
            return true;
        return false;
    }
    
    
    public void makeMove(Move move,boolean realMove)
    {
        Location srcLoc=move.getSrcLoc();
        Location dstLoc=move.getDstLoc();
        Piece p1=board[srcLoc.getRow()][srcLoc.getCol()];
        Piece p2=board[dstLoc.getRow()][dstLoc.getCol()];
        p2.setName(p1.getName());
        p2.setColor(p1.getColor());
        p1.setName(Pieces_Signs.EMPTY_SIGN);
        p1.setColor(Color.yellow);
        if(realMove)
        {
            if(board[dstLoc.getRow()][dstLoc.getCol()].getName()==Pieces_Signs.KING)
            {
                if(Math.abs(srcLoc.getCol()-dstLoc.getCol())==2)
                {
                    if(dstLoc.getCol()==6)
                    {

                        board[srcLoc.getRow()][7].setName(Pieces_Signs.EMPTY_SIGN);
                        board[srcLoc.getRow()][7].setColor(Color.yellow);
                        board[srcLoc.getRow()][5].setName(Pieces_Signs.ROOK);
                        board[srcLoc.getRow()][5].setColor(p2.getColor());
                        rookCast=new Move(new Location(srcLoc.getRow(),7), new Location(srcLoc.getRow(),5));
                    }
                    else
                    {
                        board[srcLoc.getRow()][0].setName(Pieces_Signs.EMPTY_SIGN);
                        board[srcLoc.getRow()][0].setColor(Color.yellow);
                        board[srcLoc.getRow()][3].setName(Pieces_Signs.ROOK);
                        board[srcLoc.getRow()][3].setColor(p2.getColor());
                        rookCast=new Move(new Location(srcLoc.getRow(),0), new Location(srcLoc.getRow(),3));
                    }
                }
            }
                if(p2.getName()==Pieces_Signs.KING)
                {
                    if(p2.getColor()==Color.white)
                    {
                        castle.setKingWhiteHasMoved(true);
                        castle.setTwoSqRookWhiteHasMoved(true);
                        castle.setThreeSqRookWhiteHasMoved(true);
                    }
                    else
                    {
                        castle.setKingBlackHasMoved(true);
                        castle.setTwoSqRookBlackHasMoved(true);
                        castle.setThreeSqRookBlackHasMoved(true);
                    }
                }
                if(p2.getName()==Pieces_Signs.ROOK)
                {
                    if(p2.getColor()==Color.white)
                    {
                        if(srcLoc.getCol()<4)
                            castle.setThreeSqRookWhiteHasMoved(true);
                        else
                            castle.setTwoSqRookWhiteHasMoved(true);
                    }
                    else
                    {
                        if(srcLoc.getCol()<4)
                            castle.setThreeSqRookBlackHasMoved(true);
                        else
                            castle.setTwoSqRookBlackHasMoved(true);
                    }
                }
                
        }
    }
    public void unMakeMove(Move move)
    {
        int srcRow=move.getSrcLoc().getRow();
        int srcCol=move.getSrcLoc().getCol();
        int dstRow=move.getDstLoc().getRow();
        int dstCol=move.getDstLoc().getCol();
        board[srcRow][srcCol].setName(move.getSrcPiece().getName());
        board[srcRow][srcCol].setColor(move.getSrcPiece().getColor());
        board[dstRow][dstCol].setName(move.getDstPiece().getName());
        board[dstRow][dstCol].setColor(move.getDstPiece().getColor());
        if(rookCast!=null)
        {
            Location srcLoc=rookCast.getSrcLoc();
            Location dstLoc=rookCast.getDstLoc();
            board[srcLoc.getRow()][srcLoc.getCol()].setName(Pieces_Signs.ROOK);
            board[srcLoc.getRow()][srcLoc.getCol()].setColor(board[dstLoc.getRow()][dstLoc.getCol()].getColor());
            board[dstLoc.getRow()][dstLoc.getCol()].setName(Pieces_Signs.EMPTY_SIGN);
            board[dstLoc.getRow()][dstLoc.getCol()].setColor(Color.yellow);
            resetRookCast();
        }
        
    }
    public int countWhitePieces()
    {
        int count=0;
        for (int i = 0; i < 8; i++) 
            for (int j = 0; j < 8; j++) 
                if(board[i][j].getColor()==Color.white)
                    count++;
        return count;
    }
    public int countBlackPieces()
    {
        int count=0;
        for (int i = 0; i < 8; i++) 
            for (int j = 0; j < 8; j++) 
                if(board[i][j].getColor()==Color.black)
                    count++;
        return count;
    }
    

    public void setTurn(char turn) {
        this.turn = turn;
    }

    
    public void setBoard(Piece[][] board) {
        this.board = board;
    }

    public Castle getCastle() {
        return new Castle(castle);
    }

    public void setCastle(Castle castle) {
        this.castle = castle;
    }
    public void resetRookCast()
    {
        rookCast=null;
    }
    public void setDoingCheck(ArrayList<Location> doingCheck)
    {
        this.doingCheck=doingCheck;
    }
    public ArrayList<Location> getDoingCheck()
    {
        return doingCheck;
    }
    public void setCurrentForminiMax(char current)
    {
        this.current=current;
    }
}