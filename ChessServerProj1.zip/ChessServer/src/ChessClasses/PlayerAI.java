package ChessClasses;

import ChessClasses.AlphaBeta;
import ChessClasses.Location;
import ChessClasses.Move;
import ChessClasses.Piece;
import ChessClasses.State;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import Networking.Message;

public class PlayerAI extends Player{
    private long MINIMAX_TIME_AT_MILLIS;
    private long secondsTillNow;
    private boolean outOfTime;
    private final int WIN_SCORE=100;
    private final int LOSE_SCORE=0;
    private final int TIE_SCORE=50;
    private float[][] boardPwan;
    private float[][] boardKing;
    private float[][] boardQueen;
    private float[][] boardKnight;
    private float[][] boardBishop;
    private float[][] boardRook;
    private float[][] boardPwanEndGame;
    private float[][] boardForOpKingEndGame;
    public PlayerAI(Color color,State state) {
        super(state,color);
        MINIMAX_TIME_AT_MILLIS=15;
        buildBoardsScore();
    }
    
    @Override
    public Move makeMove()
    {
        return getMinimaxMove();
    }
    public Move getAiMoveRnd(ArrayList<Move> allpossibleMoves) {
        Random rnd=new Random();
        int place=rnd.nextInt(allpossibleMoves.size());
        return allpossibleMoves.get(place);
    }
    /**
     *   
     * מכיוון שיש גיזוםO(t*O(minimx(RunTime)) זמן ריצה
     *טי מייצג את הקריאה הרקורסיבית בכל פעם עד שנגמר הזמן
     * @return מהלך לעשות על פי האלגוריתם מינימקס
     */
    public Move getMinimaxMove()
    {
        
        state.setCurrentForminiMax(this.state.getTurn());
        Move bestMove=null;
        int maxDepth=1;
        long t1; 
        long total;
        long t2;
        long timeLeft=MINIMAX_TIME_AT_MILLIS;
        while(true)
        {
            secondsTillNow=System.currentTimeMillis();
            outOfTime=false;
            Move tmpMove=bestMove;
            bestMove=minimax(new State(this.state.getBoard(), this.state.currentOfminiMax(), this.state.getCastle()),true,0,maxDepth,new AlphaBeta(Integer.MIN_VALUE,0),new AlphaBeta(Integer.MAX_VALUE, 0));
            if(outOfTime)
            {
                bestMove=tmpMove;
                break;
            }
            maxDepth++;
        }
        System.out.println(maxDepth-1);
        return bestMove;
    }
   private int getNumberCircleUp(double num)
   {
       if(num>=0.6 && num<=1)
           return 1;
       else
           if(num<0.6)
               return 0;
           else
               return (int)num;
   }
   /**
    * ככל שמשקל המשחק יותר קטן ככה המשחק יותר  מפותח
    *Run time - O(n^2): כאשר אן הוא מספר גודל הלוח זה מעבר על כל מטריצת הלוח שהיא שישים וארבע 
    *
    * @return משקל המשחק
    */
   private int getGameWight()
   {
       int mountOfBlackPieces=state.countBlackPieces();
       int mountOfWhitePieces=state.countWhitePieces();
       int endGameWight=(mountOfBlackPieces+mountOfWhitePieces);
       int totalPieces=32;
       if(endGameWight>=5)
           return 0;
       if(totalPieces/4>endGameWight)
           return 3;
       return endGameWight/2;
   }
   private Piece[][] getCpyBoard()
   {
       Piece[][] board=new Piece[8][8];
       for (int i = 0; i < 8; i++) {
           for (int j = 0; j < 8; j++) {
               board[i][j]=new Piece(state.getBoard()[i][j]);
           }
       }
       return board;
   }
   /**
    * חישוב של ניקוד עבור מצב מסוים של כל עלה בעץ 
    *על פי אסטרטגיה
    *Run time - O(n^2) מכיוון שעוברים על כל המטריצה כאשר אן על אן הוא גודל המטריצה
    * @param state עבור איזה מצב לחשב ניקוד
    * @return 
    */
   public int eval(State state)
    {
        int countBlackPieces=0;
        int countWhitePieces=0;
        int evalScore;
        float whiteScore=0;
        float blackScore=0;
        float sumBlackWhite=0;
        Location kingLocWhite=null;
        Location kingLocBlack=null;
        Piece[][] board=state.getBoard();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(board[i][j].getColor()==Color.white)
                {
                        whiteScore+=(getScoreByPosition(state,board[i][j].getName(), new Location(i, j)));
                        whiteScore+=board[i][j].getScoreBypiece();
                        if(board[i][j].getName()==Pieces_Signs.KING)
                            kingLocWhite=new Location(i, j);
                        countWhitePieces++;
                }
                else 
                {
                    if(board[i][j].getColor()==Color.black)
                    {
                        blackScore+=(getScoreByPosition(state,board[i][j].getName(), new Location(7-i, 7-j)));
                        blackScore+=board[i][j].getScoreBypiece();
                        if(board[i][j].getName()==Pieces_Signs.KING)
                            kingLocBlack=new Location(i, j);
                        countBlackPieces++;
                    }
                }
            }
        }
            if(state.currentOfminiMax()==Pieces_Signs.WHITE_TURN)
            {
                whiteScore+=getOnlyKingScore(kingLocWhite, kingLocBlack,getGameWight());
                whiteScore-=board[kingLocWhite.getRow()][kingLocWhite.getCol()].getScoreBypiece();
                whiteScore-=keepLookForDangouresMoves(state);
            }
            else
            {
                blackScore+=getOnlyKingScore(kingLocBlack, kingLocWhite,getGameWight());
                blackScore-=board[kingLocBlack.getRow()][kingLocBlack.getCol()].getScoreBypiece();
                blackScore-=keepLookForDangouresMoves(state);
            }
            
        sumBlackWhite=whiteScore+blackScore;
        whiteScore=getCorrectNumber((whiteScore/(float)sumBlackWhite) * 100);
        blackScore=getCorrectNumber((blackScore/(float)sumBlackWhite) * 100);
        if(state.currentOfminiMax()==Pieces_Signs.WHITE_TURN)
            evalScore=(int)whiteScore;
        else
            evalScore=(int)blackScore;
        return evalScore;
    }
   /**
    * מחשבת דיוק של מספר עשרוני מיועד בעיקר לפונקציית האיבל בכדי לדייק ניקוד 
    * Run time - O(1)
    * @param num מספר הרוצים לעגל כלפי מעלה או מטה
    * @return מספר מעוגל כלפי מעלה או מטה
    */
    private int getCorrectNumber(float num)
    {
        if(num-(int)num<=0.2)
            return (int)num;
        else
            if(num-(int)num<=0.4)
                return (int)num+1;
            else
                if(num-(int)num<=0.6)
                    return (int)num+2;
                else
                    return (int)num+3;
    }
    /**
     * מחשבת את מרחק המלך היריב מהפינות ככל שהמלך היריב קרוב לפינות ככה הניקוד יהיה יותר גבוה
     *מיועד לפונקצית איבל
     * @param kingTurn - מיקום המלך של המצב הנוכחי במינימקס
     * @param kingOponent - מיקום המלך היריב של המצב הנוכחי במינימקס
     * @param endGameWight - משקל המשחק האם מדובר בפתיחה של משחק אמצע או סיום רלוונטי לסיום משחק
     *Run time - O(1)
     * @return ניקוד כמה המלך היריב רחוק מן הפינות
     */
    public int getOnlyKingScore(Location kingTurn,Location kingOponent,int endGameWight)//מט עבור קינג אחד ליריב בלבד
    {
        int eval;
        int oponentKingDstFromCenterRank=Math.max(3-kingOponent.getRow(),kingOponent.getRow()-4);
        int oponentKingDstFromCenterFile=Math.max(3-kingOponent.getCol(), kingOponent.getCol()-4);
        eval=oponentKingDstFromCenterFile+oponentKingDstFromCenterRank;
        int rank=Math.abs(kingTurn.getRow()-kingOponent.getRow());
        int file=Math.abs(kingTurn.getCol()-kingOponent.getCol());
        eval+=(14-(rank+file));
        return eval * 10 * endGameWight;
    }
    /**
     * 
     * מחשבת כמה כלים מאיימים על כלי נוכח בלוח 
     *  מיועד לפונקציית האיבל
     * Run time - O(n^2*c*k) - 
     * n^2 - מעבר על כל הלוח כאשר אן הוא גודל המטרריצה
     * c - פונקציית השח כאשר סי הוא זמן הריצה של פונקצייה זו 
     * k - מעבר על כל כלי שמאיים על הכלי הנוכחי
     * @param state - המצב הנוכחי של מינימקס
     * @return את ניקוד הכלים המאויימים על ידי כלים שחלשים מהם
     */
    public int keepLookForDangouresMoves(State state)
    {
        int minusEval=0;
        Piece[][] board=state.getBoard();
        Color currentColor=state.getColor(state.currentOfminiMax());
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(board[i][j].getColor()==currentColor)
                {
                    state.setDoingCheck(new ArrayList<Location>());
                    if(state.Check(state.currentOfminiMax(),new Location(i,j),false,true))
                    {
                        for (int k = 0; k < state.getDoingCheck().size(); k++) {
                            int row=state.getDoingCheck().get(k).getRow();
                            int col=state.getDoingCheck().get(k).getCol();
                            if(board[i][j].getScoreBypiece()>board[row][col].getScoreBypiece())
                                minusEval+=board[i][j].getScoreBypiece();
                        }
                    }
                }
            }
        }
        return minusEval;
    }
    /**
     * 
     * מחשבת כמה צעדים המלך היריב יכול לעשות
     * Run time - O(m*c) - possibleMoves in State class זמן הריצה של הפונקציה 
     * @param state - מצב נוכחי עבור המינימקס
     * @param kingOpLocation - מיקום המלך היריב
     * @return את מספר הצעדים הממוזערים שהמלך יכול ללכת אליהם
     */
    public int minSizeOfTargetsKing(State state,Location kingOpLocation)
    {
        return 8-state.possibleMoves(kingOpLocation, new State(state.getBoard(), state.getOponenet(state.currentOfminiMax()))).size();
    }
    /**
     * אלגוריתם מינימקס לחישוב מהלך הטוב ביותר עבור מצב מסוים בשחמט
     * Run time - O(b^(d/2)*O(possibleMoves(Run time))
     * b - מספר המהלכים האפשריים עבור כל צומת בעץ בהנחה שהוא הכי גדול שזה יוצא ארבעים ושלוש
     * d - מספר העומק שאליו מגיע העץ
     * possibleMoves in class state - זמן הריצה של פונקציה זו
     * @param state - המצב הנוכחי של המינימקס
     * @param isMaxPlayer - האם מדובר בתור השחקן שהפעיל את המינימקס
     * @param depth - עומק נוכחי של העץ
     * @param maxDepth - העומק המקסימלי אליו העץ יכו להגיע
     * @param a - משקף את מרחק לביתא
     * @param b - משקף את המרחק לאלפא
     * @return את המהלך בעל הניקוד הכי גבוה או הכי נמוך עד כה 
     */
    public Move minimax(State state,boolean isMaxPlayer,int depth,int maxDepth,AlphaBeta a,AlphaBeta b)
    {
        if(outOfTime==true)
            return null;
        Move bestMove=null;
        ArrayList<Move> possibleMoves=state.getAllpossibleMoves(state); 
        int thereIsTerminal=isTerminal(state,isMaxPlayer,possibleMoves==null);
        if((thereIsTerminal!=-1)||depth==maxDepth)
        {
            if(thereIsTerminal!=-1)
                return new Move(thereIsTerminal,depth);
            return new Move(eval(state),depth);
        }
        if(isMaxPlayer)
        {
            bestMove = new Move(Integer.MIN_VALUE);
            for (int i = 0; i < possibleMoves.size(); i++) 
            {
                    if((System.currentTimeMillis()-secondsTillNow)/1000.0>=MINIMAX_TIME_AT_MILLIS)
                    {
                        System.out.println((System.currentTimeMillis()-secondsTillNow)/1000.0);
                        outOfTime=true;
                        return null;
                    }
                    applyMove(state,possibleMoves.get(i));
                    Move move = minimax(new State(state.getBoard(),state.getOponenet(state.getTurn()),state.getCastle()),false,depth+1,maxDepth,new AlphaBeta(a),new AlphaBeta(b));
                   if(outOfTime==true)
                   {
                       state.unMakeMove(possibleMoves.get(i));
                       return null;
                   }
                    move.setScore(move.getScore()-(keepLookForDangouresMoves(state)/100));
                    if(a.getVal()==move.getScore())
                    {
                        if(a.getDepth()>move.getDepth())
                        {
                            a.setVal(move.getScore());
                            a.setDepth(move.getDepth());
                        }
                    }
                    else
                        if(a.getVal()<move.getScore())
                        {
                            a.setVal(move.getScore());
                            a.setDepth(move.getDepth());
                        }
                    
                    if(depth==0)
                    {
                            move.setScore(move.getScore()-(keepLookForDangouresMoves(state)/100));
                            if(move.getScore()>bestMove.getScore())
                            {
                                possibleMoves.get(i).setScore(move.getScore());
                                possibleMoves.get(i).setDepth(move.getDepth());
                                bestMove=new Move(possibleMoves.get(i));
                            }
                           else
                               if(move.getScore()==bestMove.getScore())
                                   if(move.getDepth()<bestMove.getDepth())
                                   {
                                       possibleMoves.get(i).setScore(move.getScore());
                                       possibleMoves.get(i).setDepth(move.getDepth());
                                       bestMove=new Move(possibleMoves.get(i));
                                   }
                    }
                    if(move.getScore()>bestMove.getScore())
                        bestMove=new Move(move);
                    else
                        if(bestMove.getScore()==move.getScore())
                           if(bestMove.getDepth()>move.getDepth())
                               bestMove=new Move(move);
                    state.unMakeMove(possibleMoves.get(i));
                    if(a.getVal()==b.getVal())
                    {
                        if(a.getDepth()<b.getDepth())
                            break;
                    }
                    else
                        if(a.getVal()>b.getVal())
                            break;
            }
        }
        else
        {
            bestMove = new Move(Integer.MAX_VALUE);
            for (int i = 0; i < possibleMoves.size(); i++)
            {
                if((System.currentTimeMillis()-secondsTillNow)/1000.0>=MINIMAX_TIME_AT_MILLIS/1.5)
                {
                    System.out.println((System.currentTimeMillis()-secondsTillNow)/1000.0);
                    outOfTime=true;
                    return null;
                }
                    applyMove(state,possibleMoves.get(i));
                    Move move=minimax(new State(state.getBoard(),state.getOponenet(state.getTurn()),state.getCastle()),true,depth+1,maxDepth,new AlphaBeta(a),new AlphaBeta(b));
                    if(outOfTime==true)
                    {
                        state.unMakeMove(possibleMoves.get(i));
                        return null;
                    }
                    if(b.getVal()==move.getScore())
                    {
                        if(b.getDepth()<move.getDepth())
                        {
                            b.setVal(move.getScore());
                            b.setDepth(move.getDepth());
                        }
                    }
                    else
                        if(b.getVal()<move.getScore())
                        {
                            b.setVal(move.getScore());
                            b.setDepth(move.getDepth());
                        }
                    if(move.getScore()<bestMove.getScore())
                        bestMove=new Move(move);
                    else
                        if(move.getScore()==bestMove.getScore())
                            if((move.getDepth())<bestMove.getDepth())
                                bestMove=new Move(move);
                    state.unMakeMove(possibleMoves.get(i));
                    //------------------------
                    if(a.getVal()==b.getVal())
                    {
                        if(a.getDepth()<b.getDepth())
                            break;
                    }
                    else
                        if(a.getVal()>b.getVal())
                            break;
            }
        }
        return new Move(bestMove);
    }
    /**
     * Run time - O(Check in class State)
     * @param state - מצב במינימקס עליו נרצה לבדוק האם הגיע לסיום משחק
     * @param isMaxPlayer - האם מדובר בשחקן מקסימום במינימקס
     * @param thereIsPat - האם יש פט
     * @return האם יש סיום משחק
     */
    public int isTerminal(State state,boolean isMaxPlayer,boolean thereIsPat) {
        if(thereIsPat)
        {
            if (state.checkMove(state.getTurn(), false))//יש מנצח
            {
                if(isMaxPlayer)
                    return LOSE_SCORE;
                else 
                    return WIN_SCORE;
            }
            return TIE_SCORE;
        }
        return -1;
    }
    public void applyMove(State state,Move move)
    {
        Location srcLoc=move.getSrcLoc();
        Location dstLoc=move.getDstLoc();
        state.makeMove(move,true);
        if(state.getBoard()[dstLoc.getRow()][dstLoc.getCol()].getName()==Pieces_Signs.PAWN)
        {
            if(dstLoc.getRow()==7||dstLoc.getRow()==0)
                state.pwanChange();
        }
    }
    private float getScoreByPosition(State state,char name,Location pieceLoc)
    {
        int SCORE=0;
        if(getGameWight()<=3)
            SCORE=0;
        int row=pieceLoc.getRow();
        int col=pieceLoc.getCol();
        switch(name)
        {
            case Pieces_Signs.KING:return boardKing[row][col]*SCORE;
            case Pieces_Signs.PAWN:return boardPwan[row][col]*SCORE;
            case Pieces_Signs.KNIGHT:return boardKnight[row][col]*SCORE;
            case Pieces_Signs.BISHOP:return boardBishop[row][col]*SCORE;
            case Pieces_Signs.ROOK:return boardRook[row][col]*SCORE;
            case Pieces_Signs.QUEEN:return boardQueen[row][col]*SCORE; 
        }
        return 0;
    }
    public int getScoreBoard(State state)
    {
        int score=0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if(state.currentOfminiMax()==Pieces_Signs.WHITE_TURN)
                    if(state.getBoard()[i][j].getColor()==Color.white)
                        score+=getScoreByPosition(state,state.getBoard()[i][j].getName(),new Location(i,j));
                else
                    if(state.currentOfminiMax()==Pieces_Signs.BLACK_TURN)
                        if(state.getBoard()[i][j].getColor()==Color.black)
                            score+=getScoreByPosition(state,state.getBoard()[i][j].getName(),new Location(7-i,7-j));
            }
        }
        return score;
    }
    public void setSecondsForMinimax(int seconds)
    {
        MINIMAX_TIME_AT_MILLIS=seconds*1000;
    }
    public void buildBoardsScore()
    {
        buildBoardForBishop();
        buildBoardForKing();
        buildBoardForKnight();
        buildBoardForPwan();
        buildBoardForQueen();
        buildBoardForRook();
        buildBoardForPwanEndGame();
        buildBoardForOponentKing();
    }
    public float getScoreByPositionEndGame(char name,Location pieceLoc)
    {
        final int SCORE=10;
        return boardPwanEndGame[pieceLoc.getRow()][pieceLoc.getCol()] * SCORE;
    }
    public void buildBoardForKing()
    {
        float[][] board={
            {-3,-4,-4,-5,-5,-4,-4,-3},
            {-3,-4,-4,-5,-5,-4,-4,-3},
            {-3,-4,-4,-5,-5,-4,-4,-3},
            {-3,-4,-4,-5,-5,-4,-4,-3},
            {-2,-3,-3,-4,-4,-3,-3,-2},
            {-1,-2,-2,-2,-2,-2,-2,-1},
            { 2, 2, 0, 0, 0, 0, 2, 2},
            { 2, 3, 1, 0, 0, 1, 3, 2}
        };
        boardKing=board;
    }
    public void buildBoardForRook()
    {
        float[][] board={
            { 0, 0, 0, 0, 0, 0, 0,0},
            {(float)0.5,1,1,1,1,1,1,1,(float)0.5},
            {(float)-0.5, 0, 0, 0, 0, 0, 0, (float)-0.5},
            {(float)-0.5, 0, 0, 0, 0, 0, 0, (float)-0.5},
            {(float)-0.5, 0, 0, 0, 0, 0, 0, (float)-0.5},
            {(float)-0.5, 0, 0, 0, 0, 0, 0, (float)-0.5},
            {(float)-0.5, 0, 0, 0, 0, 0, 0, (float)-0.5},
            { -4, -3, 0, (float)0.5, (float)0.5, 0, -3, -4}
        };
        boardRook=board;
    }
    public void buildBoardForKnight()
    {
        float[][] board={
            {-5,-4,-3,-3,-3,-3,-4,-5},
            {-4,-2,0,0,0,0,-2,-4},
            {-3,0,1,(float)1.5,(float)1.5,1,0,-3},
            {-3,(float)0.5,(float)1.5,2,2,(float)1.5,(float)0.5,-3},
            {-3,0,(float)1.5,2,2,(float)1.5,0,-3},
            {-3,(float)0.5,1,(float)1.5,(float)1.5,1,(float)0.5,-3},
            {-4,-2,0,(float)0.5,(float)0.5,0,-2,-4},
            {-5,-4,-3,-3,-3,-3,-4,-5}
        };
        boardKnight=board;
    }
    public void buildBoardForQueen()
    {
        float[][] board={
            {-2,-1,-1,(float)-0.5,(float)-0.5,-1,-1,-2},
            {-1,0,0,0,0,0,0,-1},
            {-1,0,(float)0.5,(float)0.5,(float)0.5,(float)0.5,0,-1},
            {(float)-0.5,0,(float)0.5,(float)0.5,(float)0.5,(float)0.5,0,(float)-0.5},
            {0,0,(float)0.5,(float)0.5,(float)0.5,(float)0.5,0,(float)-0.5},
            {-1,(float)0.5,(float)0.5,(float)0.5,(float)0.5,(float)0.5,0,-1},
            {-1,0,(float)0.5,0,0,0,0,-1},
            {-2,-1,-1,(float)-0.5,(float)-0.5,-1,-1,-2}
        };
        boardQueen=board;
    }
    public void buildBoardForBishop()
    {
        float[][] board={
            {-2,-1,-1,-1,-1,-1,-1,-2},
            {-1,0,0,0,0,0,0,-1},
            {-1,0,(float)0.5,1,1,(float)0.5,0,-1},
            {-1,(float)0.5,(float)0.5,1,1,(float)0.5,(float)0.5,-1},
            {-1,0,1,1,1,1,0,-1},
            {-1,1,1,1,1,1,1,-1},
            {-1,(float)0.5,0,0,0,0,(float)0.5,-1},
            {-2,-1,-1,-1,-1,-1,-1,-2}
        };
        boardBishop=board;
    }
    public void buildBoardForPwan()
    {
        float[][] board={
            {0,0,0,0,0,0,0,0},
            {5,5,5,5,5,5,5,5},
            {1,1,2,3,3,2,1,1},
            {(float)0.5,(float)0.5,1,(float)2.5,(float)2.5,1,(float)0.5,(float)0.5},
            {0,0,3,5,5,3,0,0},
            {(float)0.5,(float)-0.5,-1,0,0,-1,(float)-0.5,(float)0.5},
            {(float)0.5,1,1,-2,-2,1,1,(float)0.5},
            {0,0,0,0,0,0,0,0},
        };
        boardPwan=board;
    }
    public void buildBoardForPwanEndGame()
    {
        float[][] board={
            {13,13,13,13,13,13,13,13},
            {11,11,11,11,11,11,11,11},
            {9,9,9,9,9,9,9,9},
            {7,7,7,7,7,7,7,7},
            {5,5,5,5,5,5,5,5},
            {3,3,3,3,3,3,3,3},
            {1,1,1,1,1,1,1,1},
            {0,0,0,0,0,0,0,0},
        };
        boardPwanEndGame=board;
    }
    public void buildBoardForOponentKing()
    {
        float[][] board={
            {100,95,90,80,80,90,95,100},
            {95 ,87,85,70,70,85,87,95},
            {90, 85,70,50,50,9, 85,90},
            {80, 70,50,0 ,0 ,7 ,70,80},
            {80 ,70,4 ,0 ,0 ,4 ,70,80},
            {90 ,85,7, 10,10,85,85 ,90},
            {95 ,87,85,70,70,85,87,95},
            {100,95,90,80,80,90,95,100},
        };
        boardForOpKingEndGame=board;
    }
    @Override
    public void sendToClient(Message msg) {
    }

    @Override
    public void setGame(Game game) {
        
    }

    @Override
    public void stopMovesFromPlayer() {
    }

    @Override
    public void keepMovesForPlayer() {
    }

    @Override
    public void setUpBoard() {
    }

    @Override
    public void updateCurrentPlayer() {
    }

    @Override
    public void updateCurrentPlayerDeafult() {
    }

    @Override
    public void ShowWinnerByMate() {
    }

    @Override
    public void showPat() {
    }

    @Override
    public void showDraw() {
    }

    @Override
    public void showPossibleMoves(ArrayList<Location> tmp) {
    }

    @Override
    public void showPossibleSrc(Location loc) {
    }

    @Override
    public void changeForPwan(Move testPwanChange) {
    }

    @Override
    public void buildBoard() {
    }

    @Override
    public void showCheckOnKing(char turn) {
    }

    @Override
    public void clearBorders() {
    }

    @Override
    public void closeGameOponentGivesUp() {
    }

}
