package ChessClasses;
public class Pieces_Signs{
    public static final char EMPTY_SIGN=' ';
    public static final char KING='K';
    public static final char ROOK='R';
    public static final char KNIGHT='N';
    public static final char BISHOP='B';
    public static final char QUEEN='Q';
    public static final char PAWN='p';
    public static final char WHITE_TURN='W';
    public static final char BLACK_TURN='B';
}
