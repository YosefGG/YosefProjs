package Networking;
import ChessClasses.State;
import java.awt.BorderLayout;
import java.awt.Color;
import java.net.*;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import ChessClasses.*;
import javax.swing.JOptionPane;


public class ServerGame {

    public ServerGame() {
    }

    
    
    private JTextArea textArea;
    private ArrayList<Game> games=new ArrayList<Game>();
    static JFrame win;
    static ServerSocket serverSocket;
    public static void main(String[] args)  {
        ServerGame server=new ServerGame();
        server.createGUI();
        server.initServer();
        server.waitingSomeoneConnected();
    }

    
    public void waitingSomeoneConnected()
    {
        
        Thread thread=new Thread(new Runnable() {
            @Override
            public void run()
            {
                AppSocket keepAppSocket=null;
                
                
                try 
                {
                    
                    
                    while(true)
                    {
                        Socket socket=serverSocket.accept();
                        Socket socketCmd=serverSocket.accept();
                        Socket socketMenu=serverSocket.accept();
                        AppSocket appSocket=new AppSocket(socket,socketCmd,socketMenu);
                        textArea.append("Guest connected from:"+appSocket.getIP()+"\n");
                        Message ms=appSocket.readMsg();
                        ms.setSubject(ms.getMsg());
                        ms.setMsg((games.size()+1)+"");
                        appSocket.writeMsg(ms);
                        Message lockButtons=new Message("disableBtns");
                        appSocket.writeMsg(lockButtons);
                        if(ms.getSubject()!=null && ms.getSubject().equals("AI"))
                        {
                            Message msg=new Message("setColorPlayer");
                            msg.setCh('W');
                            appSocket.writeMsg(msg);
                            createGameForOneAI(appSocket);
                        }
                        else
                            if(keepAppSocket!=null)
                            {
                                
                                Message msg=new Message("setColorPlayer");
                                msg.setCh('W');
                                if(!keepAppSocket.writeMsg(msg))
                                    keepAppSocket=appSocket;
                                else
                                {
                                    msg.setCh('B');
                                    appSocket.writeMsg(msg);
                                    createGameForTwoNet(keepAppSocket, appSocket);
                                    keepAppSocket=null;
                                }
                            }
                            else
                            {
                                keepAppSocket=appSocket;
                                appSocket.writeMsg(new Message("showWaitingForFlayerToConnected"));
                            }
                    }
                } 
                catch (Exception ex) 
                {}
            }
            
        });
        thread.start();
    }
    public void createGameForTwoNet(AppSocket appSocketp1,AppSocket appSocketp2)
    {
        State state=new State(1);
        PlayerNet p1=new PlayerNet(appSocketp1, state,Color.white);
        PlayerNet p2=new PlayerNet(appSocketp2, state, Color.black);
        Game game=new Game(p1,p2,this);
        synchronized(games)
        {
            games.add(game);
        }
        
    }
    public void createGameForOneAI(AppSocket appSocketp1)
    {
        State state=new State(1);
        PlayerNet p1=new PlayerNet(appSocketp1, state,Color.white);
        PlayerAI p2=new PlayerAI(Color.black,state);
        Game game=new Game(p1,p2,this);
        synchronized(games)
        {
            games.add(game);
        }    
    }
    public void createGUI() 
    {
        win=new JFrame("Chess Server");
        win.setSize(400, 400);
        win.setLocationRelativeTo(null);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.setLayout(new BorderLayout());
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setForeground(Color.green);
        textArea.setBackground(Color.black);
        win.add(textArea,BorderLayout.CENTER);
        JPanel pnl=new JPanel(new BorderLayout());
        win.add(pnl,BorderLayout.SOUTH);
        win.setVisible(true);
        
    }
    public void removeGame(Game game)
    {
        synchronized(games)
        {
            for (int i = 0; i < games.size(); i++) {
                if(games.get(i).equals(game))
                {
                    games.remove(games.get(i));
                    return;
                }
            }
        }
    }
    private void initServer() {
        boolean keepAskingPort;
        int port=1111;
        do
        {
            keepAskingPort=false;
                try {
                    port=Integer.parseInt(askForPort());
                    serverSocket=new ServerSocket(port);
                } 
                catch (Exception ex) {
                    keepAskingPort=true;
                }
        }while(keepAskingPort);
        try {
            textArea.append("The server is runing on:IP="+InetAddress.getAllByName("DESKTOP-66I3DCF")[1].getHostAddress()+", Port="+serverSocket.getLocalPort()+"\n");
        } catch (Exception ex) {
            try
            {
                textArea.append("The server is runing on:IP="+InetAddress.getLocalHost().getHostAddress()+", Port="+serverSocket.getLocalPort()+"\n");
            }
            catch(Exception t){}
        }
    }
    private String askForPort() {
        String messagePort = "Enter the Server's port!";
        String inputPort;
        inputPort = (String) JOptionPane.showInputDialog(win, messagePort, "Port request", JOptionPane.DEFAULT_OPTION,null,null,1111);
        if(inputPort==null)
            inputPort="1111";
        return inputPort;
    }

}
