package Networking;

import ChessClasses.Location;
import ChessClasses.Move;
import ChessClasses.Piece;
import ChessClasses.State;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Stack;
import ChessClasses.Game;
import ChessClasses.Player;

public class PlayerNet extends Player{
    private AppSocket appSocket;
    private Game game;
    
    public PlayerNet(AppSocket appSocket,State state, Color color) {
        super(state,color);
        this.appSocket = appSocket;
        waitForDisconnect();
        waitForMenuMsg();
    }
    
    private void waitForDisconnect()
    {
        PlayerNet player=this;
        new Thread(new Runnable() 
        {
            @Override
            public void run() 
            {
                while(true)
                {
                    if(appSocket.readCmdMsg().equals("Disconnected"))
                    {
                        game.closeGame(player);
                        break;
                    }
                }
            }
        }).start();
        
    }
    private void waitForMenuMsg()
    {
        new Thread(new Runnable() 
        {
            @Override
            public void run()
            {
                boolean socketAlive=true;
                while(socketAlive)
                {
                    try
                    {
                        Message menuMsg=appSocket.readMenuMsg();
                        System.out.println("Menu message successed!");
                        switch (menuMsg.getSubject()) {
                            case "setUpMenu": game.startNewGame(menuMsg.getNum());
                                              
                                              break;
                            case "Disconnected": appSocket.disconnectMenuSocket();
                                                 socketAlive=false;
                                                 break;
                        }
                    }
                    catch(Exception e){}
                }   
            }
        }).start();
        
    }
    
    @Override
    public Move makeMove()
    {
        Message msg=appSocket.readMsg();
        return new Move(msg.getLoc(),new Location(-1,-1));
    }
     
    @Override
    public void setGame(Game game)
    {
        this.game=game;
    }
    @Override
    public void stopMovesFromPlayer()
    {
        Message msg=new Message("disableBtns");
        sendToClient(msg);
    }
    @Override
    public void keepMovesForPlayer()
    {
         Message msg=new Message("enableBtns");
         sendToClient(msg);
    }
     @Override
    public void setUpBoard() {
        Message msg=new Message("setUp");
        msg.setPiece2d(super.getState().getBoard());
        sendToClient(msg);
    }
     @Override
    public void updateCurrentPlayer() {
        Message msg=new Message("updateCurrentPlayer");
        msg.setCh(super.getState().getOponenet(super.getState().getCurrentPlayer()));
        sendToClient(msg);
    }
    @Override
    public void updateCurrentPlayerDeafult() {
        Message msg=new Message("updateCurrentPlayerDeafult");
        sendToClient(msg);
    }
    @Override
    public void ShowWinnerByMate() {
        Message msg=new Message("ShowWinnerByMate");
        msg.setPiece2d((new State(1)).getBoard());
        msg.setCh(super.getState().getTurn());
        sendToClient(msg);
    }

    @Override
    public void showPat() {
        Message msg=new Message("showPat");
        msg.setPiece2d((new State(1)).getBoard());
        sendToClient(msg);
    }

    @Override
    public void showDraw() {
        Message msg=new Message("showDraw");
        msg.setPiece2d((new State(1)).getBoard());
        sendToClient(msg);
    }
    
    public void sendToClient(Message msg)
    {
        
        System.out.println(msg.getSubject());
        synchronized (appSocket) {
            
        appSocket.writeMsg(msg);
        }
    }

    @Override
    public void showPossibleMoves(ArrayList<Location> tmp) {
        Message msg=new Message("showPossibleMoves");
        msg.setArrayLoc(tmp);
        sendToClient(msg);
    }

    @Override
    public void showPossibleSrc(Location loc) {
        Message msg=new Message("showPossibleSrc");
        msg.setLoc(loc);
        sendToClient(msg);
    }

    @Override
    public void changeForPwan(Move testPwanChange) {
        Message msg=new Message("changeForPwan");
        msg.setMove(testPwanChange);
        sendToClient(msg);
    }

    @Override
    public void buildBoard() {
        Message msg=new Message("buildBoard");
        sendToClient(msg);
    }

    @Override
    public void showCheckOnKing(char turn) {
        Message msg=new Message("showCheckOnKing");
        msg.setCh(state.getTurn());
        sendToClient(msg);
    }

    @Override
    public void clearBorders() {
        Message msg=new Message("clearBorders");
        sendToClient(msg);
        
    }

    @Override
    public void closeGameOponentGivesUp() {
        Message msg=new Message("closeGameOponentGivesUp");
        sendToClient(msg);
    }
    
    

   

   
}
