
package Networking;
import ChessClasses.Location;
import ChessClasses.Move;
import ChessClasses.Piece;
import java.io.Serializable;
import java.util.ArrayList;
public class Message implements Serializable{
    private String msg;
    private String subject;
    private int num;
    private Location loc;
    private char ch;
    private int index;
    private ArrayList<Location> arrayLoc;
    private Move move;
    private Piece piece;
    private Piece[] piece1d;
    private Piece[][] piece2d;
    
    public Message(String subject)
    {
        this.subject=subject;
    }


    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Location getLoc() {
        return loc;
    }

    public void setLoc(Location loc) {
        this.loc = loc;
    }

    public char getCh() {
        return ch;
    }

    public void setCh(char ch) {
        this.ch = ch;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public ArrayList<Location> getArrayLoc() {
        return arrayLoc;
    }

    public void setArrayLoc(ArrayList<Location> arrayLoc) {
        this.arrayLoc=new ArrayList<Location>();
        for (int i = 0; i < arrayLoc.size(); i++) 
            this.arrayLoc.add(new Location(arrayLoc.get(i)));
    }

    public Piece getPiece() {
        return piece;
    }

    public void setPiece(Piece piece) {
        this.piece = new Piece(piece);
    }

    public Piece[] getPiece1d() {
        return piece1d;
    }

    public void setPiece1d(Piece[] piece1d) {
        this.piece1d=new Piece[piece1d.length];
        for (int i = 0; i < piece1d.length; i++) 
            this.piece1d[i]=new Piece(piece1d[i]);
    }

    public Piece[][] getPiece2d() {
        return piece2d;
    }

    public void setPiece2d(Piece[][] piece2d) {
        this.piece2d=new Piece[piece2d.length][piece2d.length];
        for (int i = 0; i < piece2d.length; i++) 
            for (int j = 0; j < piece2d.length; j++) 
                this.piece2d[i][j]=new Piece(piece2d[i][j]);
        
    }

    public Move getMove() {
        return move;
    }

    public void setMove(Move move) {
        this.move = new Move(move);
    }
    
    
    
    
}
